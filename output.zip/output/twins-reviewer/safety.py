"""Offline bounded static preparation; never executes inspected source."""
import argparse
import datetime as dt
import fnmatch
import hashlib
import json
import os
import re
from pathlib import Path

STAGES = ('inventory', 'architecture', 'workflows', 'documentation', 'diagrams', 'coverage')
EXCLUDE = {'.git', '.venv', 'venv', 'node_modules', '__pycache__', 'dist', 'build', '.aws', '.ssh'}
SECRET = re.compile(r'(^\.env(?:\.|$)|secret|credential|password|token|\.(?:pem|key|p12|pfx)$)', re.I)
EXTENSIONS = {'.py', '.js', '.ts', '.tsx', '.jsx', '.md', '.rst', '.toml', '.json', '.yaml', '.yml', '.sql', '.html', '.css', '.sh', '.ps1'}

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)

def configuration(path):
    path = Path(path).resolve()
    cfg = json.loads(path.read_text(encoding='utf-8-sig'))
    root = path.parent.parent
    if cfg.get('network') != 'disabled' or cfg.get('source_access') != 'read-only':
        raise ValueError('Only offline, read-only inspection is implemented')
    source = Path(cfg.get('source_root') or '')
    if not source.is_absolute() or not source.is_dir():
        raise ValueError('source_root must be an existing absolute directory')
    source = source.resolve()
    value = Path(cfg['output_root'])
    output = (root / value).resolve()
    if value.is_absolute() or root not in output.parents:
        raise ValueError('output_root must remain inside the lab')
    if source == root or source in root.parents or root in source.parents:
        raise ValueError('Source must be separate from the lab')
    for field in ('max_file_bytes', 'max_total_bytes', 'max_files'):
        if type(cfg.get(field, 1)) is not int or cfg.get(field, 1) < 1:
            raise ValueError('Bounds must be positive integers')
    if not isinstance(cfg.get('exclude'), list) or not all(isinstance(x, str) for x in cfg['exclude']):
        raise ValueError('Invalid exclusions')
    if cfg.get('skills') != list(STAGES):
        raise ValueError('Unsupported skill order')
    return cfg, source, output

def linked(path):
    return path.is_symlink() or bool(getattr(path.lstat(), 'st_file_attributes', 0) & 0x400)

def excluded(path, patterns):
    return any(part in EXCLUDE or SECRET.search(part) or any(fnmatch.fnmatchcase(part, pat) for pat in patterns) for part in path.parts)

def inventory(source, cfg):
    entries, omitted, unread = [], [], []
    budget = cfg.get('max_total_bytes', 10_000_000)
    def walk_error(exc):
        # Record inaccessible subtrees instead of silently losing scope.
        try:
            unread.append(Path(exc.filename).relative_to(source).as_posix() + '/ [unreadable]')
        except (TypeError, ValueError):
            unread.append('[unreadable directory]')
    for directory, dirs, files in os.walk(source, followlinks=False, onerror=walk_error):
        base = Path(directory)
        for name in sorted(dirs):
            p = base / name
            if excluded(p.relative_to(source), cfg['exclude']) or linked(p):
                dirs.remove(name)
                omitted.append(p.relative_to(source).as_posix() + '/')
        dirs.sort()
        for name in sorted(files):
            p = base / name
            label = p.relative_to(source).as_posix()
            if excluded(p.relative_to(source), cfg['exclude']) or linked(p):
                omitted.append(label)
                continue
            size = p.stat().st_size
            if (p.suffix.lower() not in EXTENSIONS and name not in {'Dockerfile', 'Makefile'}) or size > cfg['max_file_bytes'] or size > budget or len(entries) >= cfg.get('max_files', 2000):
                unread.append(label)
                continue
            with p.open('rb') as stream:
                raw = stream.read(cfg['max_file_bytes'] + 1)
            if len(raw) > cfg['max_file_bytes'] or len(raw) > budget or b'\x00' in raw:
                unread.append(label)
                continue
            budget -= len(raw)
            entries.append({'path': label, 'sha256': hashlib.sha256(raw).hexdigest(), 'lines': len(raw.decode('utf-8', errors='replace').splitlines()), 'bytes': len(raw), 'documentation': p.suffix.lower() in {'.md', '.rst'}})
    return entries, omitted, unread

def validate(run):
    meta = json.loads((run / 'run.json').read_text(encoding='utf-8'))
    coverage = json.loads((run / 'coverage.json').read_text(encoding='utf-8'))
    indexed = {e['path']: e for e in meta['inventory']}
    errors = []
    for item in coverage['items']:
        if item['status'] not in {'covered', 'partial', 'missing', 'stale', 'unknown'}:
            errors.append('Invalid coverage status')
        if item['status'] != 'unknown' and not item.get('rationale'):
            errors.append('Semantic classification requires rationale')
        for evidence in item['evidence']:
            e = indexed.get(evidence['path'])
            if not e or evidence['sha256'] != e['sha256'] or not 1 <= evidence['start_line'] <= evidence['end_line'] <= e['lines']:
                errors.append('Invalid citation')
    for name in ('architecture', 'workflow'):
        text = (run / 'diagrams' / (name + '.mmd')).read_text(encoding='utf-8')
        if not text.startswith(('flowchart ', 'sequenceDiagram\n')):
            errors.append('Invalid diagram envelope')
    result = {'valid': not errors, 'errors': errors, 'semantic_review': 'pending', 'mermaid': {'parser': None, 'status': 'unvalidated'}}
    save(run / 'validation.json', result)
    return result

def execute(config, run_id, resume=False):
    cfg, source, output = configuration(config)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}', run_id):
        raise ValueError('Invalid run ID')
    output.mkdir(parents=True, exist_ok=True)
    run = output / run_id
    if run.exists() and (linked(run) or not resume):
        raise ValueError('Run exists; choose a new ID or explicitly resume')
    run.mkdir(exist_ok=True)
    if any(linked(p) for p in run.rglob('*')):
        raise ValueError('Run contains links; refusing writes')
    previous = None
    if resume:
        previous = json.loads((run / 'run.json').read_text(encoding='utf-8'))
        if previous['source_root'] != str(source) or previous['config'] != cfg or previous['status'] == 'completed':
            raise ValueError('Resume requires unchanged configuration and unfinished run')
    meta = {'schema_version': 1, 'status': 'running', 'source_root': str(source), 'source_revision': None, 'dirty': None, 'started_at': now(), 'finished_at': None, 'inspected_files': [], 'inventory': [], 'errors': [], 'config': cfg, 'stages': {s: 'pending' for s in STAGES}, 'limitations': [
        'Static inventory only; architecture, call chains and historical findings require semantic review.',
        'Revision and dirty state unknown: no repository commands executed.',
        'No model integration or network calls; source contents are not emitted.',
        'Mermaid parser unavailable; diagrams unvalidated.',
        'OS isolation is required for hostile sources; this is not a sandbox.',
        'Concurrent changes are not an atomic snapshot.']}
    if previous:
        entries, _, _ = inventory(source, cfg)
        if previous.get('inventory') != entries:
            raise ValueError('Source changed since checkpoint; create a new run')
    save(run / 'run.json', meta)
    try:
        entries, omitted, unread = inventory(source, cfg)
        meta['inventory'] = entries
        meta['inspected_files'] = [e['path'] for e in entries]
        meta['stages']['inventory'] = 'completed'
        save(run / 'run.json', meta)
        docs = [e['path'] for e in entries if e['documentation']]
        items = [{'id': e['path'], 'status': 'unknown', 'evidence': [] if not e['lines'] else [{'path': e['path'], 'start_line': 1, 'end_line': e['lines'], 'sha256': e['sha256']}], 'documentation': [], 'rationale': 'Inventory only; semantic documentation comparison pending.'} for e in entries]
        save(run / 'coverage.json', {'schema_version': 1, 'items': items, 'existing_documentation': docs, 'excluded_files': omitted, 'uninspected_files': unread})
        (run / 'diagrams').mkdir(exist_ok=True)
        (run / 'diagrams/architecture.mmd').write_text('flowchart LR\n  A[Inspected scope] --> B[Architecture unverified]\n', encoding='utf-8')
        (run / 'diagrams/workflow.mmd').write_text('sequenceDiagram\n  participant R as Reviewer\n  participant S as Static inventory\n  R->>S: Review required\n', encoding='utf-8')
        text = f'# Retrospective documentation checkpoint\n\nObserved scope: {len(entries)} bounded files; {len(docs)} existing documentation candidates.\n\n'
        for title in ('Revision', 'Architecture', 'Workflows', 'Interfaces', 'Data', 'Deployment', 'Security observations'):
            text += f'## {title}\nUnknown: semantic evidence review pending.\n\n'
        text += '## Documentation gaps\nAll items remain unknown. Generated files do not establish coverage.\n'
        text += 'Existing baseline absent.\n' if not docs else 'Existing documentation candidates listed in coverage.json; accuracy unverified.\n'
        text += '\n## Limitations\n' + '\n'.join('- ' + s for s in meta['limitations']) + '\n'
        (run / 'state-of-art.md').write_text(text, encoding='utf-8')
        for stage in STAGES[1:]:
            meta['stages'][stage] = 'review_required' if stage != 'diagrams' else 'unvalidated'
        result = validate(run)
        meta['status'] = 'partial' if result['valid'] else 'failed'
        meta['errors'] = result['errors']
    except (OSError, ValueError, KeyError) as exc:
        meta['status'] = 'failed'
        meta['errors'] = ['Stage failed: ' + type(exc).__name__]
    finally:
        meta['finished_at'] = now()
        save(run / 'run.json', meta)
    return run, 1 if meta['status'] == 'failed' else 3

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='config/agent.json')
    sub = parser.add_subparsers(dest='command', required=True)
    run = sub.add_parser('run')
    run.add_argument('--run-id', required=True)
    run.add_argument('--resume', action='store_true')
    serve = sub.add_parser('dashboard')
    serve.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    try:
        if args.command == 'dashboard':
            from .dashboard import serve_dashboard
            _, _, output = configuration(args.config)
            serve_dashboard(output, args.port)
            return 0
        path, code = execute(args.config, args.run_id, args.resume)
        print(f'{path} (exit {code}; partial means semantic review pending)')
        return code
    except (OSError, ValueError, KeyError) as exc:
        print('Configuration or run rejected: ' + str(exc))
        return 2
