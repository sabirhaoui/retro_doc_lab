# Twins Project review repository

Standalone, offline Python 3.10+ workbench. No external dependencies, downloads,
source execution, Git hooks, containers, network or model upload. Inspect the
current checkout read-only. Reports and UML are written only under `runs/`.

## First run

From this repository directory in PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\start-review.ps1
```

Default source: `C:\workspace\twins_project`. Override with `-Repo 'C:\other\repo'`.
Use `-PythonPath 'C:\Python\python.exe'` if Python is not on PATH.
Every run has a new ID. Exit 3 means the static scan succeeded but semantic review
remains pending; it is intentionally not a clean security/full-review verdict.

Direct CLI:

```powershell
python review.py scan --repo C:/workspace/twins_project --run-id review-001
python review.py validate --run runs/review-001
```

## Outputs

| Artifact | Contents |
|---|---|
| `dashboard.html` | Offline report dashboard; open directly in a browser |
| `model.json` | File hashes, relative evidence ranges, imports, classes, methods, functions, syntactic calls, unresolved dependencies |
| `architecture-components.puml` | UML components connected by resolved imports, including isolated files |
| `architecture-overview.puml` / `.svg` | Readable grouped component overview; SVG generated locally without external tools |
| `architecture-classes.puml` | Declared classes, Python methods and locally resolved inheritance |
| `authentication-observed-calls.puml` | Syntactic calls within authentication-related Python functions; no runtime order asserted |
| `authentication-review-sequence.puml` | Explicitly proposed verification sequence; not observed runtime behavior |
| `AUTHENTICATION.md` | Authentication signals, limits and prioritized verification/remediation actions |
| `ARCHITECTURE.md` | Dependency connections with citations |
| `api-catalog.json` | Python route handler declarations, methods and ranges; mounting/authorization unverified |
| `SCOPE.md` | Included/excluded/uninspected counts, parser failures, blind spots |
| `review.json` | Twelve review domains, authentication controls, historical findings and typed claims |
| `documentation-coverage.json` | Pre-existing documentation candidates; coverage starts unknown |
| `REVIEW-TASK.md` | Exhaustive semantic review procedure and final deliverable requirements |
| `run.json` | Checkpoint, timestamps, bounded-scan statistics and structured failures |

## Meaning of exhaustive

The scanner walks every nonexcluded directory and records every omitted or
unsupported file. Defaults: 20,000 included files, 2 MB per file, 200 MB total.
Raise `--max-files`, `--max-file-bytes`, or `--max-total-bytes` for a new run if
appropriate. Generated directories, secrets/credentials/token filenames,
symlinks/junctions and binary files remain excluded. This deliberately creates
blind spots (including possible authentication implementations in token-named
files); use separately sanitized input rather than removing safety exclusions.
Unsupported formats are inventoried as uninspected, not silently declared reviewed.
Python syntax failures and non-UTF8 decoding limitations require manual inspection.

Python uses AST parsing without importing source. TypeScript/JavaScript extraction
is conservative lexical analysis; comments/templates/aliases/decorators/dynamic
imports can yield omissions or false matches. Imports prove static dependencies,
not runtime interactions. No deployment topology, function effectiveness, API
exposure, tenant isolation or complete call-chain claim follows from matches alone.
UML is supplied as PlantUML source; a trusted local PlantUML renderer is not bundled
or automatically executed. Diagram generation is not parser/semantic validation.

## Completing the full review

Read `REVIEW-TASK.md` in the run and complete the evidence-backed `review.json`.
Authentication must cover account state, password/identity proof, signature and
claim validation, expiry, refresh/replay, revocation/logout, authorization,
workspace isolation, storage/cookies, CORS/CSRF, throttling, recovery/MFA and audit.
Confirm actual entrypoints and guards before drawing a final sequence diagram.
Separate verified gaps from review actions. Reconcile every historical finding if
baseline audits are supplied; historical input is not bundled here and its absence
must remain explicit. The original baseline remains in the parent lab output.

`historical-index.json` preserves the 57 historical IDs from the supplied audit
bundle as a revalidation queue, without copying raw audit contents. The baseline
paths refer to `../retro-doc-pipeline/baseline` in the parent lab output. Each ID
starts unverified and must be reconciled against current evidence; missing
original audit access remains a limitation when this repository is moved.

No remote source processing is authorized by default. Use a human reviewer or an
explicitly configured offline reviewer for the semantic stage. An offline scanner
alone cannot truthfully certify an exhaustive security assessment. Final review
requires the source-backed deliverables specified in `REVIEW-TASK.md`.
The validator checks hashes and citation ranges; it never proves a claim's meaning.
It deliberately returns partial even when structural checks pass.

## Tests

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
python -m unittest discover -s tests -v
```

Tests use synthetic inputs only. Test writes stay under this repository's `runs/`.
Source files, existing docs and historical audits remain unchanged. A malicious
concurrent filesystem writer can race a Python reader: use OS read-only/no-network
sandboxing for hostile repositories. No concurrent writers to the same run.

## Git

This is a portable repository source tree with `.gitignore`, tests and an agent
contract. Generated runs are ignored. Review before committing; no remote is set.
