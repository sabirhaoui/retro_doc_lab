# Inspected scope

1466 files inspected; 93 exclusions; 319 uninspected; 0 parse failures.

- No execution, dependency installation, network, model calls, or target-repository commands.
- Python AST and conservative TypeScript/JavaScript lexical extraction; no type checker or interprocedural proof.
- String/comment matching is not used as authentication effectiveness evidence.
- Imports are structural dependencies, not proof of runtime calls, data flow or deployed topology.
- Sensitive names and generated directories excluded before opening; embedded secrets are never printed.
- Filename exclusions may hide security implementation: all blind spots are recorded.
- No full PlantUML parser bundled; diagrams are textual UML and rendering remains unverified.
- Revision and dirty working tree unknown; inspected files have hashes.
- Existing docs are inventory candidates only; semantic comparison and historical findings require review.
- No runtime/deployment tests; absence of an identifier is not a vulnerability or remediation proof.

See model.json for every included/excluded/uninspected path and fingerprints.
