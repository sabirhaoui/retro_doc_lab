import json
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch
import review

class ReviewTests(unittest.TestCase):
    def setUp(self):
        (review.ROOT / 'runs').mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=review.ROOT / 'runs')
        self.base = Path(self.temp.name)
        self.repo = self.base / 'source'
        self.tool = self.base / 'reviewer'
        self.repo.mkdir()
        self.tool.mkdir()
        self.patch = patch.object(review, 'ROOT', self.tool)
        self.patch.start()
        (self.repo / 'main.py').write_text('from auth import login\nclass API:\n    def check(self):\n        return login()\n', encoding='utf-8')
        (self.repo / 'auth.py').write_text('def login():\n    return verify_password()\n', encoding='utf-8')
        (self.repo / 'README.md').write_text('Historical claim, unverified', encoding='utf-8')
        (self.repo / '.env.local').write_text('CREDENTIAL_NEVER_COPY', encoding='utf-8')
    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()
    def test_graph_uml_auth_and_immutable_source(self):
        before = {p: p.read_bytes() for p in self.repo.iterdir()}
        with patch('subprocess.run', side_effect=AssertionError('No execution')):
            run, code = review.scan(self.repo, 'test')
        self.assertEqual(code, 3)
        model = json.loads((run / 'model.json').read_text())
        self.assertEqual(model['edges'][0]['target'], 'auth.py')
        self.assertIn('C0', (run / 'architecture-classes.puml').read_text())
        self.assertIn('login', (run / 'authentication-observed-calls.puml').read_text())
        self.assertIn('proposal', (run / 'authentication-review-sequence.puml').read_text())
        ET.parse(run / 'architecture-overview.svg')
        self.assertIn('@startuml', (run / 'architecture-overview.puml').read_text())
        self.assertEqual(review.validate(run), 3)
        self.assertEqual(before, {p: p.read_bytes() for p in before})
        self.assertNotIn('CREDENTIAL_NEVER_COPY', ''.join(p.read_text() for p in run.iterdir()))
    def test_bounds_and_parse_failure(self):
        (self.repo / 'huge.py').write_text('x' * 500)
        (self.repo / 'bad.py').write_text('def (')
        run, _ = review.scan(self.repo, 'bounded', max_bytes=200)
        model = json.loads((run / 'model.json').read_text())
        self.assertIn('huge.py', model['uninspected_files'])
        self.assertIn('bad.py', model['parse_failures'])
    def test_drift_and_false_completion(self):
        run, _ = review.scan(self.repo, 'drift')
        data = json.loads((run / 'review.json').read_text())
        data['domains']['security']['status'] = 'complete'
        (run / 'review.json').write_text(json.dumps(data))
        self.assertEqual(review.validate(run), 2)
        (self.repo / 'auth.py').write_text('changed')
        self.assertEqual(review.validate(run), 2)
    def test_reject_overwrite_and_traversal(self):
        review.scan(self.repo, 'once')
        with self.assertRaises(FileExistsError): review.scan(self.repo, 'once')
        with self.assertRaises(ValueError): review.scan(self.repo, '../escape')
    def test_comment_and_literal_not_auth_proof(self):
        e = {'path': 'x.py', 'sha256': 'a', 'lines': 2}
        self.assertEqual(review.analyze(e, '# jwt login\nx = "verify_password"\n')['signals'], [])
    def test_ts_relative_import_and_inheritance(self):
        e = {'path': 'ui/app.ts', 'sha256': 'a', 'lines': 3}
        a = review.analyze(e, "import {Auth} from './auth';\nclass App extends Base {}\nlocalStorage.getItem('redacted');")
        self.assertEqual(review.resolve_import('ui/app.ts', a['imports'][0], {'ui/auth.ts'}), ['ui/auth.ts'])
        self.assertTrue(any(s['category'] == 'browser_storage' for s in a['signals']))

if __name__ == '__main__': unittest.main()
