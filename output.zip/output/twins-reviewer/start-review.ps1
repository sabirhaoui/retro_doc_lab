[CmdletBinding()]
param(
    [string]$Repo = 'C:\workspace\twins_project',
    [string]$PythonPath = 'python',
    [string]$RunId = ('review-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 6))
)
$ErrorActionPreference = 'Stop'
$previousBytecode = $env:PYTHONDONTWRITEBYTECODE
Push-Location -LiteralPath $PSScriptRoot
try {
    $env:PYTHONDONTWRITEBYTECODE = '1'
    & $PythonPath -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ required; set -PythonPath.' }
    & $PythonPath -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'Synthetic tests failed.' }
    & $PythonPath review.py scan --repo $Repo --run-id $RunId
    if ($LASTEXITCODE -notin @(0,3)) { throw 'Scan failed. Check runs/<run-id>/run.json.' }
    & $PythonPath review.py validate --run (Join-Path 'runs' $RunId)
    if ($LASTEXITCODE -notin @(0,3)) { throw 'Structural validation failed.' }
    Write-Host "Reports and UML: $(Join-Path $PSScriptRoot ('runs\' + $RunId))"
    Write-Host 'Open dashboard.html. Static scan complete; full semantic/security review pending.'
    Write-Host 'Follow REVIEW-TASK.md locally. Source has not been executed or uploaded.'
} finally {
    $env:PYTHONDONTWRITEBYTECODE = $previousBytecode
    Pop-Location
}
