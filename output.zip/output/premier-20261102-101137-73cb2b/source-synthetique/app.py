# Fixture synthetique : ne jamais executer.
def greeting():
    return 'demo'
