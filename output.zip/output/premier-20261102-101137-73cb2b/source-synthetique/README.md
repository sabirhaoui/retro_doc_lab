# Documentation synthetique
Comparaison semantique non realisee.
