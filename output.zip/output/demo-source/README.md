﻿Synthetic documentation baseline; semantic accuracy has not been assessed.
