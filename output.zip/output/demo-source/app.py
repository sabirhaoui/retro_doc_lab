﻿# Synthetic fixture only; do not execute.
 def_placeholder = "demo"
