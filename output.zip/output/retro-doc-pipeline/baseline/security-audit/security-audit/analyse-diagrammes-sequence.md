# Analyse des diagrammes de séquence existants d'Assystan

> **Source :** les diagrammes du dossier `architecture-audit/diagrams/` (audit du 2026-10-01) : `authentication/auth-flow.mmd`, `authentication/authentification.mmd`, `authentication/seq_diag.mmd`, `graph-flow.mmd`, `ai-rag-flow.mmd`, et `async-flow.mmd` (organigramme, pas une séquence).
> **Limite :** ces diagrammes sont des **documents**, pas le code. Une divergence entre deux diagrammes est un signal à vérifier, pas une preuve de défaut. Chaque point indique l'extrait de code qui permet de trancher.

---

## 1. Comment lire un diagramme de séquence d'Assystan

Chaque flux suit la même chaîne d'appel. Savoir où l'on se trouve dans la chaîne permet de repérer ce qui manque.

```
Utilisateur → composant Angular → service Angular → AuthInterceptor
   → routeur FastAPI → dépendances (get_current_user, rôles, ACL)
   → service métier → repository → PostgreSQL / Neo4j
```

Trois questions à se poser sur chaque flèche :
1. **Qui décide ?** (où est prise la décision d'authentification et d'autorisation)
2. **Qu'est-ce qui franchit une frontière ?** (navigateur vers API, API vers base, API vers système externe)
3. **Qu'est-ce qui est stocké, et où ?** (mémoire du navigateur, cookie, `localStorage`, PostgreSQL, Neo4j, Redis)

## 2. Inventaire

| Diagramme | Type | Flux illustré | Couches traversées |
|---|---|---|---|
| `authentification.mmd` | Séquence | Connexion, puis liste des utilisateurs (admin) | UI, AuthService, Interceptor, Router, Dépendances, Security, Service, PostgreSQL |
| `auth-flow.mmd` | Séquence | Connexion, appel protégé, refresh, logout | UI, Interceptor, API, PostgreSQL |
| `seq_diag.mmd` | Séquence | Invitation d'un utilisateur par un admin, puis activation | UI, AdminApiService, Router, Service, `user_repo`, PostgreSQL, EmailService |
| `graph-flow.mmd` | Séquence | Ouverture d'un workspace, expansion de nœuds, recherche | UI, API Studio v2, ACL, PostgreSQL, service Studio v2, Neo4j v2, retrieval, `graph_repo` v1 |
| `ai-rag-flow.mmd` | Séquence | Question à l'assistant (appel d'outils, retrieval, ERP, persistance) | UI, router Assystan, orchestrateur, agents, LLM gateway, outils, retrieval, Neo4j, ERP, PostgreSQL |
| `async-flow.mmd` | Organigramme | Jobs Celery, Beat, import ZIP en thread | API, Redis, worker, PostgreSQL, ERP, Neo4j |

## 3. Analyse diagramme par diagramme

### 3.1 `authentification.mmd` : connexion et liste des utilisateurs

**Séquence.**
- *Phase 1, connexion.* L'UI appelle `AuthService.login`, qui poste directement sur le routeur (`/identity/auth/login`). Le routeur demande à `IdentityService.authenticate_user` de lire l'utilisateur et vérifier le hash (`Security.verify_password`). **Le routeur lui-même** appelle ensuite `create_access_token` et `create_refresh_token`, puis répond avec le jeton d'accès dans le corps et le refresh dans un cookie HttpOnly. `AuthService` garde l'access token **en mémoire**.
- *Phase 2, liste des utilisateurs.* La requête passe par l'`AuthInterceptor`, qui ajoute `Authorization: Bearer`. Côté API : `Depends(get_current_user)`, décodage du jeton, lecture de l'utilisateur, puis `require_workspace_role` ou `require_system_admin`. Le service lit la table `users` paginée.

**Ce que ce diagramme apprend.**
- L'émission des jetons est dans le **routeur** (couche d'exposition) et non dans le service métier.
- La pagination est faite côté SQL (`LIMIT`, `OFFSET`).
- `list_users` reçoit un `workspace_id` : la liste serait donc **limitée à un workspace**.

**Ce qu'il omet ou rend ambigu.** L'étape « Current User (is_active=True) » suggère que le statut est vérifié, ce qui contredit `auth-flow.mmd` et ARCH-006 (voir écart D-02). La requête de connexion ne passe pas par l'intercepteur (D-03). Les routes commencent par `/identity/...` (D-01).

### 3.2 `auth-flow.mmd` : connexion, appel protégé, refresh, logout

**Séquence.** Connexion avec `withCredentials`, réponse avec jeton d'accès et `Set-Cookie` du refresh (HttpOnly, SameSite=Lax). Les appels protégés portent le Bearer ; `get_current_user` retrouve l'utilisateur par `sub`. Sur un access token expiré, l'intercepteur appelle le **refresh**, qui contrôle `is_active`, renvoie « nouveau access/refresh » et rejoue la requête. Au **logout**, seul le cookie est supprimé.

**Ce que ce diagramme apprend.**
- Le contrôle de statut existe au **login et au refresh**, pas à chaque requête (note du diagramme).
- Le refresh renvoie un nouveau jeton : une rotation existe peut-être, mais aucune **détection de réutilisation** ni **registre de sessions** n'est représentée.
- Le logout ne révoque rien côté serveur.

**Lien avec les findings :** SEC-003, BE-02, API-16.

### 3.3 `seq_diag.mmd` : invitation puis activation

**Séquence.**
- *Invitation.* L'admin ouvre « Nouvel utilisateur » ; `AdminApiService.addUser` poste sur `/api/v1/admin/users`. Le service vérifie l'unicité, insère l'utilisateur (`is_active=False`, mot de passe provisoire), fabrique `create_invite_token(user.name)` et renvoie `UserResponse` **avec `setup_link`**. Le **routeur** envoie ensuite l'e-mail **de façon synchrone** et répond 201.
- *Activation.* Le destinataire ouvre `setup-account?token=...` ; l'UI poste `{token, new_password}` sur `/api/v1/auth/setup-account`. Le service met à jour le hash et `is_active=True`.

**Ce que ce diagramme apprend.**
- Le statut du compte se résume à **un booléen** : « invité » et « désactivé » ne se distinguent pas.
- Le jeton d'invitation est dérivé du **nom** de l'utilisateur et **aucune étape de stockage, d'expiration ou de consommation** n'apparaît.
- L'e-mail est envoyé dans la requête HTTP : une panne SMTP bloque ou fait échouer la création.

**Ce qu'il omet.** Contrôle de l'expiration du jeton, usage unique, règles de mot de passe, réponse générique en cas d'échec. **Liens :** H-02, SEC-011, BE-04, API-06.

### 3.4 `graph-flow.mmd` : ouverture d'un workspace et recherche

**Séquence.** À l'ouverture, l'UI appelle `GET /api/v2/studio/workspaces/{id}/nodes/roots`. L'API demande à `identity.authorization` de vérifier l'accès (lecture de l'appartenance dans PostgreSQL), puis le service Studio v2 lit les racines dans Neo4j. L'expansion d'un nœud appelle `/nodes/{id}/children`, avec « vérifie droits puis délègue ». Une **recherche** passe par `retrieval.service`, qui essaie d'abord le modèle v2 (`Node/RELATES_TO`) et se **replie sur le modèle v1** (`WorkspaceDocument`, via `graph_repo`) si rien n'existe en v2.

**Ce que ce diagramme apprend.**
- **PostgreSQL décide, Neo4j exécute** : l'ACL et les métadonnées sont en SQL, les graphes en Neo4j ; ce ne sont pas des transactions distribuées (note du diagramme).
- Deux modèles de graphe coexistent, avec un **repli** automatique.
- Le chargement est paginé et lazy (racines, puis enfants).

**Ce qu'il omet ou simplifie.** Neo4j répond « à l'UI » (en réalité via l'API). Aucune ACL n'est dessinée entre `Retrieval` et `graph_repo` v1. Les droits sont vérifiés à deux endroits différents (D-05, D-06). **Lien :** H-01, BE-07, API-01.

### 3.5 `ai-rag-flow.mmd` : question à l'assistant

**Séquence.** L'UI envoie la question avec le workspace et le projet vers `/api/v1/assystan/chat` (ou en SSE). L'orchestrateur lit le contexte de session si demandé, choisit un agent via `AgentRouter` et la LLM gateway, puis l'agent exécute **jusqu'à 10 tours** : prompt, appels d'outils (retrieval avec ACL, ou ERP live), résultats réinjectés. Une synthèse finale produit réponse, confiance, citations et trace ; le tour est **persisté si `persist=true`**.

**Ce que ce diagramme apprend.**
- L'ACL est dans les **outils** (`AuthorizedAssystanTools`), pas visiblement au routeur.
- Retrieval graphe et outils ERP sont **partagés** avec les flux Studio et connecteurs.
- La boucle d'outils est bornée, mais chaque tour appelle le fournisseur LLM (coût et latence).

**Ce qu'il omet.** La copie **locale** de la conversation (`ChatStoreService`, `localStorage`), la résolution des identifiants ERP (`secret_ref`), la validation du workspace envoyé par le client, le format des erreurs d'outils. **Liens :** SEC-004, SEC-007, SEC-008, H-01. Le diagramme `seq-chat-assystan.mermaid` ajoute ces éléments.

### 3.6 `async-flow.mmd` : jobs et import ZIP (organigramme)

Deux circuits distincts : (1) Celery (job d'ingestion en base puis `.delay`, Beat pour mappings 23:00, snapshots 23:30 et alertes), dont le job d'ingestion est un **placeholder** qui renvoie SUCCESS ; (2) l'**import ZIP** en thread daemon avec un dictionnaire de statut en mémoire, qui synchronise Studio v2 puis écrit dans Neo4j et PostgreSQL. L'annulation de job ne révoque pas la tâche. **Liens :** ARCH-008, ARCH-011, SEC-010.

## 4. Lecture croisée

### 4.1 Composants communs à plusieurs flux

| Composant | Connexion | Admin | Invitation | Studio | Chat | Import ZIP |
|---|:-:|:-:|:-:|:-:|:-:|:-:|
| `AuthInterceptor` | (non montré) | oui | non montré | non montré | non montré | non montré |
| `get_current_user` | - | oui | - | implicite | implicite | implicite |
| ACL workspace | - | `require_workspace_role` | - | `identity.authorization` | `AuthorizedAssystanTools` | non montrée |
| PostgreSQL | utilisateurs | utilisateurs | utilisateurs | appartenance | session et chat | catalogue |
| Neo4j | - | - | - | graphes | via retrieval | synchronisation |
| Systèmes externes | - | - | SMTP | - | LLM, ERP | - |

### 4.2 Où la décision d'autorisation est prise

| Flux | Lieu de la décision | Remarque |
|---|---|---|
| Admin | `Depends(get_current_user)` puis `require_workspace_role` ou `require_system_admin` | Dans les dépendances FastAPI |
| Studio v2 (racines) | `identity.authorization`, appelé par l'API | Composant dédié |
| Studio v2 (enfants) | « le service vérifie les droits » | Dans le service métier |
| Chat | `AuthorizedAssystanTools` | Dans les outils, pas au routeur |
| Retrieval, repli v1 | non montrée | **Point critique (H-01)** |
| Import ZIP | non montrée | À vérifier |

**Lecture :** la décision d'autorisation est répartie en au moins **quatre endroits** (dépendances, composant dédié, services, outils). C'est le symptôme à vérifier pour BE-06 (« autorisation centralisée ») et la raison d'être du futur `AuthorizationService` unique.

### 4.3 Écarts entre diagrammes

| ID | Écart | Diagrammes | Impact | Pour trancher |
|---|---|---|---|---|
| D-01 | Préfixes de route : `/identity/auth/login`, `/identity/users` contre `/api/v1/auth/login` et `/api/v1/admin/users` | `authentification.mmd` contre les autres | Contrat d'API flou ; `/identity/...` est probablement un nom de module, pas une URL | `main.py` et l'OpenAPI |
| D-02 | Contrôle de `is_active` : suggéré après lecture de l'utilisateur, nié par la note du flux d'auth et par ARCH-006 | `authentification.mmd` contre `auth-flow.mmd` | Révocation d'accès (SEC-003) | `identity/dependencies.py` |
| D-03 | Connexion avec ou sans intercepteur | `authentification.mmd` contre `auth-flow.mmd` | Traitement de `withCredentials` et du header | `AuthInterceptor` |
| D-04 | Émission des jetons dans le routeur (et non dans le service) | `authentification.mmd` | Logique de sécurité dans la couche d'exposition | `identity/router.py:65-90` |
| D-05 | ACL vérifiée à des endroits différents selon le flux | graph, auth, ai | Duplication des contrôles (BE-06) | Dépendances, `authorization`, services |
| D-06 | ACL sur le repli v1 du retrieval : non montrée contre « avec ACL » | `graph-flow.mmd` contre `ai-rag-flow.mmd` | Contournement possible de l'isolation (H-01) | `retrieval/repository.py`, `graph_repo.py` |
| D-07 | Neo4j répond à l'UI : simplification qui masque le rôle de l'API | `graph-flow.mmd` | Fausse impression d'accès direct | Aucun, convention de dessin |
| D-08 | Jeton d'invitation dérivé du nom, sans stockage ni consommation ; `setup_link` renvoyé dans la réponse API ; pas d'expiration montrée | `seq_diag.mmd` | Rejeu et fuite du lien (H-02) | `create_invite_token`, `setup_account` |
| D-09 | E-mail envoyé de façon synchrone dans le routeur | `seq_diag.mmd` | Disponibilité (INT-CELERY-01) | `identity/router.py` |
| D-10 | Copie de la conversation en `localStorage` absente du diagramme IA | `ai-rag-flow.mmd` | Données dupliquées (SEC-008) | `chat-store.service.ts` |
| D-11 | Le workspace est fourni par le client ; son contrôle d'accès n'est montré que dans les outils | `ai-rag-flow.mmd` | Contrôle d'objet (API-01) | Router Assystan |
| D-12 | Outils ERP : ni ACL ni résolution d'identifiants montrées | `ai-rag-flow.mmd` | SEC-004, SEC-002 | `agent_context.py:74`, clients ERP |
| D-13 | Refresh qui « renvoie un nouvel access/refresh » : rotation sans détection de réutilisation ni registre | `auth-flow.mmd` | Vol de refresh (BE-02) | `identity/service.py:92-100` |

## 5. Carte des interactions entre flux

```mermaid
flowchart LR
    LOGIN["Connexion et refresh"] -->|"access token mémoire<br/>refresh cookie"| ICPT["AuthInterceptor"]
    ICPT --> GCU["get_current_user"]
    GCU --> ACL["ACL workspace"]

    ADMIN["Administration<br/>invitation, activation"] -->|"crée utilisateur"| PGU[("PostgreSQL<br/>users")]
    ADMIN -->|"e-mail synchrone"| SMTP["SMTP"]
    SMTP -.->|"lien d'activation"| LOGIN

    ACL --> STUDIO["Studio v2<br/>racines, enfants"]
    ACL --> CHAT["Chat Assystan"]
    STUDIO --> NEO[("Neo4j v2 et v1")]
    CHAT -->|"outil retrieval"| RET["Retrieval<br/>v2 puis v1"]
    RET --> NEO
    CHAT -->|"outil ERP"| ERPCLI["Clients P6 et Unifier"]
    CONN["Routes connecteurs"] --> ERPCLI
    ERPCLI --> ERP["ERP P6 / Unifier"]
    CHAT --> PGC[("PostgreSQL<br/>chat")]
    CHAT -->|"copie locale"| LS["localStorage"]
    CHAT --> LLM["LLM Gateway<br/>OpenAI"]

    ZIP["Import ZIP<br/>thread daemon"] -->|"sync"| STUDIO
    JOBS["Celery et Beat"] --> ERPCLI
    JOBS --> PGU
```

**Ce que la carte montre.**
- Le **retrieval** et les **clients ERP** sont des points de rencontre : ils sont utilisés par plusieurs flux, donc un défaut y a un effet transversal (SEC-002, H-01).
- L'**authentification** est le tronc commun : tout flux protégé passe par l'intercepteur puis `get_current_user`.
- Les **données** se rejoignent dans deux magasins (PostgreSQL et Neo4j) sans transaction commune.

## 6. Questions pour le code, par priorité

| Priorité | Question | Écarts concernés | Extrait à demander |
|---|---|---|---|
| 1 | L'ACL est-elle appliquée sur le repli v1 du retrieval et sur chaque requête Neo4j ? | D-05, D-06 | `retrieval/repository.py`, `graph_repo.py` |
| 2 | `get_current_user` contrôle-t-il `is_active` (et un `sid`) ? | D-02, D-13 | `identity/dependencies.py`, migration `0025` |
| 3 | Le workspace du chat est-il contrôlé dès le routeur ? | D-11 | routeur Assystan |
| 4 | Comment le jeton d'invitation est-il fabriqué, stocké, expiré, consommé ? | D-08 | `identity/service.py`, `setup_account` |
| 5 | Les URL réelles des routes ? | D-01 | `main.py`, OpenAPI |
| 6 | Les outils ERP résolvent-ils les identifiants et restreignent-ils les destinations ? | D-12 | `agent_context.py`, `p6_client.py`, `unifier_client.py` |
| 7 | Quel traitement fait l'`AuthInterceptor` du login et de `withCredentials` ? | D-03 | `AuthInterceptor` |

## 7. Conseils pour votre draw.io

- Un **calque par flux** (connexion, administration, Studio, chat, import ZIP, jobs).
- Reprenez les **noms de participants des diagrammes** pour que les trois sources se recoupent.
- Marquez en **orange** les écarts D-xx non tranchés ; passez-les en **vert** quand l'extrait de code les confirme.
- Pour D-05, dessinez une petite icône « décision d'autorisation » à chaque endroit où elle est prise : le nombre d'icônes donne la mesure de la dispersion.
- Ajoutez un trait distinct pour les flux qui franchissent une **frontière de confiance** (navigateur vers API, API vers ERP ou LLM).
