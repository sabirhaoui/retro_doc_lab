# SEC-003 - Access token accepté après désactivation ; pas de révocation serveur ; refresh de 14 jours
- **Composant :** Backend
- **Catégorie :** OWASP API 2023 API2 ; ASVS V3 ; **CWE :** CWE-613, CWE-324
- **Sévérité :** MOYENNE ; **Confiance :** élevée (sur le code audité) ; à reconfirmer sur le code actuel
- **Statut de preuve :** prouvé par le code (rapporté, E-006 et E-020)
- **Priorité :** P1 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** ARCH-006

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- `get_current_user` valide le JWT puis retourne l'utilisateur sans contrôler `is_active` (`backend/app/modules/identity/dependencies.py:24-43`).
- Login et refresh contrôlent `is_active` (`identity/service.py:50-56,92-100`).
- Valeurs par défaut : access 60 min, refresh 14 jours (README : 30 min et 7 jours) (`shared/config.py:97-101`).
- Le logout supprime le cookie sans révoquer le JWT côté serveur (`identity/router.py:65-90,115-157`).

Sources : S-003, S-004 (voir `evidence/ledger.md`).
- `backend/app/modules/identity/dependencies.py:24-43`
- `backend/app/modules/identity/service.py:50-56,92-100`
- `backend/app/modules/identity/router.py:65-90,115-157`
- `backend/app/modules/shared/config.py:97-101`

## Observation
Après désactivation d'un compte, les nouveaux login et refresh échouent, mais un access token non expiré reste accepté. Le refresh n'est pas révocable individuellement.

## Inférence
La désactivation prend effet à l'expiration du token (jusqu'à 60 minutes) et un refresh volé reste utilisable jusqu'à 14 jours tant que le compte reste actif.

## Scénario d'attaque (descriptif)
Préconditions : un compte désactivé conserve un access token valide (ou un refresh volé sur un compte actif). Point d'entrée : toute route protégée. Résultat : lecture et mutation dans les workspaces du compte pendant la fenêtre résiduelle.

## Impact
Intégrité et confidentialité : fenêtre d'accès après révocation ; borné par l'expiration ; aucune exploitation démontrée.

## Recommandation
- **Court terme :** Contrôler le statut du compte dans `get_current_user` ; test de désactivation après émission d'un token ; aligner README et valeurs réelles.
- **Structurelle :** Registre de sessions avec identifiant de session (`sid`), révocation à la désactivation, rotation du refresh avec détection de réutilisation, expirations d'inactivité et absolue (chantier branches FT-01 et FT-04).

## Contre-check
Le refresh refuse les comptes inactifs et l'expiration est finie : l'exposition est bornée. Le chantier en cours prévoit un registre de sessions (migration 0025, statut non vérifié) ; le document interne `diagrams/authentication/ReadMe.md` affirme que le contrôle `get_current_user` est « déjà traité », ce qui contredit l'audit : à trancher sur le code courant.

## Vérification
- T-04-003 (disabled avec access token émis avant : 401)
- T-01-004 (session révoquée : 401)
- T-07-007 et F-05 (désactivation en cours de session)

## Références
OWASP ASVS V3.3 ; RFC 8725 ; CWE-613
