# SEC-014 - DDL exécuté au démarrage : le compte applicatif porte vraisemblablement des droits de schéma
- **Composant :** Backend
- **Catégorie :** OWASP Top 10 A05 ; ASVS V1 ; **CWE :** CWE-250
- **Sévérité :** BASSE ; **Confiance :** faible
- **Statut de preuve :** inféré (E-009)
- **Priorité :** P3 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-009

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le démarrage exécute `create_all`, ajoute des colonnes manquantes et supprime une contrainte (`backend/app/core/database.py:15-38`, `backend/app/main.py:68-72`).
- La release applique aussi Alembic (`deploy/scripts/apply-release.sh:144`).

Sources : S-015 (voir `evidence/ledger.md`).
- `backend/app/core/database.py:15-38`
- `backend/app/main.py:68-72`

## Observation
Deux voies modifient le schéma dans le parcours normal.

## Inférence
Pour que le démarrage réussisse, le compte de base de données de l'application doit avoir des droits DDL ; une injection SQL aurait donc un impact accru.

## Scénario d'attaque (descriptif)
Préconditions : une injection SQL (non démontrée). Résultat : modification de schéma possible au lieu d'un accès limité aux données.

## Impact
Défense en profondeur ; aucune injection démontrée.

## Recommandation
- **Court terme :** Documenter les droits du compte applicatif.
- **Structurelle :** Séparer le compte de migration (DDL) du compte d'exécution (DML), supprimer le DDL de démarrage (chantier de convergence ARCH-009).

## Contre-check
Les droits réels du compte n'ont pas été vérifiés.

## Vérification
- Contrôle de configuration des privilèges (hors tests automatiques)

## Références
OWASP ASVS V1.4 ; CWE-250
