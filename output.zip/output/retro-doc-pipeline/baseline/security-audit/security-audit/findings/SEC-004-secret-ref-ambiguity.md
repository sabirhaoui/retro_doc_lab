# SEC-004 - `secret_ref` consommé comme token sans résolution de coffre
- **Composant :** Backend
- **Catégorie :** OWASP API 2023 API3 / API8 ; ASVS V6 ; **CWE :** CWE-522, CWE-312
- **Sévérité :** MOYENNE ; **Confiance :** élevée sur l'absence de résolution ; moyenne sur la valeur stockée
- **Statut de preuve :** prouvé par le code pour l'absence de résolveur ; nature de la valeur à confirmer (rapporté, E-007)
- **Priorité :** P1 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-007

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le schéma décrit `secret_ref` comme pointeur de coffre non secret (`backend/app/modules/connectors/catalog_schemas.py:50-64`).
- Les consommateurs copient la chaîne dans `credentials["token"]` (`assystan/orchestration/agent_context.py:74`, `entity_mappings/service.py:74`).
- La colonne est une chaîne SQL (`backend/app/models/orm/connector.py:39`).

Sources : S-005 (voir `evidence/ledger.md`).
- `backend/app/modules/connectors/catalog_schemas.py:50-64`
- `backend/app/modules/assystan/orchestration/agent_context.py:74`
- `backend/app/modules/entity_mappings/service.py:74`
- `backend/app/models/orm/connector.py:39`

## Observation
Aucun adaptateur de coffre ni chiffrement n'a été observé dans les chemins examinés.

## Inférence
Soit la valeur stockée est un vrai identifiant ERP en clair dans PostgreSQL (donc dans les sauvegardes), soit l'intégration envoie une référence comme token. La sévérité passerait à HAUTE si la valeur est un secret réel et si l'API la renvoie à des utilisateurs non administrateurs.

## Scénario d'attaque (descriptif)
Préconditions : accès à une sauvegarde de base ou à la réponse du catalogue de connecteurs. Résultat : lecture d'identifiants ERP.

## Impact
Confidentialité : identifiants ERP ; rotation et audit difficiles ; aucune exploitation démontrée.

## Recommandation
- **Court terme :** Confirmer immédiatement ce que contient la colonne en production ; ne jamais renvoyer la valeur dans les réponses du catalogue.
- **Structurelle :** Décider du contrat : résolveur de coffre avec stockage de références uniquement, ou chiffrement applicatif avec renommage de la propriété.

## Contre-check
Le nom `secret_ref` n'est pas une preuve de coffre externe ; un sidecar ou un coffre hors dépôt reste possible. Le champ est renvoyé par l'API sous ce nom, sans preuve de son contenu.

## Vérification
- Nouveau T-SEC-004 : tracer un credential factice jusqu'au client ERP et vérifier qu'un résolveur est appelé
- Nouveau T-SEC-005 : la réponse du catalogue ne contient aucune valeur secrète

## Références
OWASP ASVS V6.4 ; CWE-522
