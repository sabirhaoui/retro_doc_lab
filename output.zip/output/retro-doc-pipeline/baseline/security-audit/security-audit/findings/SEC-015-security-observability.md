# SEC-015 - Observabilité de sécurité : journal d'audit des événements d'accès non identifié
- **Composant :** Backend
- **Catégorie :** OWASP Top 10 A09 ; ASVS V7 ; **CWE :** CWE-778
- **Sévérité :** INFO ; **Confiance :** faible
- **Statut de preuve :** absence d'observation dans le périmètre consulté (non une preuve d'absence)
- **Priorité :** P3 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Middleware `X-Correlation-ID` et logging structuré présents (`backend/app/modules/shared/middleware.py`, `shared/logging.py`).
- `/health` renvoie une réponse fixe (`backend/app/main.py:139-141`).
- Aucun APM ni alerte identifiés ; le contenu des logs n'a pas été audité.

Sources : S-016, S-020 (voir `evidence/ledger.md`).
- `backend/app/modules/shared/middleware.py`
- `backend/app/main.py:139-141`

## Observation
Aucun journal d'audit dédié aux connexions, refus d'accès et changements de droits n'a été identifié dans les documents.

## Inférence
La détection d'abus (échecs de connexion répétés, refus de licence) dépend de l'existence de ces événements, non confirmée.

## Scénario d'attaque (descriptif)
Sans objet : constat de maturité.

## Impact
Capacité de détection et d'enquête.

## Recommandation
- **Court terme :** Confirmer l'existence d'événements d'audit d'authentification.
- **Structurelle :** Journal d'audit des événements de sécurité (chantier : registre de sessions et audit), corrélé par `request_id`.

## Contre-check
Le registre de sessions et l'audit du chantier en cours peuvent déjà répondre à ce point (non inclus dans le zip).

## Vérification
- T-01-009 (événements d'audit de login)
- T-06-007 (audit des refus de licence)

## Références
OWASP ASVS V7 ; CWE-778
