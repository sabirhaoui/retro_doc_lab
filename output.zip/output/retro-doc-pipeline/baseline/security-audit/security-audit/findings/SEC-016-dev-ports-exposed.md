# SEC-016 - Ports des datastores publiés dans le Compose de développement
- **Composant :** Infra
- **Catégorie :** OWASP Top 10 A05 ; **CWE :** CWE-1327
- **Sévérité :** INFO ; **Confiance :** élevée
- **Statut de preuve :** prouvé par la configuration (rapporté, 14-runtime)
- **Priorité :** P3 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le Compose de développement publie Postgres (5433), Neo4j (7474, 7687) et Redis (6379).

Sources : S-017 (voir `evidence/ledger.md`).
- `docker-compose.yml`

## Observation
Le Compose de production ne publie aucun datastore et lie backend et frontend à `127.0.0.1`.

## Inférence
Sur un poste de développement sur un réseau non maîtrisé, ces ports peuvent être accessibles ; l'authentification de Redis n'est pas établie.

## Scénario d'attaque (descriptif)
Préconditions : poste de développement sur un réseau partagé. Résultat : accès aux bases de développement.

## Impact
Limité aux données de développement.

## Recommandation
- **Court terme :** Lier les ports de développement à `127.0.0.1`.
- **Structurelle :** Documenter que le Compose de développement n'est pas destiné à un hôte exposé.

## Contre-check
Le point est déjà noté dans l'audit d'architecture comme devant « rester explicitement local ».

## Vérification
- Contrôle statique du Compose de développement

## Références
OWASP Top 10 A05
