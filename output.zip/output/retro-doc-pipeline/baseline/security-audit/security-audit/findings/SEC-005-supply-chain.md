# SEC-005 - Chaîne d'approvisionnement : dépendances non épinglées, aucun scan, SBOM ni signature
- **Composant :** Infra
- **Catégorie :** OWASP Top 10 A06 / A08 ; **CWE :** CWE-1104, CWE-494
- **Sévérité :** MOYENNE ; **Confiance :** élevée sur l'absence observée
- **Statut de preuve :** prouvé par la configuration (rapporté, E-026 et 13-devops)
- **Priorité :** P2 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Exigences Python partiellement en `>=`, aucun lockfile Python recensé (`backend/requirements.txt`, `backend/pyproject.toml`).
- Images à tags mobiles : `python:3.11-slim`, `node:22-alpine`, `nginx:alpine`, `postgres:15-alpine`, `redis:7-alpine`.
- Aucun scan d'image, SBOM, signature ou provenance dans le YAML ni les scripts consultés ; CI en Node 24, image prod en Node 22.

Sources : S-006 (voir `evidence/ledger.md`).
- `backend/requirements.txt`
- `backend/pyproject.toml`
- `azure-pipelines.yml:26,98`
- `frontend/Dockerfile.prod:1`

## Observation
Deux builds identiques à des dates différentes peuvent produire des artefacts différents ; aucune vérification de vulnérabilité n'est branchée au pipeline.

## Inférence
Une dépendance compromise ou vulnérable peut entrer en production sans détection par le pipeline.

## Scénario d'attaque (descriptif)
Préconditions : publication d'une version malveillante ou vulnérable d'une dépendance non épinglée. Point d'entrée : le prochain build CD. Résultat : code tiers non revu dans l'image déployée.

## Impact
Intégrité et confidentialité du backend ; probabilité faible, impact potentiellement élevé.

## Recommandation
- **Court terme :** Épingler les dépendances Python (fichier de verrouillage avec hachages) ; épingler les images par digest ; ajouter `pip-audit`, `npm audit` et un scan d'image à la CI.
- **Structurelle :** SBOM et signature des images ; automatisation des mises à jour avec revue ; alignement des versions de Node.

## Contre-check
`frontend/package-lock.json` existe et la CI utilise `npm ci` : le frontend est reproductible. Aucun résultat de scan n'est disponible : l'existence de vulnérabilités connues n'est ni affirmée ni exclue.

## Vérification
- Nouveau T-SEC-006 : job CI qui échoue sur une vulnérabilité connue de gravité haute
- T-00-001 à T-00-007 (socle CI)

## Références
OWASP Top 10 A06, A08 ; SLSA
