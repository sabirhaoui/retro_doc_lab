# SEC-007 - Sorties d'outils réinjectées comme messages `user` ; erreurs d'outils exposées ; pas de test d'injection de prompt
- **Composant :** Backend (IA)
- **Catégorie :** OWASP LLM Top 10 (LLM01, LLM02) ; OWASP API 2023 API10 ; **CWE :** CWE-74, CWE-209
- **Sévérité :** MOYENNE ; **Confiance :** moyenne
- **Statut de preuve :** inféré à partir de la conception rapportée (E-024)
- **Priorité :** P2 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le résultat d'un outil est réinjecté comme message `user` (`backend/app/modules/assystan/agents/tool_loop_engine.py:148-177`).
- Les erreurs d'outils deviennent `{error: str(exc)}` et sont visibles du modèle.
- La boucle est bornée à 10 rounds ; les outils graphe passent par `AuthorizedAssystanTools` qui impose l'ACL de workspace.
- Aucun test adversarial (injection de prompt, exfiltration par outil) n'a été identifié dans le périmètre consulté.

Sources : S-008 (voir `evidence/ledger.md`).
- `backend/app/modules/assystan/agents/tool_loop_engine.py:9-11,96,148-177`
- `backend/app/modules/llm_gateway/interfaces.py`

## Observation
La frontière de provenance entre instructions de l'utilisateur et données récupérées (graphes, documents) n'est pas matérialisée dans l'historique envoyé au modèle.

## Inférence
Un contenu de graphe ou de document contrôlé par un utilisateur peut contenir des instructions que le modèle traite comme venant de l'utilisateur, avec pour limite les outils autorisés par l'ACL. Les messages d'exception peuvent révéler des détails internes.

## Scénario d'attaque (descriptif)
Préconditions : un utilisateur peut écrire du contenu consulté ensuite par un autre (libellé, propriété ou document). Résultat : influence de la réponse, tentative d'appels d'outils, ou fuite de détails internes via les erreurs.

## Impact
Intégrité des réponses et confidentialité limitée par l'ACL ; l'impact maximal dépend des outils exposés (lecture ERP, retrieval).

## Recommandation
- **Court terme :** Ne pas renvoyer `str(exc)` au modèle ni à l'utilisateur ; marquer les sorties d'outils comme données non fiables.
- **Structurelle :** Rôle `tool` standard avec identifiants d'appel ; validation des arguments et des réponses par schémas ; bornes de temps et de coût ; tests adversariaux d'injection et d'exfiltration.

## Contre-check
L'ACL est refaite dans les outils et la boucle est bornée : l'impact est limité aux données déjà accessibles à l'appelant. L'exploitabilité réelle n'a pas été testée.

## Vérification
- Nouveau T-SEC-007 : corpus d'entrées d'injection de prompt dans des libellés de nœuds ; aucun appel d'outil non demandé
- Nouveau T-SEC-008 : une exception d'outil ne contient pas de détail interne dans la réponse utilisateur

## Références
OWASP LLM Top 10 ; CWE-209
