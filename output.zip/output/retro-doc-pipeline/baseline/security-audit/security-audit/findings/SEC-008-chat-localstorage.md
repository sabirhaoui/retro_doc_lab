# SEC-008 - Historique de chat métier conservé en `localStorage`
- **Composant :** Frontend
- **Catégorie :** OWASP Top 10 A02 / A04 ; ASVS V8 ; **CWE :** CWE-922
- **Sévérité :** MOYENNE ; **Confiance :** élevée
- **Statut de preuve :** prouvé par le code (rapporté, E-012)
- **Priorité :** P2 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-012

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- `ChatStoreService` sérialise toutes les conversations en JSON dans `localStorage` (`frontend/src/app/services/chat-store.service.ts:15-17,165`).
- Le backend persiste aussi sessions, messages et citations.

Sources : S-009 (voir `evidence/ledger.md`).
- `frontend/src/app/services/chat-store.service.ts:15-17,165`

## Observation
Contenu de projet, questions, réponses et extraits peuvent rester dans le profil du navigateur de façon durable.

## Inférence
Un XSS sur l'origine ou un poste partagé permet la lecture des conversations ; la suppression serveur et l'effacement local peuvent diverger.

## Scénario d'attaque (descriptif)
Préconditions : poste partagé ou exécution de script sur l'origine. Résultat : lecture de conversations contenant des données de projet.

## Impact
Confidentialité des données métier ; conformité à la politique de rétention.

## Recommandation
- **Court terme :** Ne plus persister l'historique en `localStorage` ou le limiter et l'effacer à la déconnexion.
- **Structurelle :** Le backend est la source de vérité de l'historique ; rétention et suppression centralisées.

## Contre-check
Le token d'accès n'est pas en `localStorage` (mémoire) et le refresh est HttpOnly : l'exposition porte sur l'historique, pas sur les jetons.

## Vérification
- Nouveau T-SEC-009 : après logout, `localStorage` ne contient aucune conversation
- T-11-007 (aucune donnée de l'ancien utilisateur après changement)

## Références
OWASP ASVS V8.2 ; CWE-922
