# SEC-013 - Origines CORS codées en dur, variable `CORS_ORIGINS` non consommée
- **Composant :** API
- **Catégorie :** OWASP API 2023 API8 ; **CWE :** CWE-942
- **Sévérité :** BASSE ; **Confiance :** élevée
- **Statut de preuve :** prouvé par le code (rapporté, E-017)
- **Priorité :** P3 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- `main.py` utilise des origines locales codées en dur ; `CORS_ORIGINS` existe dans la configuration et l'exemple de production mais n'est pas lue à cet endroit (`backend/app/main.py:43-50`).

Sources : S-014 (voir `evidence/ledger.md`).
- `backend/app/main.py:43-50`
- `backend/app/modules/shared/config.py`

## Observation
Les origines sont explicites (pas de joker), ce qui est positif ; le contrat de configuration est incohérent.

## Inférence
En production à même origine via Caddy, CORS n'est pas nécessaire. Un changement de topologie obligerait à modifier le code, avec le risque d'un contournement par un joker.

## Scénario d'attaque (descriptif)
Préconditions : futur changement d'origine. Résultat : régression fonctionnelle ou assouplissement non maîtrisé.

## Impact
Faible, défense en profondeur.

## Recommandation
- **Court terme :** Lire `CORS_ORIGINS` depuis la configuration et refuser `*` avec identifiants.
- **Structurelle :** Test de contrat sur les en-têtes CORS par environnement.

## Contre-check
Une topologie à même origine rend le sujet sans effet en production.

## Vérification
- Nouveau T-SEC-011 : en-têtes CORS conformes par environnement

## Références
OWASP API Security 2023 API8
