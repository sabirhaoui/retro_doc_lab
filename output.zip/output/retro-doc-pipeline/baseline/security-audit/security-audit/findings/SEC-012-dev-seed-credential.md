# SEC-012 - Mot de passe administrateur de démonstration publié (mode développement)
- **Composant :** Backend
- **Catégorie :** OWASP Top 10 A07 ; ASVS V2 ; **CWE :** CWE-798
- **Sévérité :** BASSE ; **Confiance :** élevée
- **Statut de preuve :** prouvé par le code (rapporté, E-027) ; valeur volontairement omise
- **Priorité :** P3 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** ARCH-015

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le credential est dans le chemin de seed conditionné à `APP_ENV == development` (`backend/seed_db.py:54-65`) et documenté (`README.md:278`).
- Le Compose de production fixe `APP_ENV=production`.

Sources : S-013 (voir `evidence/ledger.md`).
- `backend/seed_db.py:54-65`
- `README.md:278`

## Observation
Aucun accès à la production par ce chemin n'est démontré.

## Inférence
Une erreur d'environnement (seed lancé en mode développement sur un environnement exposé) créerait un compte administrateur connu.

## Scénario d'attaque (descriptif)
Préconditions : environnement de staging ou de développement exposé et seed exécuté. Résultat : accès administrateur.

## Impact
Limité aux environnements non production mal configurés.

## Recommandation
- **Court terme :** Retirer la valeur du README ; générer un mot de passe aléatoire au seed.
- **Structurelle :** Garde dans le code qui refuse le seed hors liste d'environnements locaux explicites.

## Contre-check
La condition `APP_ENV` et le script `create-first-admin.sh` (secret temporaire) en production réduisent fortement le risque.

## Vérification
- Test du seed sous `APP_ENV=development` et `production` sur base jetable

## Références
OWASP ASVS V2.1.1 ; CWE-798
