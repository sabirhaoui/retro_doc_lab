# SEC-006 - Déploiement automatique par SSH sur push `dev`, sans approbation visible
- **Composant :** Infra
- **Catégorie :** OWASP Top 10 A08 ; CI/CD ; **CWE :** CWE-284
- **Sévérité :** MOYENNE ; **Confiance :** moyenne (gate externe possible)
- **Statut de preuve :** prouvé par le YAML ; absence d'approbation à confirmer dans Azure DevOps (rapporté, E-013)
- **Priorité :** P2 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** ARCH-013

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le stage `CD` se déclenche sur un push réussi sur `dev` hors PR : build des images, installation d'une clé SSH, transfert et application de la release (`azure-pipelines.yml:2,148-156`).
- Le README et le TODO déclarent « pas de CD ».

Sources : S-007 (voir `evidence/ledger.md`).
- `azure-pipelines.yml:2,148-156`
- `README.md:348`

## Observation
Le YAML consulté n'exprime aucune approbation d'environnement.

## Inférence
Un merge sur `dev` peut modifier l'environnement cible sans validation humaine supplémentaire ; un compte pouvant fusionner sur `dev` obtient un effet de déploiement.

## Scénario d'attaque (descriptif)
Préconditions : droit de fusionner sur `dev` (ou contournement des politiques de branche). Résultat : code déployé sur l'hôte via la clé SSH du pipeline.

## Impact
Intégrité de l'environnement cible ; dépend des protections de branche et des gates Azure.

## Recommandation
- **Court terme :** Confirmer ou ajouter une approbation sur l'environnement Azure ; appliquer les politiques de branche prévues pour `dev` ; aligner README et TODO.
- **Structurelle :** Environnements Azure avec approbateurs, clés SSH à portée minimale et rotation, journal de déploiement.

## Contre-check
Une approbation peut être configurée dans Azure DevOps (hors YAML) : c'est une hypothèse non vérifiable depuis le zip.

## Vérification
- Contrôle de configuration Azure (hors tests automatiques)
- T-00-007 (le CD ne se déclenche pas si la CI échoue)

## Références
OWASP CI/CD Security Top 10 (CICD-SEC-1)
