# SEC-002 - Destinations HTTP fournies par l'appelant pour les connecteurs (SSRF) et TLS désactivable
- **Composant :** API + Backend
- **Catégorie :** OWASP API 2023 API7 / API5 ; OWASP Top 10 A10 ; **CWE :** CWE-918, CWE-295
- **Sévérité :** HAUTE ; **Confiance :** moyenne
- **Statut de preuve :** prouvé par le code pour le chemin d'appel ; exploitabilité dépendante du réseau (rapporté, E-005)
- **Priorité :** P1 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-005

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Les routes de test et de lecture P6/Unifier acceptent `base_url` dans le corps ou la query (`backend/app/modules/connectors/router.py:304-314,363-403,467-522`).
- Les clients appellent l'URL fournie avec `urlopen` (`p6_client.py:184`, `unifier_client.py:172`) ; aucune validation de destination observée.
- Les routes de test acceptent `insecure`, qui désactive la vérification TLS ; elles sont ouvertes à tout utilisateur authentifié.

Sources : S-002 (voir `evidence/ledger.md`).
- `backend/app/modules/connectors/router.py:304-314,363-403,467-522`
- `backend/app/modules/connectors/p6_client.py:184`
- `backend/app/modules/connectors/unifier_client.py:172`

## Observation
Le repli évite d'envoyer les identifiants enregistrés vers une URL différente, mais l'URL fournie par l'utilisateur reste utilisée.

## Inférence
Le backend peut servir de relais HTTP vers des hôtes internes joignables depuis le conteneur (services d'administration, métadonnées cloud) ; l'option `insecure` facilite l'interception sur une destination choisie.

## Scénario d'attaque (descriptif)
Préconditions : un compte authentifié de base. Point d'entrée : une route de test de connexion avec une `base_url` interne. Étapes : le backend émet la requête depuis son réseau ; la réponse ou l'erreur renseigne l'appelant sur le service interne. Résultat : cartographie ou accès indirect à des services non exposés.

## Impact
Confidentialité et intégrité : accès indirect à des services internes ; tenants : tous (le backend est partagé) ; aucune exploitation démontrée.

## Recommandation
- **Court terme :** Réserver ces routes aux administrateurs ; refuser `insecure` hors configuration d'environnement ; valider schéma, port et hôte avant l'appel.
- **Structurelle :** Allowlist de connecteurs administrés ; résolution DNS puis blocage des plages loopback, link-local, privées et métadonnées ; suivi des redirections ; allowlist d'egress au niveau réseau.

## Contre-check
Les routes exigent un JWT et le repli ne transmet pas les secrets stockés à une autre URL. Un filtrage d'egress (pare-feu, Caddy) pourrait limiter l'impact : non vérifié, hors dépôt. D'où la confiance « moyenne ».

## Vérification
- Nouveau T-SEC-002 : tests unitaires de validation d'URL (IPv4/IPv6, redirections, DNS rebinding, métadonnées)
- T-07-002 adapté : un membre non admin reçoit 403 sur les routes de test de connecteur

## Références
OWASP API Security 2023 API7 ; CWE-918 ; CWE-295
