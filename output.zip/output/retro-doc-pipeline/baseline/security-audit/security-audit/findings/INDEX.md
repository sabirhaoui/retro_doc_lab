# Index des findings de sécurité

| ID | Titre | Composant | Sévérité | Priorité | Confiance | Preuve | Fiche ARCH liée |
|---|---|---|---|---|---|---|---|
| SEC-001 | Identifiants ERP transportés dans les URL (query strings) | API + Frontend | HAUTE | P1 | élevée | prouvé par le code | ARCH-004 |
| SEC-002 | Destinations HTTP fournies par l'appelant pour les connecteurs (SSRF) et TLS désactivable | API + Backend | HAUTE | P1 | moyenne | prouvé par le code pour le chemin d'appel ; exploitabilité dépendante du réseau | ARCH-005 |
| SEC-003 | Access token accepté après désactivation ; pas de révocation serveur ; refresh de 14 jours | Backend | MOYENNE | P1 | élevée (sur le code audité) ; à reconfirmer sur le code actuel | prouvé par le code | ARCH-006 |
| SEC-004 | `secret_ref` consommé comme token sans résolution de coffre | Backend | MOYENNE | P1 | élevée sur l'absence de résolution ; moyenne sur la valeur stockée | prouvé par le code pour l'absence de résolveur ; nature de la valeur à confirmer | ARCH-007 |
| SEC-005 | Chaîne d'approvisionnement : dépendances non épinglées, aucun scan, SBOM ni signature | Infra | MOYENNE | P2 | élevée sur l'absence observée | prouvé par la configuration | — |
| SEC-006 | Déploiement automatique par SSH sur push `dev`, sans approbation visible | Infra | MOYENNE | P2 | moyenne (gate externe possible) | prouvé par le YAML ; absence d'approbation à confirmer dans Azure DevOps | ARCH-013 |
| SEC-007 | Sorties d'outils réinjectées comme messages `user` ; erreurs d'outils exposées ; pas de test d'injection de prompt | Backend (IA) | MOYENNE | P2 | moyenne | inféré à partir de la conception rapportée | — |
| SEC-008 | Historique de chat métier conservé en `localStorage` | Frontend | MOYENNE | P2 | élevée | prouvé par le code | ARCH-012 |
| SEC-009 | Pas de sauvegarde Neo4j avant migration (résilience et intégrité) | Infra | MOYENNE | P1 | moyenne | prouvé par les scripts consultés ; procédures externes possibles | ARCH-010 |
| SEC-010 | Import ZIP en mémoire dans un thread du processus API, sans limite d'upload observée | API + Backend | MOYENNE | P2 | faible à moyenne | inféré | ARCH-011 |
| SEC-011 | Mot de passe provisoire constant pour les comptes invités | Backend | BASSE | P3 | moyenne | inféré à partir d'un document interne non audité | — |
| SEC-012 | Mot de passe administrateur de démonstration publié (mode développement) | Backend | BASSE | P3 | élevée | prouvé par le code | ARCH-015 |
| SEC-013 | Origines CORS codées en dur, variable `CORS_ORIGINS` non consommée | API | BASSE | P3 | élevée | prouvé par le code | — |
| SEC-014 | DDL exécuté au démarrage : le compte applicatif porte vraisemblablement des droits de schéma | Backend | BASSE | P3 | faible | inféré | ARCH-009 |
| SEC-015 | Observabilité de sécurité : journal d'audit des événements d'accès non identifié | Backend | INFO | P3 | faible | absence d'observation dans le périmètre consulté | — |
| SEC-016 | Ports des datastores publiés dans le Compose de développement | Infra | INFO | P3 | élevée | prouvé par la configuration | — |

Répartition : HAUTE 2, MOYENNE 8, BASSE 4, INFO 2. Aucun CRITIQUE.

## Hypothèses à vérifier (non retenues comme findings)

| ID | Hypothèse | Pourquoi | Comment la lever |
|---|---|---|---|
| H-01 | Contournement possible de l'ACL de workspace par les chemins Studio v1 (`graph_repo`) ou par des identifiants de graphe/nœud. | Retrieval essaie v2 puis v1 ; deux dépôts Neo4j aux labels différents ; ACL refaite outil par outil (E-019). | Lire `retrieval/repository.py`, `graph_repo.py` et chaque requête Cypher ; tests T-09-002 à T-09-005. |
| H-02 | Activation de compte (jeton ou setup-account), e-mail d'invitation et courses : jetons non hachés, rejouables, e-mail synchrone qui échoue en 500. | Code non fourni ; document interne seul (S-012). | Lire `identity/service.py`, `user_repo.py`, `email_service.py` ; tests T-04-005 à T-04-013. |
| H-03 | Routes legacy encore exposées (`app/api/`, `dependencies/`) sans les contrôles du chemin actif. | Usage résiduel non tracé (01-repository-map). | Comparer l'OpenAPI généré aux routeurs actifs de `main.py`. |
| H-04 | Injection SQL ou Cypher par construction de requêtes avec des entrées. | Repositories « non uniformes » (04-backend). | `semgrep`, `bandit`, revue des f-strings dans les repositories. |
| H-05 | Flux OAuth Microsoft sans validation du tenant, de l'issuer, de l'audience, du `nonce` ou PKCE ; auto-activation de comptes inactifs. | Seul le `state` est documenté (S-018). | Lire `identity/service.py` et le callback ; tests T-08-001 à T-08-006. |
| H-06 | Dernier administrateur supprimable ou rétrogradable ; admin plateforme avec accès implicite aux workspaces. | Règle non documentée. | Lire les routes `/admin/users` ; tests T-07-009 et T-09-010. |
| H-07 | XSS via libellés ou propriétés de nœuds (WebGL/DOM), markdown du chat ou réponses LLM rendues sans échappement. | Aucune recherche d'`innerHTML` ni de `bypassSecurityTrust*` possible sans le code. | `grep` de ces motifs ; revue des composants de chat et de graphe. |
| H-08 | En-têtes de sécurité (CSP, HSTS, anti-clickjacking), taille de corps, journalisation des URL, exposition de `/docs` au niveau de Caddy. | Caddy hors dépôt. | Obtenir la configuration Caddy de production. |
