# SEC-001 - Identifiants ERP transportés dans les URL (query strings)
- **Composant :** API + Frontend
- **Catégorie :** OWASP API 2023 API2 / API8 ; ASVS V3 et V8 ; **CWE :** CWE-598
- **Sévérité :** HAUTE ; **Confiance :** élevée
- **Statut de preuve :** prouvé par le code (rapporté par l'audit d'architecture, E-004 ; non revérifié ici)
- **Priorité :** P1 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** ARCH-004

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le client Angular construit des `HttpParams` `token`, `username`, `password` pour les GET de découverte de projets et de BP (`frontend/src/app/services/api.service.ts:84-116`).
- Les routes FastAPI correspondantes les déclarent en `Query` (`backend/app/modules/connectors/router.py:363-403,512-522`).

Sources : S-001 (voir `evidence/ledger.md`).
- `frontend/src/app/services/api.service.ts:84-116`
- `backend/app/modules/connectors/router.py:363-403,512-522`

## Observation
Une query string apparaît dans l'URL du navigateur, les journaux d'accès du proxy, les traces et les captures réseau. Les POST de test de connexion n'ont pas ce défaut ; les GET de lecture l'ont.

## Inférence
Des identifiants ERP (comptes de service) peuvent survivre à la requête dans des journaux (Caddy, Nginx, APM) ou être partagés involontairement par copie d'URL.

## Scénario d'attaque (descriptif)
Préconditions : un opérateur ou un outil lit les journaux d'accès du proxy. Point d'entrée : les journaux ou l'historique du navigateur. Résultat : récupération d'identifiants P6 ou Unifier valides, sans interaction avec l'application.

## Impact
Confidentialité : compromission de comptes de service ERP ; périmètre : toute organisation dont les identifiants ont transité ; aucune exploitation active démontrée.

## Recommandation
- **Court terme :** Passer ces appels en POST avec corps JSON ; supprimer les paramètres `token`, `password`, `username` des routes GET ; expurger ces champs des journaux du proxy ; renouveler les secrets déjà exposés.
- **Structurelle :** Ne plus faire transiter d'identifiant ERP par le navigateur : le backend résout l'identifiant depuis un coffre (voir SEC-004) à partir d'un identifiant de connecteur.

## Contre-check
Les routes exigent un utilisateur authentifié, ce qui ne réduit pas l'exposition dans les URL. Si les journaux du proxy de production masquent les query strings, l'exposition se limite au navigateur : cette configuration est hors dépôt (Caddy) et non vérifiée.

## Vérification
- T-10-005 (aucun token ni mot de passe en query string, contrat OpenAPI)
- Nouveau T-SEC-001 : test HTTP qui échoue si une route accepte `password` ou `token` en `Query`

## Références
OWASP ASVS V3.1 ; CWE-598 ; OWASP API Security 2023 API2
