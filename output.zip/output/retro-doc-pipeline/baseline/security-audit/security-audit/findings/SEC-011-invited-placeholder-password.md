# SEC-011 - Mot de passe provisoire constant pour les comptes invités
- **Composant :** Backend
- **Catégorie :** ASVS V2 ; OWASP API 2023 API2 ; **CWE :** CWE-798
- **Sévérité :** BASSE ; **Confiance :** moyenne
- **Statut de preuve :** inféré à partir d'un document interne non audité (S-012)
- **Priorité :** P3 ; **Effort :** S
- **Fiche d'audit d'architecture liée :** —

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Selon `diagrams/authentication/ReadMe.md` §2.4, `user_repo.create_user` écrit `INVITED_NO_PASSWORD_SET_YET` dans `hashed_password` et le compte est créé avec `is_active=False`.

Sources : S-012 (voir `evidence/ledger.md`).
- `backend/app/repositories/user_repo.py`

## Observation
La chaîne n'est pas un hash bcrypt valide ; la vérification de mot de passe la rejette en principe. Ce point vient d'un document de l'équipe, non vérifié par l'audit d'architecture.

## Inférence
Le risque devient réel si la logique de vérification change, ou si un compte invité est activé par un autre chemin (par exemple OAuth) sans que le mot de passe soit défini.

## Scénario d'attaque (descriptif)
Préconditions : défaut dans la vérification ou activation par un autre flux. Résultat : connexion avec une valeur connue.

## Impact
Faible tant que la vérification reste correcte ; élevé si elle régresse.

## Recommandation
- **Court terme :** Stocker `NULL` et refuser toute vérification sur `NULL`.
- **Structurelle :** Statut de compte explicite (`invited`, `active`, `disabled`) et activation par jeton à usage unique (chantier FT-02, FT-04).

## Contre-check
La comparaison bcrypt avec une chaîne qui n'est pas un hash échoue généralement ; le risque est conditionnel. Le code n'a pas été relu.

## Vérification
- T-04-016 (aucun mot de passe n'ouvre un compte dont le hash est NULL)
- T-02-004 (le placeholder est remplacé par NULL)

## Références
OWASP ASVS V2.1 ; CWE-798
