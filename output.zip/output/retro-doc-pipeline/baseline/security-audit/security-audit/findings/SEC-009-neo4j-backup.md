# SEC-009 - Pas de sauvegarde Neo4j avant migration (résilience et intégrité)
- **Composant :** Infra
- **Catégorie :** OWASP Top 10 A04 ; résilience ; **CWE :** CWE-1263
- **Sévérité :** MOYENNE ; **Confiance :** moyenne
- **Statut de preuve :** prouvé par les scripts consultés ; procédures externes possibles (rapporté, E-010)
- **Priorité :** P1 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-010

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- La release produit un `pg_dump` compressé avant Alembic (`deploy/scripts/apply-release.sh:139-144`).
- Les données Neo4j sont sur un volume persistant sans étape de backup trouvée (`deploy/docker-compose.deploy.yml:26`).

Sources : S-010 (voir `evidence/ledger.md`).
- `deploy/scripts/apply-release.sh:139-144`
- `deploy/docker-compose.deploy.yml:26`

## Observation
Neo4j porte les graphes Studio et le modèle canonique, non reconstruits par la migration SQL.

## Inférence
La perte ou la corruption du volume, ou un défaut de migration touchant les graphes, ne serait pas récupérable avec le seul backup SQL.

## Scénario d'attaque (descriptif)
Préconditions : corruption, suppression accidentelle ou action malveillante sur le volume. Résultat : perte de graphes.

## Impact
Disponibilité et intégrité des données métier principales.

## Recommandation
- **Court terme :** Ajouter un export ou un snapshot Neo4j à la release ; tester la restauration.
- **Structurelle :** Sauvegardes planifiées et restauration périodique des deux datastores.

## Contre-check
L'audit d'architecture a classé ce point HIGH ; je le reclasse MOYENNE en sécurité parce que l'impact est la résilience et non une fuite ou une prise de contrôle ; il reste P1 côté exploitation. Une sauvegarde hors dépôt peut exister.

## Vérification
- Test de restauration sur une base jetable (hors tests automatiques)

## Références
OWASP Top 10 A04 ; ISO 27001 A.8.13
