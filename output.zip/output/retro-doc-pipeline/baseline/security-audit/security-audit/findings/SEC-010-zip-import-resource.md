# SEC-010 - Import ZIP en mémoire dans un thread du processus API, sans limite d'upload observée
- **Composant :** API + Backend
- **Catégorie :** OWASP API 2023 API4 ; **CWE :** CWE-770, CWE-400
- **Sévérité :** MOYENNE ; **Confiance :** faible à moyenne
- **Statut de preuve :** inféré (E-011 ; limites d'upload non observées dans le périmètre consulté)
- **Priorité :** P2 ; **Effort :** M
- **Fiche d'audit d'architecture liée :** ARCH-011

## Fait (rapporté par l'audit d'architecture, non revérifié sur le code)
- Le traitement démarre dans un thread daemon après lecture complète du ZIP en mémoire ; l'état est dans `task_status_store`, un dictionnaire de processus (`backend/app/modules/unifier_package/router.py:38,142-153`).
- L'extraction vérifie que les chemins restent dans la destination (`unifier_adapter.py:145-154`).

Sources : S-011, S-019 (voir `evidence/ledger.md`).
- `backend/app/modules/unifier_package/router.py:38,142-153`
- `backend/app/modules/unifier_package/unifier_adapter.py:145-154`

## Observation
Le ZIP complet est en mémoire du processus API qui a reçu l'upload ; aucune limite de taille, de nombre d'entrées ou de ratio de décompression n'a été observée.

## Inférence
Un utilisateur authentifié peut dégrader ou interrompre le processus API avec un fichier volumineux ou une archive à fort ratio de compression.

## Scénario d'attaque (descriptif)
Préconditions : droit d'appeler l'import. Résultat : saturation mémoire du processus API, indisponibilité pour tous les tenants.

## Impact
Disponibilité de l'API ; aucune fuite de données.

## Recommandation
- **Court terme :** Limiter la taille du corps et le nombre d'entrées ; borner la taille décompressée.
- **Structurelle :** Import en file durable (Celery) avec suivi en base, flux sur disque, quotas par organisation.

## Contre-check
Une limite peut exister côté proxy (taille de corps) ou dans le code non consulté : non vérifié. La protection contre le parcours de chemins (zip-slip) est présente.

## Vérification
- Nouveau T-SEC-010 : archive dépassant la taille ou le nombre d'entrées autorisés refusée avec 413 ou 422

## Références
OWASP API Security 2023 API4 ; CWE-409
