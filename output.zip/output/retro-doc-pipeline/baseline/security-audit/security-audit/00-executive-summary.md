# 00 - Synthèse exécutive

**Périmètre réel de cet audit :** le fichier fourni (`architecture-audit.zip`) contient les 54 documents de l'audit d'architecture du 2026-10-01 (rapports, fiches ARCH-001 à ARCH-015, registre de preuves E-001 à E-027, diagrammes). **Il ne contient aucun code source** (ni `backend/`, ni `frontend/`, ni configuration de proxy). Cet audit est donc une **revue documentaire de sécurité** : les faits cités avec `fichier:ligne` sont ceux rapportés par l'audit d'architecture et **n'ont pas été revérifiés sur le code**. Ce qui exige le code est noté `Non vérifiable`.

## Verdict

- **Aucun finding CRITIQUE** : aucun chemin d'attaque complet sans authentification ou inter-tenant n'est démontré par les documents.
- **2 findings HAUTE, 8 MOYENNE, 4 BASSE, 2 INFO** (16 au total).
- Les deux risques les plus sérieux concernent les **connecteurs ERP** : identifiants dans les URL (SEC-001) et destinations HTTP libres avec TLS désactivable (SEC-002). Les deux sont accessibles à tout utilisateur authentifié.
- **57 contrôles de checklist** évalués : 1 conformes, 29 partiels, 8 non conformes, 19 non vérifiables. Les 19 contrôles non vérifiables portent notamment sur l'isolation des workspaces, l'activation de compte, l'OAuth, l'injection et le XSS : ils exigent le code.

## Top 10 des risques

| ID | Titre | Sévérité | Priorité | Confiance |
|---|---|---|---|---|
| SEC-001 | Identifiants ERP transportés dans les URL (query strings) | HAUTE | P1 | élevée |
| SEC-002 | Destinations HTTP fournies par l'appelant pour les connecteurs (SSRF) et TLS désactivable | HAUTE | P1 | moyenne |
| SEC-003 | Access token accepté après désactivation ; pas de révocation serveur ; refresh de 14 jours | MOYENNE | P1 | élevée (sur le code audité) ; à reconfirmer sur le code actuel |
| SEC-004 | `secret_ref` consommé comme token sans résolution de coffre | MOYENNE | P1 | élevée sur l'absence de résolution ; moyenne sur la valeur stockée |
| SEC-005 | Chaîne d'approvisionnement : dépendances non épinglées, aucun scan, SBOM ni signature | MOYENNE | P2 | élevée sur l'absence observée |
| SEC-006 | Déploiement automatique par SSH sur push `dev`, sans approbation visible | MOYENNE | P2 | moyenne (gate externe possible) |
| SEC-007 | Sorties d'outils réinjectées comme messages `user` ; erreurs d'outils exposées ; pas de test d'injection de prompt | MOYENNE | P2 | moyenne |
| SEC-008 | Historique de chat métier conservé en `localStorage` | MOYENNE | P2 | élevée |
| SEC-009 | Pas de sauvegarde Neo4j avant migration (résilience et intégrité) | MOYENNE | P1 | moyenne |
| SEC-010 | Import ZIP en mémoire dans un thread du processus API, sans limite d'upload observée | MOYENNE | P2 | faible à moyenne |
| SEC-011 | Mot de passe provisoire constant pour les comptes invités | BASSE | P3 | moyenne |
| SEC-012 | Mot de passe administrateur de démonstration publié (mode développement) | BASSE | P3 | élevée |
| SEC-013 | Origines CORS codées en dur, variable `CORS_ORIGINS` non consommée | BASSE | P3 | élevée |
| SEC-014 | DDL exécuté au démarrage : le compte applicatif porte vraisemblablement des droits de schéma | BASSE | P3 | faible |
| SEC-015 | Observabilité de sécurité : journal d'audit des événements d'accès non identifié | INFO | P3 | faible |
| SEC-016 | Ports des datastores publiés dans le Compose de développement | INFO | P3 | élevée |

## Décisions et informations attendues

1. Fournir le code (`backend/app/modules/identity`, `connectors`, `studio_v2`, `retrieval`, `repositories/graph_repo.py`, et les composants Angular de chat et de graphe) pour lever les hypothèses H-01 à H-07.
2. Fournir la configuration Caddy de production et confirmer les approbations d'environnement Azure (H-08, SEC-006).
3. Indiquer si le registre de sessions (migration 0025) corrige SEC-003 sur le code courant.

Voir `FINAL-REPORT.md` pour la consolidation et `09-remediation-roadmap.md` pour l'ordre de correction.
