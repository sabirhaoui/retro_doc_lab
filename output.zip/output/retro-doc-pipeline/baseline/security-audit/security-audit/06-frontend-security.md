# 06 - Sécurité du frontend (checklist FE-xx)

Les « preuves » sont celles rapportées par l'audit d'architecture (S-xxx, voir `evidence/ledger.md`) ; elles n'ont pas été revérifiées sur le code.

**Bilan :** Partiel : 7 ; Non vérifiable : 8.

| ID | Verdict | Preuve ou raison | Réf. |
|---|---|---|---|
| FE-01 | **Partiel** | Access token en mémoire, refresh HttpOnly (S-025, positif) ; historique de chat en `localStorage` (S-009). | SEC-008 |
| FE-02 | **Non vérifiable** | Usages de `innerHTML` et `bypassSecurityTrust*`, rendu des libellés de graphe et du markdown du chat : non vérifiables. | H-07 |
| FE-03 | **Non vérifiable** | Image Nginx statique en production ; en-têtes et CSP non décrits (Caddy hors dépôt). | H-08 |
| FE-04 | **Partiel** | Guards présents, guard d'onboarding commenté (S-025) ; correspondance routes masquées et refus API non vérifiable. | — |
| FE-05 | **Non vérifiable** | Gestion de `returnUrl` non décrite. | — |
| FE-06 | **Partiel** | `AuthInterceptor` ajoute le Bearer et rejoue sur 401 (S-025) ; filtrage par origine non vérifiable ; import asynchrone vers `http://localhost:8001` (S-024). | — |
| FE-07 | **Partiel** | Base d'API relative, pas de `fileReplacements` (S-024) ; secrets dans les fichiers d'environnement et cartes source non vérifiés. | — |
| FE-08 | **Partiel** | `package-lock.json` et `npm ci` (positif) ; `npm audit` non exécuté. | SEC-005 |
| FE-09 | **Partiel** | Logout supprime le cookie sans révocation serveur ; pas de déconnexion sur inactivité (cible du chantier). | SEC-003 |
| FE-10 | **Non vérifiable** | Affichage et journalisation des erreurs côté client non décrits. | — |
| FE-11 | **Non vérifiable** | En-têtes de clickjacking et de typage non décrits. | H-08 |
| FE-12 | **Non vérifiable** | Politique de cache des réponses authentifiées non décrite. | — |
| FE-13 | **Non vérifiable** | `postMessage` et événements `storage` non décrits. | — |
| FE-14 | **Non vérifiable** | Rendu WebGL (Sigma) des graphes : échappement des libellés non vérifiable. | H-07 |
| FE-15 | **Partiel** | Conversations conservées localement (S-009) ; envois à des tiers non vérifiables. | SEC-008 |

Observation : le guard d'onboarding est commenté dans les routes et aucun test E2E navigateur n'est identifié (S-025).
