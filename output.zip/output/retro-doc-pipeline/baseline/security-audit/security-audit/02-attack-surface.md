# 02 - Surface d'attaque (reconstituée depuis les documents)

> **Inventaire non exhaustif.** Il ne contient que les routes et flux mentionnés dans les documents. Une table complète exige l'OpenAPI ou les routeurs.

## Routes et flux connus

| Méthode et chemin | Rôle | Authentification constatée | Autorisation constatée | Source | Verdict |
|---|---|---|---|---|---|
| `POST /api/v1/auth/login` | Connexion locale | Publique (par nature) | - | E-020, 06-flows | Vérifications mot de passe et `is_active` rapportées |
| `POST /api/v1/auth/refresh` | Renouvellement (cookie) | Cookie de refresh | Contrôle `is_active` | E-006, E-020 | Pas de rotation observée (SEC-003) |
| `POST /api/v1/auth/logout` | Déconnexion | Cookie | - | E-020 | Pas de révocation serveur (SEC-003) |
| Callback OAuth Microsoft | SSO | Publique (callback) | `state` en cookie | 10-security | `nonce`, PKCE, tenant non vérifiables (H-05) |
| `POST /v1/auth/setup-account` | Fixation du mot de passe (invité) | Non précisée | Non précisée | ReadMe auth (document interne) | Non vérifiable (H-02) |
| `POST /api/v1/admin/users` (et dérivés) | Administration des utilisateurs | Oui | `require_admin` | ReadMe auth, 10-security | Dernier admin non vérifiable (H-06) |
| `/api/v2/studio/...` | Workspaces et graphes | Oui | ACL workspace SQL, niveaux viewer et plus | 06-flows | Isolation Neo4j non vérifiable (H-01) |
| `GET` connecteurs P6/Unifier (projets, BP) | Découverte ERP | Oui | Aucune restriction de rôle rapportée | E-004, E-005 | SEC-001, SEC-002 |
| `POST` connecteurs (test de connexion) | Test de connexion | Oui | Aucune restriction de rôle rapportée | E-005 | SEC-002 |
| Jobs d'ingestion (création, statut, annulation) | Ingestion | Oui | Non précisée | E-008 | Placeholder (hors périmètre sécurité) |
| Import ZIP Unifier (asynchrone et statut) | Import | Oui | Non précisée | E-011, E-021 | SEC-010 |
| `POST /api/v1/assystan/chat` et SSE | Assistant LLM | Oui | ACL workspace dans les outils | 09-ai-architecture | SEC-007 |
| `GET /health` | Sonde | Publique | - | E-015 | Réponse fixe |

## Entrées
Paramètres de chemin et de requête (dont des identifiants ERP : SEC-001), corps JSON (dont `base_url` : SEC-002), cookies (refresh, state OAuth), en-tête `Authorization`, fichiers ZIP, callback OAuth, messages Celery (Redis), en-tête `X-Correlation-ID`.

## Frontières de confiance
Navigateur - Caddy (hors dépôt) - API FastAPI - PostgreSQL, Neo4j, Redis (réseau Docker) - SMTP - Microsoft (IdP) - fournisseur LLM (OpenAI) - ERP P6/Unifier (sortant). Les sorties vers l'ERP et le LLM franchissent la frontière sans filtrage d'egress observé.

## Emplacements de secrets (noms uniquement)
`SECRET_KEY` (sans défaut), `CORS_ORIGINS`, URI PostgreSQL et Neo4j, `APP_ENV`, `.env` de production (copié sur l'hôte, placeholders refusés), `deploy/ci-fixtures/.env` (non lu), colonne `secret_ref` des connecteurs, identifiants ERP saisis dans l'interface, clé SSH du pipeline CD, clé du fournisseur LLM (nom de variable non documenté dans le zip).

## Flux de données sensibles
Identifiants ERP : navigateur vers API (en URL pour les GET) puis vers l'ERP ; conversations : navigateur (`localStorage`) et PostgreSQL ; jetons : mémoire du navigateur (access) et cookie HttpOnly (refresh) ; contenu de graphes : Neo4j vers le LLM.
