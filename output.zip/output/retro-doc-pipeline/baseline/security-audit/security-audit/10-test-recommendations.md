# 10 - Tests recommandés (liés à plan-testing.md)

| Finding | Tests existants du catalogue | Nouveaux tests proposés |
|---|---|---|
| SEC-001 | T-10-005 | **T-SEC-001** : aucune route n'accepte `password`, `token` ou `username` en `Query` (introspection OpenAPI) |
| SEC-002 | T-07-002 (adapté) | **T-SEC-002** : validation d'URL (IPv4/IPv6, plages privées, métadonnées, redirections, DNS rebinding) ; **T-SEC-003** : `insecure` refusé hors configuration contrôlée |
| SEC-003 | T-04-003, T-01-004, T-07-007, F-05 | - |
| SEC-004 | - | **T-SEC-004** : un credential factice passe par un résolveur ; **T-SEC-005** : la réponse du catalogue ne contient aucune valeur secrète |
| SEC-005 | T-00-001 à T-00-007 | **T-SEC-006** : job CI échoue sur une vulnérabilité de gravité haute |
| SEC-006 | T-00-007 | Contrôle de configuration Azure |
| SEC-007 | - | **T-SEC-007** : corpus d'injection de prompt dans des libellés ; **T-SEC-008** : aucune exception interne dans la réponse |
| SEC-008 | T-11-007 | **T-SEC-009** : après logout, `localStorage` sans conversation |
| SEC-009 | - | Test de restauration sur base jetable |
| SEC-010 | - | **T-SEC-010** : archive trop volumineuse ou trop d'entrées refusée |
| SEC-011 | T-04-016, T-02-004 | - |
| SEC-013 | - | **T-SEC-011** : en-têtes CORS conformes par environnement |
| SEC-015 | T-01-009, T-06-007 | - |
| H-01 | T-09-001 à T-09-010, F-06 | Prioritaires dès que le code est disponible |

Les tests T-SEC-xxx sont à ajouter au catalogue de `plan-testing.md` (module « Sécurité transverse ») ; ils reprennent le format `T-NN-NNN`, niveaux U, I, C selon le cas.
