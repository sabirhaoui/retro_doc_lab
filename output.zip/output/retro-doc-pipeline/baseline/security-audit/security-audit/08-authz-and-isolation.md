# 08 - Autorisation et isolation (rôle × workspace × licence)

## Constaté (rapporté)
- Dépendances `get_current_user` et `require_admin` ; ACL de workspace avec niveaux (viewer et plus) ; ACL refaite dans plusieurs outils Assystan.
- Données de droits dans PostgreSQL ; graphes dans Neo4j avec deux modèles (v1 historique, v2) ; `WorkspaceGraphRef` relie un workspace SQL à la clé de graphe.
- Retrieval essaie Studio v2 puis se rabat sur v1 (E-019).
- Aucune notion de licence dans le code audité (chantier en cours).

## Écarts et points à vérifier
| Point | État | Réf. |
|---|---|---|
| `get_current_user` ne contrôle pas le statut du compte | Constaté sur le code audité | SEC-003 |
| Routes de test de connecteurs ouvertes à tout utilisateur authentifié | Constaté | SEC-002 |
| Filtre d'appartenance sur toutes les requêtes Neo4j (v1 et v2) | Non vérifiable | H-01 |
| Un `graph_id` ne doit jamais valoir droit d'accès | Non vérifiable | H-01 |
| Réponse 404 pour un workspace non autorisé (anti-énumération) | Non vérifiable | H-01 |
| Dernier admin, admin plateforme sans accès implicite | Non vérifiable | H-06 |
| Licence relue en base à chaque requête (chantier) | Cible, non auditable | FT-06 |

## Conclusion
L'isolation inter-tenant est le contrôle le plus important et **le moins vérifiable depuis ce zip**. Elle doit être la première cible d'une revue du code, avec les tests T-09-001 à T-09-010 et le scénario F-06.
