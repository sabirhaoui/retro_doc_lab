# Commandes exécutées et non exécutées

**Exécutées :** aucune commande d'analyse de sécurité. Seules des commandes de lecture du zip (`unzip`, `cat`, `sed`) ont été utilisées pour lire les documents.

**Non exécutées, faute de code source dans l'entrée (aucun résultat n'est revendiqué) :**

| Commande | État | À lancer sur |
|---|---|---|
| `bandit -r backend/app -f json` | NON EXÉCUTÉ | dépôt complet |
| `pip-audit -r backend/requirements.txt` | NON EXÉCUTÉ | dépôt complet |
| `semgrep --config auto backend frontend/src` | NON EXÉCUTÉ | dépôt complet |
| `gitleaks detect --no-banner --redact` | NON EXÉCUTÉ | dépôt complet (sortie expurgée) |
| `npm audit --omit=dev` (dans `frontend/`) | NON EXÉCUTÉ | dépôt complet |
| `hadolint Dockerfile*` ; `trivy config .` | NON EXÉCUTÉ | dépôt complet |
| comparaison OpenAPI généré et instantané | NON EXÉCUTÉ | dépôt complet |

Recommandation : exécuter ces outils dans un job CI dédié (pas de machine locale disponible), en sortie expurgée pour `gitleaks`.
