# 07 - Proxy, pipeline et déploiement (checklist INF-xx)

Les « preuves » sont celles rapportées par l'audit d'architecture (S-xxx, voir `evidence/ledger.md`) ; elles n'ont pas été revérifiées sur le code.

**Bilan :** Conforme : 1 ; Partiel : 2 ; Non conforme : 1 ; Non vérifiable : 1.

| ID | Verdict | Preuve ou raison | Réf. |
|---|---|---|---|
| INF-01 | **Non vérifiable** | Caddy hors dépôt ; Nginx de développement mal configuré (ARCH-001, ARCH-002, sujet fonctionnel). | H-08 |
| INF-02 | **Conforme** | Production : datastores non publiés, backend et frontend en loopback (S-021). Développement : ports publiés. | SEC-016 |
| INF-03 | **Partiel** | CD par SSH sur `dev` sans approbation visible (S-007) ; gestion des secrets du pipeline non vérifiable. | SEC-006 |
| INF-04 | **Non conforme** | Pas de scan, SBOM, signature ; tags mobiles ; pas de backup Neo4j (S-006, S-010). | SEC-005, SEC-009 |
| INF-05 | **Partiel** | `APP_ENV=production` fixé ; seed de démonstration conditionné à `development` (S-013) ; `deploy/ci-fixtures/.env` non lu. | SEC-012 |
