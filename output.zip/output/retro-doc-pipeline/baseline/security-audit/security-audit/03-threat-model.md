# 03 - Modèle de menaces (STRIDE)

| Flux | Acteur | Menace (STRIDE) | Contrôle attendu | Contrôle constaté | Verdict | Réf. |
|---|---|---|---|---|---|---|
| Connexion locale | Anonyme | S, D (force brute) | Limitation de débit, bcrypt, message générique | bcrypt présent ; limitation de débit non observée | Partiel | BE-03, API-04 |
| Refresh et logout | Voleur de cookie | S, E | Rotation, révocation, durée courte | 14 jours, pas de révocation | Non conforme | SEC-003 |
| OAuth Microsoft | Anonyme, tenant externe | S, E | `state`, `nonce`, PKCE, tenant, issuer, audience | `state` seul documenté | Non vérifiable | H-05 |
| Création et activation de compte | Admin, invité, anonyme | S, T, I (énumération) | Jeton à usage unique haché, réponse générique | Non fourni ; mot de passe provisoire constant (doc interne) | Non vérifiable | H-02, SEC-011 |
| Accès workspace et graphe | Membre d'un autre workspace | E, I (BOLA) | Filtre d'appartenance sur toute requête SQL et Cypher | ACL SQL rapportée ; Neo4j v1/v2 non vérifié | Non vérifiable | H-01 |
| Connecteurs ERP | Utilisateur authentifié | I, E (SSRF), I (secrets en URL) | Allowlist, POST, résolveur de coffre | Aucun des trois | Non conforme | SEC-001, 002, 004 |
| Import ZIP | Utilisateur authentifié | D, T | Limites de taille, extraction sûre | Extraction sûre ; limites non observées | Partiel | SEC-010 |
| Chat LLM | Rédacteur de contenu de graphe | T, I (injection de prompt) | Provenance des sorties d'outils, erreurs filtrées | Rôle `user`, `str(exc)` | Partiel | SEC-007 |
| Jobs Celery et Beat | Interne | T, R | Annulation coopérative, idempotence | Statut SQL sans révocation | Non conforme | API-17 |
| Pipeline CD | Contributeur sur `dev` | E, T | Approbation d'environnement, clé à portée minimale | Aucune approbation visible | Partiel | SEC-006 |

## Cas d'abus

- **AC-01** : un utilisateur de base saisit `http://<service interne>/` comme `base_url` d'un test de connexion et lit l'erreur ou la réponse (SEC-002).
- **AC-02** : un opérateur consulte les journaux d'accès du proxy et y retrouve les mots de passe ERP passés en query (SEC-001).
- **AC-03** : un administrateur désactive un compte ; l'utilisateur continue d'agir avec son access token pendant jusqu'à 60 minutes (SEC-003).
- **AC-04** : un membre du workspace A fournit à une route de lecture un identifiant de nœud ou de graphe du workspace B (H-01, à vérifier).
- **AC-05** : un utilisateur dépose dans un libellé de nœud des instructions destinées au modèle ; un autre utilisateur interroge l'assistant (SEC-007).
- **AC-06** : un utilisateur téléverse une archive très volumineuse ou à fort ratio de compression (SEC-010).
- **AC-07** : un compte invité est activé par le flux OAuth Microsoft sans passer par l'activation par jeton (H-05).
- **AC-08** : une personne ayant accès à une sauvegarde de base lit la colonne `secret_ref` (SEC-004).
- **AC-09** : un contributeur fusionne sur `dev` et déclenche un déploiement automatique (SEC-006).
- **AC-10** : un poste de développement sur réseau partagé expose Postgres, Neo4j et Redis (SEC-016).
