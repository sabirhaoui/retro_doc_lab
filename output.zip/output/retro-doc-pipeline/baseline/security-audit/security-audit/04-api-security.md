# 04 - Sécurité des API (checklist API-xx)

Les « preuves » sont celles rapportées par l'audit d'architecture (S-xxx, voir `evidence/ledger.md`) ; elles n'ont pas été revérifiées sur le code.

**Bilan :** Partiel : 9 ; Non conforme : 4 ; Non vérifiable : 4.

| ID | Verdict | Preuve ou raison | Réf. |
|---|---|---|---|
| API-01 | **Non vérifiable** | Contrôles d'ACL de workspace et `require_admin` rapportés (10-security) ; couverture route par route et sur les identifiants de graphe/nœud non démontrable sans le code. Retrieval essaie Studio v2 puis v1 (E-019) : à vérifier en priorité. | H-01 |
| API-02 | **Partiel** | `get_current_user` existe ; les routes connecteurs exigent un JWT (S-002). Liste complète des routes publiques absente du zip. | — |
| API-03 | **Partiel** | `secret_ref` renvoyé par l'API sous ce nom (S-005) ; autres schémas de sortie non vérifiables. | SEC-004 |
| API-04 | **Partiel** | Studio v2 paginé et chargé à la demande (S-025) ; ZIP lu en mémoire, aucun timeout global de tâche (S-011, S-022). Limitation de débit non observée (absence d'observation, non preuve d'absence). | SEC-010 |
| API-05 | **Non conforme** | Routes de test des connecteurs ouvertes à tout utilisateur authentifié (S-002). `require_admin` existe pour l'administration. | SEC-002 |
| API-06 | **Non vérifiable** | Flux `setup-account` et invitation : code non fourni ; existence confirmée par le document interne seulement (S-012). | H-02 |
| API-07 | **Non conforme** | `base_url` fournie par l'appelant, appels `urlopen` sans allowlist, `insecure` possible (S-002). | SEC-002 |
| API-08 | **Partiel** | CORS à origines explicites (positif) mais incohérent avec la configuration (S-014) ; exposition de `/docs`, en-têtes de sécurité et TLS non vérifiables (Caddy hors dépôt). | SEC-013 |
| API-09 | **Partiel** | OpenAPI présent (`shared/openapi.py`) ; dossiers legacy `api/` et `dependencies/` d'usage non tracé ; Studio v1 et v2 coexistent (E-019). | H-03 |
| API-10 | **Partiel** | Clients ERP en `urlopen` sans validation de destination ; aucun timeout LLM commun mesuré (09-ai-architecture). | SEC-002, SEC-007 |
| API-11 | **Non vérifiable** | Les repositories encapsulent SQL et Cypher « de façon non uniforme » (04-backend) : construction des requêtes non vérifiable. | H-04 |
| API-12 | **Non vérifiable** | Pydantic v2 en usage ; rejet des champs inconnus et normalisation non vérifiables. | — |
| API-13 | **Partiel** | Gestionnaires d'exceptions typées et format structuré rapportés ; les erreurs d'outils LLM transmettent `str(exc)` (S-008). | SEC-007 |
| API-14 | **Non conforme** | `token`, `username`, `password` en query string (S-001). | SEC-001 |
| API-15 | **Partiel** | Protection contre le parcours de chemins à l'extraction ZIP (S-019, positif) ; taille, nombre d'entrées et ratio non observés (S-011). | SEC-010 |
| API-16 | **Partiel** | Cookie de refresh HttpOnly, SameSite=Lax, Secure en production (S-004) ; aucun jeton anti-CSRF mentionné. Lax bloque les POST inter-sites, sous réserve d'une architecture à même site. | — |
| API-17 | **Non conforme** | Annulation de job sans transition atomique (S-023) ; DDL de démarrage concurrent (S-015). Consommation des jetons d'activation non vérifiable. | SEC-014, H-02 |
