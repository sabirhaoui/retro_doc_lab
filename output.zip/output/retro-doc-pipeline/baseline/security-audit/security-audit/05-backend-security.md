# 05 - Sécurité du backend (checklist BE-xx)

Les « preuves » sont celles rapportées par l'audit d'architecture (S-xxx, voir `evidence/ledger.md`) ; elles n'ont pas été revérifiées sur le code.

**Bilan :** Partiel : 11 ; Non conforme : 3 ; Non vérifiable : 6.

| ID | Verdict | Preuve ou raison | Réf. |
|---|---|---|---|
| BE-01 | **Partiel** | Algorithme passé explicitement au decode ; `SECRET_KEY` sans valeur par défaut (S-018, positif). `exp`, `iss`, `aud`, rotation de clé non vérifiables. | — |
| BE-02 | **Non conforme** | Pas de révocation serveur ; refresh de 14 jours sans rotation observée (S-003, S-004). | SEC-003 |
| BE-03 | **Partiel** | bcrypt via passlib (S-018, positif) ; mot de passe provisoire constant pour les invités (S-012). | SEC-011 |
| BE-04 | **Non vérifiable** | Implémentation de `setup-account` non fournie. | H-02 |
| BE-05 | **Partiel** | State OAuth en cookie HttpOnly avec vérification d'égalité (S-018). `nonce`, PKCE, validation de l'URI de redirection, issuer, audience et tenant non vérifiables ; liaison de compte non vérifiable. | H-05 |
| BE-06 | **Partiel** | `get_current_user`, `require_admin`, ACL workspace présents ; ACL refaite dans plusieurs outils Assystan (duplication) ; pas de licences à ce stade. | — |
| BE-07 | **Non vérifiable** | ACL SQL rapportée ; filtrage Neo4j v1 (`graph_repo`) et v2 non vérifiable. Un `graph_id` ne doit jamais prouver un droit. | H-01 |
| BE-08 | **Non vérifiable** | Dernier admin, accès implicite d'un admin plateforme : non documentés. | H-06 |
| BE-09 | **Partiel** | `SECRET_KEY` sans défaut et script de release refusant les placeholders (S-021, positif) ; `secret_ref` ambigu (S-005) ; `deploy/ci-fixtures/.env` non lu. | SEC-004 |
| BE-10 | **Partiel** | Corrélation et logs structurés (S-020, positif) ; contenu des logs non audité ; secrets en query potentiellement journalisés par le proxy. | SEC-001, SEC-015 |
| BE-11 | **Non vérifiable** | Générateurs aléatoires et TLS vers PostgreSQL, Neo4j, Redis, SMTP non documentés. | — |
| BE-12 | **Partiel** | Redis broker, ack tardif, prefetch=1 (S-022) ; authentification Redis et sérialisation non vérifiées ; pas de timeout global. | — |
| BE-13 | **Non conforme** | Dictionnaire de statut et thread daemon dans le processus API ; singletons (S-011). | SEC-010 |
| BE-14 | **Partiel** | Sauvegarde SQL en release (positif) ; DDL de démarrage ; pas de backup Neo4j ; privilèges du compte non vérifiés (S-010, S-015). | SEC-009, SEC-014 |
| BE-15 | **Non vérifiable** | `email_service` non examiné (Mailpit en développement). | H-02 |
| BE-16 | **Non vérifiable** | Usage de `urlopen` constaté ; `pickle`, `eval`, `subprocess` non recherchés dans le zip. | — |
| BE-17 | **Partiel** | Exigences Python partiellement non épinglées, pas de lockfile ; aucun scan (S-006). | SEC-005 |
| BE-18 | **Partiel** | Backend non root, ports prod en loopback (S-021, positif) ; tags mobiles, pas de healthcheck backend. | SEC-005 |
| BE-19 | **Partiel** | ACL imposée dans les outils, boucle bornée à 10 rounds (positif) ; provenance des sorties d'outils, `str(exc)`, pas de test adversarial (S-008). | SEC-007 |
| BE-20 | **Non conforme** | Identifiants en query, `base_url` libre, `secret_ref` ambigu (S-001, S-002, S-005). | SEC-001, SEC-002, SEC-004 |
