# 09 - Feuille de route de remédiation

Aucune priorité P0 : aucun finding critique.

| Lot | Thème | Findings | Priorité | Effort | Dépendances | Backlog |
|---|---|---|---|---|---|---|
| L1 | Sécurité des connecteurs ERP | SEC-001, SEC-002, SEC-004 | P1 | S + M + M | Décision sur le coffre de secrets | Nouvelle Feature (à créer dans le backlog, après FT-07) |
| L0 | Révocation et sessions | SEC-003, SEC-011 | P1 | S | Registre de sessions (FT-01) | FT-01, FT-04, FT-07 |
| L5 | Résilience des données | SEC-009 | P1 | M | Accès à l'hôte de production | CN-10, GV-05 |
| L2 | Ressources et API | SEC-010 | P2 | M | File durable (Celery) | Nouvelle Feature |
| L3 | Sécurité IA | SEC-007 | P2 | M | - | Nouvelle Feature |
| L6 | Chaîne d'approvisionnement et CD | SEC-005, SEC-006 | P2 | M + S | Branche FT-00 (CI) | FT-00, GV-02 |
| L7 | Frontend | SEC-008 | P2 | M | Source de vérité de l'historique | FT-11, FT-14 |
| L4 | Hygiène et durcissement | SEC-012, SEC-013, SEC-014, SEC-015, SEC-016 | P3 | S à M | - | Tâches de nettoyage |

## Ordre recommandé
1. **Lever les hypothèses H-01, H-02, H-05** (revue du code) avant d'investir dans le reste : elles peuvent produire des findings plus graves que ceux listés.
2. L0 : corriger `get_current_user` (statut du compte) et retirer le mot de passe provisoire, au sein des branches FT-01 à FT-04 déjà planifiées.
3. L1 : traiter les trois findings connecteurs ensemble (POST en corps, restriction aux administrateurs, validation d'URL, résolveur de secrets).
4. L5 : ajouter une sauvegarde Neo4j et un test de restauration avant la prochaine release.
5. L6, L2, L3, L7 ensuite, puis L4.

## Dépendance avec le plan de livraison existant
Les lots L0 et L7 s'intègrent dans les branches `authz-01` à `authz-04`, `authz-11` et `authz-14`. Le lot L1 est **absent du plan de branches actuel** : il doit être ajouté, ce qui est cohérent avec la décision « licence par organisation » qui implique aussi un traitement des identifiants de connecteur par organisation.
