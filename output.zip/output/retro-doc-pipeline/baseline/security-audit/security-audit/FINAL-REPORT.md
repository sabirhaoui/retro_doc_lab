# FINAL-REPORT - Audit de sécurité Assystan (API, backend, frontend)

**Date :** 2026-10-12. **Entrée :** `architecture-audit.zip` (documents de l'audit d'architecture du 2026-10-01 ; aucun code). **Nature :** revue documentaire de sécurité ; les faits sont de seconde main.

## Résumé
- Aucun finding CRITIQUE. 2 HAUTE, 8 MOYENNE, 4 BASSE, 2 INFO.
- Priorités : connecteurs ERP (SEC-001, SEC-002, SEC-004), révocation d'accès (SEC-003), sauvegarde Neo4j (SEC-009).
- Contrôles positifs confirmés : algorithme JWT explicite, `SECRET_KEY` sans défaut, bcrypt, cookie de refresh HttpOnly/SameSite/Secure, extraction ZIP protégée, CORS à origines explicites, datastores non exposés en production, backend non root.
- Le principal risque inconnu est l'**isolation inter-workspaces** (H-01) : non vérifiable sans le code.

## Constats antérieurs du prompt (§4)
| Constat | Verdict | Réf. |
|---|---|---|
| Identifiants ERP en query string | Confirmé (rapporté) | SEC-001 |
| Destinations sortantes pilotées par l'appelant, pas d'allowlist | Confirmé (rapporté) | SEC-002 |
| `is_active` non contrôlé sur un access token émis | Confirmé sur le code audité ; contredit par un document interne ; à reconfirmer sur le code courant | SEC-003 |
| `secret_ref` non résolu | Confirmé pour l'absence de résolveur ; nature de la valeur non vérifiable | SEC-004 |
| Proxy, préfixe d'API, URL de base d'import en production | Confirmé en développement (ARCH-001, 002, 003 : problèmes fonctionnels) ; Caddy de production non vérifiable | H-08 |
| Ingestion factice ; état d'import en thread et dictionnaire | Confirmé (rapporté) ; l'ingestion factice est un défaut fonctionnel hors périmètre sécurité | SEC-010 |
| Identifiant de démonstration ; mot de passe provisoire constant ; auto-activation OAuth | Démonstration : confirmé, atténué. Provisoire constant : confirmé par un document interne seulement. Auto-activation OAuth : non vérifiable (absente du zip) | SEC-012, SEC-011, H-05 |
| Cloisonnement Neo4j (`graph_repo.py`), `graph_id` | Non vérifiable | H-01 |
| DDL de démarrage parallèle à Alembic ; absence de sauvegarde Neo4j | Confirmés (rapporté) | SEC-014, SEC-009 |

## Findings
Voir `findings/INDEX.md` (16 fiches) et `findings.json` (format machine).

## Hypothèses à vérifier
Voir `findings/INDEX.md` (H-01 à H-08).

## Limites
Pas de code, pas de proxy de production, pas d'exécution d'outil ; les faits peuvent avoir évolué depuis le 2026-10-01 (registre de sessions du chantier non inclus).

## Prochaines étapes
1. Fournir le code ciblé et la configuration Caddy ; relancer l'audit sur ces fichiers pour lever H-01 à H-08.
2. Lancer les outils listés dans `evidence/commands.md` dans un job CI dédié.
3. Intégrer les lots de `09-remediation-roadmap.md` au backlog (le lot L1 manque au plan actuel).

## Auto-contrôle (§13 du prompt)

- [x] Chaque ligne des checklists porte un verdict et une preuve ou une raison (57 sur 57).
- [~] Chaque finding cite des `fichier:ligne` : oui, mais **rapportés par l'audit d'architecture**, non revérifiés ; quelques références n'ont pas de numéro de ligne (fichiers de dépendances, configuration) car l'audit n'en donne pas.
- [x] Aucun secret ni valeur sensible reproduit.
- [x] Les findings HAUTE ont un contre-check ; tous les findings en ont un.
- [ ] **Table de routes complète : non satisfait**, faute de code (voir `02`).
- [x] Chaque constat antérieur du §4 est confirmé, infirmé ou marqué non vérifiable (tableau ci-dessous).
- [x] Les commandes non exécutées sont listées, aucun résultat d'outil inventé.
- [x] Recommandations avec ordre, effort et test de vérification.
- [x] Limites écrites en clair.
- [x] Findings reliés à `plan-testing.md` (`10`).
