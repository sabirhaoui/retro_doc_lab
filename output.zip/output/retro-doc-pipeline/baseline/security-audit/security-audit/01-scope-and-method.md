# 01 - Périmètre et méthode

## Entrées effectivement lues
`architecture-audit.zip` (54 fichiers, 252 Ko) : `00` à `22`, `FINAL-REPORT.md`, `STATE.md`, `findings/ARCH-001` à `ARCH-015` et `INDEX.md`, `evidence/ledger.md` (E-001 à E-027) et `commands.md`, 9 diagrammes Mermaid dont `diagrams/authentication/ReadMe.md`.

## Entrées absentes
Code backend et frontend, `docker-compose*.yml`, `Dockerfile*`, `azure-pipelines.yml`, configurations Nginx et Caddy, `requirements*.txt`, `package.json`, OpenAPI généré, `solution-analysis/`, `Plan.md`, `plan-testing.md` (ces deux derniers sont utilisés comme référentiel de tests, connus de la conversation mais non présents dans le zip), `.env` (jamais lus).

## Méthode appliquée
- **Phase 0** : cadrage (ce document).
- **Phase 1** : surface d'attaque reconstituée depuis les documents (`02`). L'inventaire exhaustif des routes est impossible sans le code.
- **Phase 2** : modèle de menaces STRIDE sur 10 flux (`03`).
- **Phase 3** : 57 contrôles de checklist (`04` à `07`), chacun avec un verdict et une preuve ou une raison.
- **Phase 4** : 16 findings qualifiés (`findings/`), reclassements justifiés, contre-check rédigé pour chaque finding.
- **Phase 5** : feuille de route et tests (`09`, `10`).

## Règles de qualification utilisées
- Un fait est « rapporté » : il vient de l'audit d'architecture avec sa référence `fichier:ligne`, sans revérification.
- Les sévérités reprennent le barème du prompt (HAUTE exige un impact fort sur la confidentialité ou l'intégrité ou une SSRF vers l'interne ; CRITIQUE exige un chemin complet démontré). Trois reclassements par rapport à l'audit d'architecture sont expliqués : ARCH-010 (HIGH vers MOYENNE : résilience), ARCH-007 (MEDIUM, avec condition de passage en HAUTE), ARCH-008 (HIGH fonctionnel, hors périmètre sécurité).
- Les points sans preuve sont des **hypothèses H-xx**, pas des findings.

## Limites
Audit statique et documentaire, sans exécution ni accès au code. Les faits peuvent avoir changé depuis le 2026-10-01 (le chantier de registre de sessions est postérieur). Caddy, Azure DevOps et les sauvegardes hors dépôt ne sont pas vérifiables. Aucun secret n'a été lu ni reproduit ; la valeur du credential de démonstration (ARCH-015) est absente des documents.
