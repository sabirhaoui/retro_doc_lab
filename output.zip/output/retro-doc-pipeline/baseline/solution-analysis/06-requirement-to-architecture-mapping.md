# 06 - Requirement to architecture mapping

| Requirement / US | Existing component | Reusable capability | Missing capability | Change required |
| --- | --- | --- | --- | --- |
| US01.1.01 | `backend/app/api/auth_router.py`, `frontend/src/app/services/auth.service.ts` | login flow, JWT issuance | external SSO / IdP gateway | add OIDC-compatible adapter and route handling |
| US01.1.02 | `backend/app/core/config.py`, `backend/app/core/security.py` | expiring JWTs | explicit session invalidation + inactivity policy | add server-side session registry |
| US01.1.03 | `backend/app/repositories/user_repo.py`, `workspace_repo.py` | user role access model | active-session revocation and audit log | add revocation + audit event model |
| US01.1.04 | `backend/app/models/orm/user.py` | roles and user table | technical account scopes and non-interactive restrictions | extend user model with account type / scopes |
| US01.2.01 | `workspace_router.py`, `workspace_repo.py` | workspace CRUD | archive-only lifecycle / metadata model | add workspace lifecycle states |
| US01.2.02 | `user_workspace_association`, `authorization.py` | membership relation | history + explicit remove/revocation behavior | add membership audit and access checks |
| US01.2.03 | workspace routes + UI navigation | selected workspace context | project/environment context structure | add context model and selector state |
| US01.2.04 | `authorization.py`, `assert_workspace_access()` | access check | end-to-end cross-workspace security tests and documentation | add test matrix + enforced checks |
| US01.2.05 | `frontend/src/app/pages/admin/users/admin-users.component.ts`, workspace membership API | user administration and workspace membership | visual reassignment between projects and named groups | add permission-checked drag-and-drop, scoped groups, atomic membership updates, and audit events |

## Observed implementation pattern

The code already contains a solid foundation for per-workspace enforcement, but the enterprise backlog needs a more explicit security and governance layer above that foundation.

## Key conclusion

No large-scale rewrite is required; the work is better framed as an incremental hardening of the current auth/workspace model with a secure identity integration and auditing layer.
