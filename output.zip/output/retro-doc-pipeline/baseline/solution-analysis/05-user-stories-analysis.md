# 05 - User stories analysis

## US01.1.01 — Se connecter via le SSO d'entreprise

- As a user, I want to authenticate with the enterprise SSO.
- Current state: username/password login is implemented in the backend and frontend. See `E-004`, `E-005`, `E-009`.
- Gap: no external IdP/OIDC/SAML flow is present in the code.
- Impact: enterprise trust, session management, and auditability are not yet aligned with the backlog.

## US01.1.02 — Gérer l'expiration et la fermeture de session

- As a user, I want session expiration and logout to reduce unauthorized access.
- Current state: JWT tokens have expiry configured in `settings` (`ACCESS_TOKEN_EXPIRE_MINUTES` and `REFRESH_TOKEN_EXPIRE_DAYS`). See `E-003`, `E-004`.
- Gap: server-side invalidation and configurable inactivity policy are not implemented as an explicit session registry.

## US01.1.03 — Révoquer immédiatement les accès d'un utilisateur

- As an administrator, I want to immediately revoke active sessions.
- Current state: user roles and workspace access exist, but there is no active-session revocation mechanism or audit log for access revocation.
- Gap: no token revocation or session list management is implemented.

## US01.1.04 — Gérer les comptes techniques

- As an administrator, I want technical accounts with restricted scopes.
- Current state: roles exist via `Role` and `User`, but no explicit technical account model or scope enforcement is visible.
- Gap: account type and scope model are not implemented.

## US01.2.01 — Créer et administrer un workspace

- As an administrator, I want workspace creation and administration.
- Current state: workspace create/list/update/delete logic exists in the API and repository. See `E-006`, `E-007`, `E-008`.
- Gap: archive-only lifecycle and project/environment metadata are not explicitly implemented in the checked-in model.

## US01.2.02 — Rattacher des utilisateurs à un workspace

- As an administrator, I want to attach/remove users from workspaces.
- Current state: the `user_workspace` association exists in `workspace.py`, and access checks use workspace membership. See `E-006`, `E-007`.
- Gap: no explicit membership history, revocation event stream, or audit trail is visible in the code.

## US01.2.03 — Sélectionner le contexte de travail actif

- As a user, I want to select the active workspace/project/environment.
- Current state: the application exposes workspace retrieval and guard-based navigation, but no explicit context selector model is evident.
- Gap: the current API is workspace-centric rather than fully context-specific (workspace/project/environment). 

## US01.2.04 — Garantir l'isolation logique entre workspaces

- As an RSSI, I want cross-workspace data isolation.
- Current state: workspace access is checked through `assert_workspace_access()` and `accessible_workspace_ids()`. See `E-006`.
- Gap: there is no evidence of automated cross-workspace regression tests or a broader authorization model covering all data-access operations.

## Summary

The backlog is valid and well-ordered. The repository already covers the baseline workspace and JWT foundation, while the enterprise-grade requirements in the backlog still need a focused improvement plan.
