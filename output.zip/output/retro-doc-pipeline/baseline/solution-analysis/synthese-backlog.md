# Synthèse de l'échange et amorce du backlog (chantier authentification, droits et licences - Assystan)

> **Pour le LLM ou l'agent destinataire.** Ce document est la synthèse d'une session de conception avec un assistant. Il sert à générer les éléments de gestion de projet : backlog, sprints, calendrier des réunions, critères d'acceptation, registre des risques. Un fichier compagnon `backlog-seed.json` contient la même décomposition sous forme structurée.
> **Règles de lecture :**
> - Aucune réunion n'a eu lieu : les cérémonies de la section 7 sont des **propositions**.
> - Aucune estimation n'a été validée par une équipe : les tailles (S, M, L) sont **indicatives**, à recaler en raffinement.
> - Rien n'a été exécuté (ni code, ni CI, ni migration) : tous les livrables sont des conceptions.
> - Toute information marquée « hypothèse » ou « question ouverte » ne doit pas être présentée comme une décision.

## 1. Contexte

- **Projet :** Assystan, en phase de POC.
- **Stack :** frontend Angular ; backend FastAPI ; PostgreSQL (comptes, ACL, état applicatif) ; Neo4j (graphes) ; Redis et Celery ; CI/CD Azure Pipelines (`azure-pipelines.yml`) ; scripts de release en shell ; environnement de travail Windows et PowerShell.
- **Besoin exprimé :** intégrer le processus d'authentification pour créer les droits des utilisateurs, les licences et le parcours d'activation d'un compte.
- **Contrainte :** pas de machine de développement locale configurée pour tester. La conception est donc faite « de façon théorique », et l'exécution des tests passera par la CI.
- **Sources fournies :** le plan de mise en œuvre initial (RBAC et licences JSONB, quatre phases), un zip contenant l'audit d'architecture (`architecture-audit/`) et l'analyse de solution (`solution-analysis/`, dont `FINAL-SOLUTION.md`, `Plan.md`, `OPEN-QUESTIONS.md`, `HANDOFF.md`).

## 2. État des lieux constaté dans les documents

**Existant :** connexion locale par JWT avec cookie de rafraîchissement HttpOnly ; connexion Microsoft OAuth ; rôles ; ACL de workspace (viewer, éditeur, owner) ; création d'utilisateur par un admin avec invitation et page `setup-account`.

**Code écrit mais jamais vérifié (d'après `HANDOFF.md`) :** registre de sessions révocables, audit, migration `0025_auth_sessions` (statut `DONE-UNVERIFIED`).

**Constats de l'audit utiles au chantier :**
- ARCH-006 : un compte désactivé conserve l'accès tant que son access token est valide.
- ARCH-009 : le DDL au démarrage coexiste avec Alembic.
- ARCH-014 : les tests d'intégration PostgreSQL ne sont pas dans le gate CI ; la couverture Jest est désactivée.
- HANDOFF : le cycle invité/désactivé (`TASK-001B`) n'est pas implémenté ; le mot de passe provisoire est un texte constant ; OAuth Microsoft auto-active un compte `is_active=False`.
- Aucune sauvegarde Neo4j dans le dépôt.

**Manques :** licences, permissions fines, parcours d'activation sûr, cloisonnement côté graphe, contrôles d'accès par module côté Angular.

## 3. Revue initiale du plan fourni

Écarts relevés entre le plan initial et les documents, devenus des éléments de backlog :

1. `FINAL-SOLUTION.md` contient deux solutions (SSO/OIDC avec sessions, et RBAC avec licences) : seule la seconde était reprise.
2. La révocation immédiate manquait côté serveur (en partie traitée par le registre de sessions, à vérifier).
3. Les licences ne doivent pas vivre dans le JWT (obsolescence) : relecture en base à chaque requête.
4. Le cloisonnement doit aussi couvrir Neo4j (`graph_repo.py`).
5. Retour 404 plutôt que 403 pour un workspace non autorisé (anti-énumération).
6. Le lien d'activation dans les logs doit être limité au développement.
7. L'envoi d'e-mail asynchrone n'avait pas de tâche (Celery et Redis existent).
8. La migration Alembic doit être coordonnée avec le DDL de démarrage.
9. Les tests d'intégration PostgreSQL doivent d'abord tourner en CI.
10. Le seed SQL de comptes techniques ne doit pas contenir de secrets : fixtures générées à l'exécution.
Points de forme : critères de sortie par phase manquants.

## 4. Objectif et périmètre

**Dans le périmètre :** statut de compte (`invited`, `active`, `disabled`) ; activation par jeton et par SSO ; licences par utilisateur ; permissions dérivées de rôle et niveau de workspace ; contrôle côté API ; endpoint `/auth/me` ; endpoints d'administration ; cloisonnement des workspaces dans PostgreSQL et Neo4j ; frontend dynamique (guards, menu, administration, déconnexion sur inactivité) ; contrat OpenAPI ; CI avec tests d'intégration ; plan de tests et dashboard.

**Hors périmètre ou reporté :** OIDC générique (l'adaptateur Microsoft suffit tant que Q-001 est ouverte) ; comptes techniques ; glisser-déposer et groupes (`TASK-006`) ; contexte projet/environnement ; modèle d'organisation pour les licences (dépend de Q-A).

## 5. Décisions de conception proposées (à valider en revue CR-02)

Ces éléments sont des **propositions de l'assistant**, non encore validées par l'équipe :

| Réf. | Proposition | Justification |
|---|---|---|
| D-01 | Trois axes séparés : rôle (global), appartenance et niveau de workspace (données), licence (modules) | Évite trois systèmes qui se chevauchent |
| D-02 | Pas de colonne JSONB `permissions` : permissions dérivées d'une table statique dans le code | Simplicité, audit par revue de code |
| D-03 | Licences dans une table `user_licenses` (expiration, révocation, auteur) plutôt qu'un JSONB sur `users` | Traçabilité et expiration |
| D-04 | Statut de compte en enum ; mot de passe nullable ; `is_active` dérivé puis supprimé (0027) | Distingue invité et désactivé |
| D-05 | Jeton d'activation à usage unique, stocké haché, consommation atomique, réponse générique | Sécurité et anti-énumération |
| D-06 | Licence relue en base à chaque requête, jamais dans le JWT | Révocation immédiate |
| D-07 | Une chaîne de dépendances FastAPI : session et statut, puis rôle, licence, appartenance au workspace | Un seul point de contrôle |
| D-08 | Garde-fous : flags `AUTHZ_ENFORCE_LICENSES` et `authz.enforceLicenses` à `false` par défaut | Livrer sans changer le comportement visible |
| D-09 | Nouveau schéma uniquement via Alembic, jamais via le DDL de démarrage | ARCH-009 |
| D-10 | Désactivation = changement de statut et révocation des sessions dans la même transaction | Pas d'état partiel |
| D-11 | Seeds de test : fixtures générées à l'exécution, aucun hash ni mot de passe versionné | Sécurité |

**Hypothèses non vérifiées :** les chemins de fichiers cités (par exemple `backend/app/identity/dependencies.py`) sont déduits des documents ; la variable de connexion des tests est supposée être `POSTGRES_URI` avec le driver `psycopg2` ; la migration `0026` suppose que `0025` est la précédente ; les noms de services Angular sont supposés.

## 6. Questions ouvertes

| Réf. | Question | Impact | Décideur suggéré |
|---|---|---|---|
| Q-001 | Quel fournisseur d'identité d'entreprise est visé (Microsoft seul ou OIDC générique) et quelles règles de tenant, domaine et provisioning ? | Bloque FT-08, influence FT-04 | Tech lead, sécurité |
| Q-A | Les licences sont-elles attachées à l'utilisateur (hypothèse retenue) ou à une organisation avec attribution de places ? | Change le modèle de FT-02 et FT-06 | PO |
| Q-B | Quelle liste de modules licenciables (studio_v2, analytics, ...) ? | Alimente l'enum de licences | PO |
| Q-C | Un dernier administrateur peut-il être désactivé ou perdre son rôle ? | Règle de FT-07 | PO, sécurité |
| Q-D | Un administrateur plateforme a-t-il un accès implicite aux données d'un workspace ? | Règle de FT-09 | Sécurité |
| Q-E | Durée de validité d'une invitation, politique de mot de passe, durée d'inactivité et durée absolue de session ? | Paramètres de FT-04, FT-14 | PO, sécurité |
| Q-F | Le dépôt est-il dans Azure Repos (politiques de branches par az) ou ailleurs (règles différentes) ? | Valide GV-02, GV-03 | Tech lead |
| Q-G | Où exécuter les tests sans machine locale : CI seule, devcontainer ou serveur de dev ? | Rythme de validation de toutes les branches | Tech lead |
| Q-H | Neo4j : sauvegarde avant migration (hors périmètre du dépôt, signalé par l'audit) ? | Risque de livraison | DevOps |

## 7. Réunions et cérémonies proposées

| Réf. | Réunion | Quand | Participants suggérés | Objectif | Entrées | Sorties |
|---|---|---|---|---|---|---|
| CR-01 | Atelier de cadrage / kick-off | Sprint 0 | PO, tech lead, développeurs back et front, sécurité | Valider périmètre, trois axes de droits, plan de branches | Plan.md, plan-testing.md, synthèse | Décisions CN-01 à CN-05, périmètre figé |
| CR-02 | Revue de conception (ADR) | Sprint 0 à 1 | Tech lead, développeurs, sécurité | Valider modèle de données, jetons, contrat d'API | ADR, diagramme de séquence, fiches ARCH | ADR validé, contrat d'API validé |
| CR-03 | Revue sécurité de conception | Avant les branches 04 et 06 | Sécurité, tech lead | Contrôler énumération, jetons, 404, logs, expurgation | ADR, checklist PR | Liste d'exigences sécurité intégrée aux critères d'acceptation |
| CR-04 | Raffinement du backlog | Chaque sprint | PO, tech lead, équipe | Découper, estimer, recaler les tailles proposées | Backlog, dépendances | Éléments prêts (Definition of Ready) |
| CR-05 | Planification de sprint | Début de sprint | Équipe complète | Engager un périmètre selon la capacité réelle | Backlog raffiné, vagues du plan | Objectif de sprint, éléments engagés |
| CR-06 | Point quotidien | Quotidien, 15 minutes | Équipe | Débloquer, synchroniser les branches | Tableau, dashboard de tests | Blocages identifiés |
| CR-07 | Revue de code (pull request) | Continue, selon les PR | Auteur et relecteurs | Valider le comportement, les tests et la sécurité | PR, checklist du modèle, CI verte | PR approuvée ou corrigée |
| CR-08 | Revue de gate (go / no-go de branche) | Fin de chaque branche | Tech lead, relecteur, testeur | Décider du merge à partir du dashboard | Dashboard, rapport de gate | Merge autorisé ou refusé avec raisons |
| CR-09 | Revue de sprint / démonstration | Fin de sprint | Équipe, parties prenantes | Montrer les comportements livrés | Environnement de dev, flags | Retours, ajustements du backlog |
| CR-10 | Rétrospective | Fin de sprint | Équipe | Améliorer le processus (CI, taille des PR, flakiness) | Métriques du dashboard | Actions d'amélioration |
| CR-11 | Revue de pré-livraison vers dev | Après la branche 15 | Équipe, sécurité | Valider flags activés, matrice E2E, plan de retour arrière | Rapport final de test | Décision de PR integration vers dev |
| CR-12 | Point de déploiement et de communication | Avant la livraison finale | Tech lead, support, PO | Préparer la reconnexion générale et le retour arrière | Plan de déploiement (CN-10) | Communication validée |

## 8. Livrables déjà produits dans la session

Tous sont des conceptions, **aucun n'a été exécuté**.

| Fichier | Contenu | Statut |
|---|---|---|
| auth-licences-sequence.mermaid | Diagramme de séquence du comportement cible (invitation, activation, connexion, licence, révocation) | Proposé, non validé |
| pull_request_template.md | Modèle de PR et checklist (tests, migration, sécurité, retour arrière) | Proposé, non déployé |
| azure-pipelines-authz-jobs.yml | Jobs CI : intégration PostgreSQL, migrations, nommage des branches | Proposé, non exécuté |
| set-branch-policies.ps1 | Politiques de branches Azure Repos (az repos policy) | Proposé, non exécuté |
| Plan.md | Mise en place locale des 18 branches, sous-fonctions et PR (fonctions PowerShell) | Proposé, non exécuté |
| plan-testing.md | Plan de tests pour un agent : 154 cas, 15 scénarios, diagnostic, dashboard | Proposé, non exécuté |

## 9. Structure du backlog

Hiérarchie proposée : **Epic > Feature > Tâche**. Une Feature correspond à une branche `authz-NN` (identifiant `FT-NN`). Une tâche correspond à une sous-fonction (identifiant `FT-NN.x`, un commit chacune). Chaque Feature porte son module de test (`T-NN-*`) et sa gate.

### 9.1 Epics

| Epic | Titre | Features |
|---|---|---|
| EP-0 | Cadrage et conception | - |
| EP-1 | Fondations CI et qualité | FT-00, FT-01 |
| EP-2 | Modèle de données et droits | FT-02, FT-03 |
| EP-3 | Cycle de vie du compte et activation | FT-04, FT-05, FT-08 |
| EP-4 | Licences et API d'administration | FT-06, FT-07, FT-10 |
| EP-5 | Cloisonnement des workspaces | FT-09 |
| EP-6 | Frontend dynamique | FT-11, FT-12, FT-13, FT-14 |
| EP-7 | Validation, tests et dashboard | FT-15 |
| EP-8 | Documentation et clôture | FT-16, FT-17 |
| EP-9 | Gouvernance de livraison | - |

### 9.2 EP-0 - Cadrage et conception

| ID | Tâche | Activité | Réunion ou question liée |
|---|---|---|---|
| CN-01 | Atelier de cadrage : valider le périmètre (RBAC + licences + activation) et ce qui est reporté | Conception | CR-01 |
| CN-02 | Décider : licences attachées à l'utilisateur ou à une organisation | Conception | Q-A |
| CN-03 | Décider : fournisseur d'identité et règles SSO (Q-001) : tenant, domaine, provisioning | Conception | Q-001 |
| CN-04 | Décider : règles d'administration (dernier admin protégé, accès admin aux données de workspace) | Conception | Q-C, Q-D |
| CN-05 | Décider : durée de l'invitation, politique de mot de passe, durée d'inactivité et durée absolue de session | Conception | Q-E |
| CN-06 | Confirmer l'hébergement du dépôt (Azure Repos ou autre) et l'accès à la CI et au CD | Conception | Q-F |
| CN-07 | Rédiger l'ADR du modèle de droits (rôle, workspace, licence ; permissions dérivées du code) | Conception | — |
| CN-08 | Revue de conception sécurité : jetons, énumération, 404, logs, expurgation | Review | CR-03 |
| CN-09 | Valider le contrat d'API cible (/auth/me, endpoints admin, erreurs structurées) | Conception | — |
| CN-10 | Définir le plan de déploiement et de communication (reconnexion générale, retour arrière) | Conception | CR-12 |

### 9.3 EP-9 - Gouvernance de livraison

| ID | Tâche | Activité |
|---|---|---|
| GV-01 | Créer la branche d'intégration integration/authz-licences | DevOps |
| GV-02 | Appliquer les politiques de branches (set-branch-policies.ps1) après relecture | DevOps |
| GV-03 | Déposer le modèle de PR dans .azuredevops/ et vérifier son affichage | DevOps |
| GV-04 | Ajouter scripts/authz-git.ps1 (fonctions d'aide) et valider sur une branche test | DevOps |
| GV-05 | Vérifier le nom du pipeline, les droits de build validation et les environnements de dev | DevOps |
| GV-06 | Définir les valeurs des flags par environnement (AUTHZ_ENFORCE_LICENSES, authz.enforceLicenses) | DevOps |

### 9.4 Vue d'ensemble des Features (branches)

Tailles indicatives (S, M, L), à recaler en raffinement. La colonne « Cas de test » donne le nombre de cas du module correspondant dans `plan-testing.md` (la Feature 15 est validée par les 15 scénarios F-01 à F-15).

| Feature | Branche | Titre | Dépend de | Taille | Cas de test | Gate de validation |
|---|---|---|---|---|---|---|
| FT-00 | `ci/authz-00-postgres-integration-job` | Job CI PostgreSQL pour les tests d'intégration | - | M | 7 | Baseline CI documentée ; le job échoue sur un test volontairement cassé ; aucun test ignoré. |
| FT-01 | `fix/authz-01-session-registry-baseline` | Valider le registre de sessions existant (migration 0025) | FT-00 | M | 11 | alembic upgrade/downgrade de 0025 et tests auth/sessions verts en CI. |
| FT-02 | `feat/authz-02-db-schema` | Schéma de données : statut, licences, jetons (migration 0026) | FT-01 | M | 12 | Migration testée sur des données invitées, actives et désactivées ; downgrade vérifié ; une seule tête Alembic. |
| FT-03 | `feat/authz-03-permissions-core` | Noyau de permissions : rôle, niveau de workspace, authorize() | FT-00 | S | 9 | Tests unitaires purs (sans base de données) verts, table rôle/niveau exhaustive. |
| FT-04 | `feat/authz-04-account-lifecycle` | Cycle de vie du compte : statut vérifié, jetons, setup-account | FT-02 | L | 16 | invited et disabled refusés au login, au refresh et sur un access token émis ; jeton rejoué ou concurrent géré. |
| FT-05 | `feat/authz-05-email-async` | Envoi asynchrone de l'e-mail d'invitation (Celery) | FT-04 | S | 8 | Panne SMTP simulée : la création renvoie 201 et l'échec est audité ; lien loggé uniquement en développement. |
| FT-06 | `feat/authz-06-api-license-enforcement` | Routes de l'API : licences, /auth/me, flag backend | FT-02, FT-03, FT-04 | L | 14 | 403 {code: license_required} avec flag actif ; comportement strictement inchangé flag off. |
| FT-07 | `feat/authz-07-admin-user-endpoints` | Endpoints d'administration des utilisateurs | FT-04, FT-06 | L | 14 | Désactivation : session morte à la requête suivante ; licences remplacées avec audit du différentiel. |
| FT-08 | `feat/authz-08-sso-activation` | Activation via Microsoft SSO | FT-04 | M | 8 | Un invited s'active si l'e-mail correspond ; un disabled ou inconnu n'est jamais activé ; réponse sans détail. |
| FT-09 | `feat/authz-09-graph-isolation` | Cloisonnement des workspaces dans Neo4j | FT-03 | M | 10 | Aucune lecture ou écriture de graphe possible hors des workspaces de l'utilisateur ; 404 pour un workspace non autorisé. |
| FT-10 | `chore/authz-10-openapi-contract` | Contrat OpenAPI figé et contrôlé en CI | FT-06, FT-07 | S | 6 | La CI échoue si le contrat dérive ; /auth/me et les endpoints admin sont documentés. |
| FT-11 | `feat/authz-11-front-auth-store` | Frontend : AuthStore, /auth/me, intercepteur | FT-10 | M | 9 | Tests Jest verts avec /auth/me simulé ; 401 et 403 gérés de façon centralisée. |
| FT-12 | `feat/authz-12-front-guards-menu` | Frontend dynamique : guards, menu, page non autorisé | FT-11 | M | 9 | Menu et routes suivent les licences ; flag off = interface actuelle ; guards testés. |
| FT-13 | `feat/authz-13-front-admin-ui` | Frontend : écrans d'administration des utilisateurs | FT-11 | M | 8 | Invitation, renvoi, désactivation et licences utilisables depuis l'interface ; tests de composants verts. |
| FT-14 | `feat/authz-14-front-autologout` | Frontend : déconnexion sur inactivité | FT-11 | S | 7 | Timers simulés vérifiés ; appel à POST /auth/logout ; avertissement avant expiration. |
| FT-15 | `test/authz-15-e2e-matrix` | Matrice de tests E2E rôle × licence × workspace | FT-07, FT-08, FT-09, FT-12, FT-13, FT-14 | L | 15 scénarios | Matrice complète verte en CI ; comptes de test générés à l'exécution, aucun secret versionné. |
| FT-16 | `docs/authz-16-docs-adr` | Documentation et décisions d'architecture | FT-15 | S | 3 | Relecture validée ; fiches d'audit concernées mises à jour. |
| FT-17 | `chore/authz-17-drop-is-active` | Suppression de is_active (migration 0027) | FT-16 | S | 3 | À livrer dans une release suivante, après une période sans incident ; downgrade testé. |

### 9.5 Détail des Features

Pour chaque Feature : récit utilisateur, références d'audit, flag éventuel, puis tâches par activité. Les messages de commit sont conformes à Conventional Commits.


#### FT-00 - Job CI PostgreSQL pour les tests d'intégration

- **Récit :** En tant qu'équipe, nous voulons que la CI exécute les tests d'intégration PostgreSQL et les migrations, afin qu'une PR verte prouve réellement le comportement.
- **Branche :** `ci/authz-00-postgres-integration-job` ; **Epic :** EP-1
- **Dépend de :** aucune ; **Taille indicative :** M
- **Références :** ARCH-014 ; **Flag :** —
- **Critère d'acceptation (gate) :** Baseline CI documentée ; le job échoue sur un test volontairement cassé ; aucun test ignoré.
- **Tests associés :** module 00 (7 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-00.a | ci(authz): ajoute le conteneur PostgreSQL et le job backend_integration | DevOps | azure-pipelines.yml |
| FT-00.b | ci(authz): refuse les tests ignorés via le rapport JUnit | DevOps | azure-pipelines.yml |
| FT-00.c | ci(authz): ajoute le job backend_migrations (tête unique, upgrade/downgrade/upgrade) | DevOps | azure-pipelines.yml |
| FT-00.d | ci(authz): réactive la couverture Jest dans le job frontend | DevOps | azure-pipelines.yml, frontend/package.json |
| FT-00.e | ci(authz): ajoute le job branch_naming | DevOps | azure-pipelines.yml |
| FT-00.f | docs(authz): documente la baseline CI (durée, tests, couverture) | Documentation | docs/authz/ |
| FT-00.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-00.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-01 - Valider le registre de sessions existant (migration 0025)

- **Récit :** En tant qu'équipe, nous voulons valider le registre de sessions existant (migration 0025), afin de construire les nouvelles fonctions sur une base prouvée.
- **Branche :** `fix/authz-01-session-registry-baseline` ; **Epic :** EP-1
- **Dépend de :** FT-00 ; **Taille indicative :** M
- **Références :** HANDOFF (DONE-UNVERIFIED), ARCH-006 ; **Flag :** —
- **Critère d'acceptation (gate) :** alembic upgrade/downgrade de 0025 et tests auth/sessions verts en CI.
- **Tests associés :** module 01 (11 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-01.a | test(authz): ajoute les tests de migration 0025 (up/down) | Testing | backend/tests/integration/ |
| FT-01.b | test(authz): couvre sid, révocation, refresh et logout | Testing | backend/tests/ |
| FT-01.c | fix(authz): corrige les écarts révélés par la CI (corrections seules, pas de nouvelle fonctionnalité) | Development | backend/app/ |
| FT-01.d | docs(authz): passe les éléments du HANDOFF de DONE-UNVERIFIED à vérifié | Documentation | solution-analysis/implementation/HANDOFF.md |
| FT-01.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-01.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-02 - Schéma de données : statut, licences, jetons (migration 0026)

- **Récit :** En tant qu'équipe, nous voulons un schéma avec statut de compte, licences et jetons, afin de représenter invitation, désactivation et droits.
- **Branche :** `feat/authz-02-db-schema` ; **Epic :** EP-2
- **Dépend de :** FT-01 ; **Taille indicative :** M
- **Références :** ARCH-009, TASK licences ; **Flag :** —
- **Critère d'acceptation (gate) :** Migration testée sur des données invitées, actives et désactivées ; downgrade vérifié ; une seule tête Alembic.
- **Tests associés :** module 02 (12 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-02.a | feat(authz): ajoute l'enum user_status et la colonne users.status avec règle de rattrapage | Development | backend/alembic/versions/0026_*.py |
| FT-02.b | feat(authz): rend hashed_password nullable et remplace le placeholder par NULL | Development | backend/alembic/versions/0026_*.py |
| FT-02.c | feat(authz): crée la table user_licenses | Development | backend/alembic/versions/0026_*.py, backend/app/models/ |
| FT-02.d | feat(authz): crée la table account_tokens (token_hash unique) | Development | backend/alembic/versions/0026_*.py, backend/app/models/ |
| FT-02.e | refactor(authz): is_active devient une propriété dérivée de status | Development | backend/app/models/user.py |
| FT-02.f | test(authz): teste la migration et la règle de rattrapage | Testing | backend/tests/integration/ |
| FT-02.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-02.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-03 - Noyau de permissions : rôle, niveau de workspace, authorize()

- **Récit :** En tant que développeur, je veux un point unique d'autorisation (rôle plus niveau de workspace), afin d'éviter des règles dispersées.
- **Branche :** `feat/authz-03-permissions-core` ; **Epic :** EP-2
- **Dépend de :** FT-00 ; **Taille indicative :** S
- **Références :** TASK RBAC ; **Flag :** —
- **Critère d'acceptation (gate) :** Tests unitaires purs (sans base de données) verts, table rôle/niveau exhaustive.
- **Tests associés :** module 03 (9 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-03.a | feat(authz): ajoute l'enum Permission | Development | backend/app/identity/permissions.py |
| FT-03.b | feat(authz): ajoute ROLE_PERMS et LEVEL_PERMS | Development | backend/app/identity/permissions.py |
| FT-03.c | feat(authz): ajoute authorize(user, permission, workspace_id) | Development | backend/app/identity/ |
| FT-03.d | test(authz): tests unitaires de la matrice rôle et niveau | Testing | backend/tests/unit/ |
| FT-03.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-03.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-04 - Cycle de vie du compte : statut vérifié, jetons, setup-account

- **Récit :** En tant qu'utilisateur invité, je veux activer mon compte par un lien sécurisé ; en tant qu'admin, je veux que les comptes invités ou désactivés n'accèdent à rien.
- **Branche :** `feat/authz-04-account-lifecycle` ; **Epic :** EP-3
- **Dépend de :** FT-02 ; **Taille indicative :** L
- **Références :** ARCH-006, TASK-001B, HANDOFF ; **Flag :** —
- **Critère d'acceptation (gate) :** invited et disabled refusés au login, au refresh et sur un access token émis ; jeton rejoué ou concurrent géré.
- **Tests associés :** module 04 (16 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-04.a | fix(authz): get_current_user vérifie la session active et status=active | Development | backend/app/identity/dependencies.py |
| FT-04.b | feat(authz): ajoute le dépôt account_tokens (hachage, consommation atomique) | Development | backend/app/repositories/ |
| FT-04.c | feat(authz): ajoute POST /v1/auth/setup-account (réponse générique) | Development | backend/app/api/ |
| FT-04.d | fix(authz): login et refresh refusent invited et disabled | Development | backend/app/api/auth*.py |
| FT-04.e | feat(authz): émet les événements d'audit user.activated | Development | backend/app/repositories/ |
| FT-04.f | test(authz): rejeu, concurrence, expiration, comptes invalides | Testing | backend/tests/ |
| FT-04.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-04.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-05 - Envoi asynchrone de l'e-mail d'invitation (Celery)

- **Récit :** En tant qu'admin, je veux que l'invitation parte par e-mail sans ralentir ni bloquer la création du compte.
- **Branche :** `feat/authz-05-email-async` ; **Epic :** EP-3
- **Dépend de :** FT-04 ; **Taille indicative :** S
- **Références :** INT-CELERY-01 ; **Flag :** —
- **Critère d'acceptation (gate) :** Panne SMTP simulée : la création renvoie 201 et l'échec est audité ; lien loggé uniquement en développement.
- **Tests associés :** module 05 (8 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-05.a | feat(authz): ajoute la tâche Celery send_invitation_email | Development | backend/app/tasks/ |
| FT-05.b | feat(authz): repli par log du lien réservé à APP_ENV=development | Development | backend/app/services/email_service.py |
| FT-05.c | feat(authz): audite l'échec d'envoi sans annuler la création | Development | backend/app/services/ |
| FT-05.d | test(authz): tests avec SMTP simulé | Testing | backend/tests/ |
| FT-05.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-05.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-06 - Routes de l'API : licences, /auth/me, flag backend

- **Récit :** En tant que produit, nous voulons restreindre les modules aux utilisateurs licenciés côté serveur et exposer leurs droits via /auth/me.
- **Branche :** `feat/authz-06-api-license-enforcement` ; **Epic :** EP-4
- **Dépend de :** FT-02, FT-03, FT-04 ; **Taille indicative :** L
- **Références :** TASK licences, ARCH-006 ; **Flag :** AUTHZ_ENFORCE_LICENSES (backend), défaut false
- **Critère d'acceptation (gate) :** 403 {code: license_required} avec flag actif ; comportement strictement inchangé flag off.
- **Tests associés :** module 06 (14 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-06.a | feat(authz): ajoute license_repo.has_active (expiration, révocation) | Development | backend/app/repositories/ |
| FT-06.b | feat(authz): ajoute require_license et l'audit access.denied_license | Development | backend/app/identity/dependencies.py |
| FT-06.c | feat(authz): ajoute le flag AUTHZ_ENFORCE_LICENSES | Development | backend/app/core/config.py |
| FT-06.d | refactor(authz): applique require_license au niveau des routeurs concernés | Development | backend/app/api/ |
| FT-06.e | feat(authz): ajoute GET /v1/auth/me (statut, rôle, licences, permissions) | Development | backend/app/api/ |
| FT-06.f | test(authz): 403 structuré, flag off inchangé, licence expirée ou révoquée | Testing | backend/tests/ |
| FT-06.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-06.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-07 - Endpoints d'administration des utilisateurs

- **Récit :** En tant qu'admin, je veux inviter, renvoyer, désactiver et gérer les licences via l'API.
- **Branche :** `feat/authz-07-admin-user-endpoints` ; **Epic :** EP-4
- **Dépend de :** FT-04, FT-06 ; **Taille indicative :** L
- **Références :** TASK-001B, TASK licences ; **Flag :** —
- **Critère d'acceptation (gate) :** Désactivation : session morte à la requête suivante ; licences remplacées avec audit du différentiel.
- **Tests associés :** module 07 (14 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-07.a | feat(authz): ajoute POST /v1/admin/users (création en invited et jeton) | Development | backend/app/api/admin*.py |
| FT-07.b | feat(authz): ajoute POST /v1/admin/users/{id}/resend-invite | Development | backend/app/api/admin*.py |
| FT-07.c | feat(authz): ajoute POST /v1/admin/users/{id}/disable (révocation des sessions, même transaction) | Development | backend/app/api/admin*.py |
| FT-07.d | feat(authz): ajoute PUT /v1/admin/users/{id}/licenses (différentiel audité) | Development | backend/app/api/admin*.py |
| FT-07.e | feat(authz): ajoute la liste des utilisateurs avec statut et licences | Development | backend/app/api/admin*.py |
| FT-07.f | test(authz): contrôle d'accès admin, désactivation, renvoi, licences | Testing | backend/tests/ |
| FT-07.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-07.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-08 - Activation via Microsoft SSO

- **Récit :** En tant qu'utilisateur invité, je veux activer mon compte via Microsoft sans que cela contourne une désactivation.
- **Branche :** `feat/authz-08-sso-activation` ; **Epic :** EP-3
- **Dépend de :** FT-04 ; **Taille indicative :** M
- **Références :** Q-001 (OPEN-QUESTIONS) ; **Flag :** —
- **Critère d'acceptation (gate) :** Un invited s'active si l'e-mail correspond ; un disabled ou inconnu n'est jamais activé ; réponse sans détail.
- **Tests associés :** module 08 (8 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-08.a | feat(authz): active un compte invited au callback Microsoft (e-mail correspondant) | Development | backend/app/api/auth*.py |
| FT-08.b | fix(authz): refuse disabled et inconnu avec une réponse générique | Development | backend/app/api/auth*.py |
| FT-08.c | feat(authz): contrôle le tenant ou le domaine autorisé (à confirmer, Q-001) | Development | backend/app/core/config.py |
| FT-08.d | test(authz): tests du callback avec fournisseur simulé | Testing | backend/tests/ |
| FT-08.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-08.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-09 - Cloisonnement des workspaces dans Neo4j

- **Récit :** En tant que client, je veux que mes données de graphe ne soient accessibles qu'aux membres de mon workspace.
- **Branche :** `feat/authz-09-graph-isolation` ; **Epic :** EP-5
- **Dépend de :** FT-03 ; **Taille indicative :** M
- **Références :** TASK isolation, ARCH (graph_repo) ; **Flag :** —
- **Critère d'acceptation (gate) :** Aucune lecture ou écriture de graphe possible hors des workspaces de l'utilisateur ; 404 pour un workspace non autorisé.
- **Tests associés :** module 09 (10 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-09.a | feat(authz): applique le filtre d'appartenance dans graph_repo.py | Development | backend/app/repositories/graph_repo.py |
| FT-09.b | fix(authz): renvoie 404 pour un workspace non autorisé | Development | backend/app/api/ |
| FT-09.c | test(authz): tests de non-fuite entre workspaces | Testing | backend/tests/ |
| FT-09.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-09.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-10 - Contrat OpenAPI figé et contrôlé en CI

- **Récit :** En tant que développeur frontend, je veux un contrat d'API figé et contrôlé, afin de développer sans ambiguïté.
- **Branche :** `chore/authz-10-openapi-contract` ; **Epic :** EP-4
- **Dépend de :** FT-06, FT-07 ; **Taille indicative :** S
- **Références :** TASK-API-01 ; **Flag :** —
- **Critère d'acceptation (gate) :** La CI échoue si le contrat dérive ; /auth/me et les endpoints admin sont documentés.
- **Tests associés :** module 10 (6 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-10.a | chore(authz): génère le schéma OpenAPI | Development | backend/scripts/ |
| FT-10.b | chore(authz): versionne l'instantané de contrat | Development | docs/api/openapi.json |
| FT-10.c | ci(authz): échoue si le contrat dérive de l'instantané | DevOps | azure-pipelines.yml |
| FT-10.d | docs(authz): documente les erreurs structurées (license_required, …) | Documentation | docs/api/ |
| FT-10.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-10.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-11 - Frontend : AuthStore, /auth/me, intercepteur

- **Récit :** En tant qu'utilisateur, je veux que l'application connaisse mes droits dès la connexion et réagisse aux refus.
- **Branche :** `feat/authz-11-front-auth-store` ; **Epic :** EP-6
- **Dépend de :** FT-10 ; **Taille indicative :** M
- **Références :** TASK front ; **Flag :** —
- **Critère d'acceptation (gate) :** Tests Jest verts avec /auth/me simulé ; 401 et 403 gérés de façon centralisée.
- **Tests associés :** module 11 (9 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-11.a | feat(authz): types TypeScript issus du contrat OpenAPI | Development | frontend/src/app/core/ |
| FT-11.b | feat(authz): ajoute l'AuthStore (Signals) | Development | frontend/src/app/core/auth/ |
| FT-11.c | feat(authz): charge /auth/me après login et refresh | Development | frontend/src/app/core/auth/ |
| FT-11.d | feat(authz): intercepteur 401 (déconnexion) et 403 license_required (rafraîchit /auth/me) | Development | frontend/src/app/core/ |
| FT-11.e | test(authz): tests Jest du store et de l'intercepteur | Testing | frontend/src/app/core/ |
| FT-11.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-11.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-12 - Frontend dynamique : guards, menu, page non autorisé

- **Récit :** En tant qu'utilisateur, je veux ne voir et n'atteindre que les modules auxquels j'ai droit.
- **Branche :** `feat/authz-12-front-guards-menu` ; **Epic :** EP-6
- **Dépend de :** FT-11 ; **Taille indicative :** M
- **Références :** TASK front, TASK licences ; **Flag :** authz.enforceLicenses (environnement Angular), défaut false
- **Critère d'acceptation (gate) :** Menu et routes suivent les licences ; flag off = interface actuelle ; guards testés.
- **Tests associés :** module 12 (9 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-12.a | feat(authz): ajoute licenseGuard | Development | frontend/src/app/core/guards/ |
| FT-12.b | feat(authz): ajoute la directive *hasLicense | Development | frontend/src/app/shared/ |
| FT-12.c | feat(authz): masque dynamiquement les entrées du menu | Development | frontend/src/app/layout/ |
| FT-12.d | feat(authz): ajoute la page /unauthorized | Development | frontend/src/app/pages/ |
| FT-12.e | feat(authz): ajoute le flag authz.enforceLicenses | Development | frontend/src/environments/ |
| FT-12.f | test(authz): tests des guards et du menu selon les licences | Testing | frontend/src/app/ |
| FT-12.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-12.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-13 - Frontend : écrans d'administration des utilisateurs

- **Récit :** En tant qu'admin, je veux gérer les utilisateurs et leurs licences depuis l'interface.
- **Branche :** `feat/authz-13-front-admin-ui` ; **Epic :** EP-6
- **Dépend de :** FT-11 ; **Taille indicative :** M
- **Références :** TASK-001B, TASK licences ; **Flag :** —
- **Critère d'acceptation (gate) :** Invitation, renvoi, désactivation et licences utilisables depuis l'interface ; tests de composants verts.
- **Tests associés :** module 13 (8 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-13.a | feat(authz): liste des utilisateurs avec statut et licences | Development | frontend/src/app/admin/ |
| FT-13.b | feat(authz): formulaire d'invitation | Development | frontend/src/app/admin/ |
| FT-13.c | feat(authz): gestion des licences d'un utilisateur | Development | frontend/src/app/admin/ |
| FT-13.d | feat(authz): actions renvoyer l'invitation et désactiver | Development | frontend/src/app/admin/ |
| FT-13.e | test(authz): tests de composants (API simulée) | Testing | frontend/src/app/admin/ |
| FT-13.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-13.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-14 - Frontend : déconnexion sur inactivité

- **Récit :** En tant que responsable sécurité, je veux une déconnexion automatique après inactivité.
- **Branche :** `feat/authz-14-front-autologout` ; **Epic :** EP-6
- **Dépend de :** FT-11 ; **Taille indicative :** S
- **Références :** TASK-SESSION ; **Flag :** —
- **Critère d'acceptation (gate) :** Timers simulés vérifiés ; appel à POST /auth/logout ; avertissement avant expiration.
- **Tests associés :** module 14 (7 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-14.a | feat(authz): ajoute AutoLogoutService (détection d'inactivité) | Development | frontend/src/app/core/auth/ |
| FT-14.b | feat(authz): appelle POST /v1/auth/logout à l'expiration | Development | frontend/src/app/core/auth/ |
| FT-14.c | feat(authz): avertissement avant déconnexion | Development | frontend/src/app/layout/ |
| FT-14.d | test(authz): tests avec timers simulés | Testing | frontend/src/app/core/auth/ |
| FT-14.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-14.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-15 - Matrice de tests E2E rôle × licence × workspace

- **Récit :** En tant qu'équipe, nous voulons une matrice de tests de bout en bout, afin de valider l'ensemble avant livraison.
- **Branche :** `test/authz-15-e2e-matrix` ; **Epic :** EP-7
- **Dépend de :** FT-07, FT-08, FT-09, FT-12, FT-13, FT-14 ; **Taille indicative :** L
- **Références :** Stratégie de test ; **Flag :** —
- **Critère d'acceptation (gate) :** Matrice complète verte en CI ; comptes de test générés à l'exécution, aucun secret versionné.
- **Tests associés :** scénarios F-01 à F-15

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-15.a | test(authz): fixtures conftest.py (comptes générés à l'exécution) | Testing | backend/tests/conftest.py |
| FT-15.b | test(authz): matrice rôle × licence × workspace | Testing | backend/tests/ |
| FT-15.c | test(authz): scénarios activation, désactivation, révocation | Testing | backend/tests/ |
| FT-15.d | test(authz): scénarios SSO | Testing | backend/tests/ |
| FT-15.e | test(authz): scénarios frontend (guards, menu) | Testing | frontend/ |
| FT-15.f | ci(authz): publie le rapport de la matrice | DevOps | azure-pipelines.yml |
| FT-15.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-15.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-16 - Documentation et décisions d'architecture

- **Récit :** En tant qu'équipe, nous voulons une documentation et des ADR à jour, afin de transmettre et maintenir la solution.
- **Branche :** `docs/authz-16-docs-adr` ; **Epic :** EP-8
- **Dépend de :** FT-15 ; **Taille indicative :** S
- **Références :** ARCH-013, docs gaps ; **Flag :** —
- **Critère d'acceptation (gate) :** Relecture validée ; fiches d'audit concernées mises à jour.
- **Tests associés :** module 16 (3 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-16.a | docs(authz): ADR du modèle de droits (rôle, workspace, licence) | Documentation | docs/adr/ |
| FT-16.b | docs(authz): README du parcours d'activation | Documentation | README.md |
| FT-16.c | docs(authz): diagramme de séquence dans diagrams/authentication/ | Documentation | architecture-audit/diagrams/authentication/ |
| FT-16.d | docs(authz): runbook de déploiement et de retour arrière | Documentation | docs/runbooks/ |
| FT-16.e | docs(authz): met à jour les fiches d'audit traitées | Documentation | architecture-audit/findings/ |
| FT-16.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-16.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

#### FT-17 - Suppression de is_active (migration 0027)

- **Récit :** En tant qu'équipe, nous voulons retirer l'ancien champ is_active, afin de supprimer la dette de compatibilité.
- **Branche :** `chore/authz-17-drop-is-active` ; **Epic :** EP-8
- **Dépend de :** FT-16 ; **Taille indicative :** S
- **Références :** — ; **Flag :** —
- **Critère d'acceptation (gate) :** À livrer dans une release suivante, après une période sans incident ; downgrade testé.
- **Tests associés :** module 17 (3 cas)

| ID | Tâche (message de commit) | Activité | Fichiers probables |
|---|---|---|---|
| FT-17.a | feat(authz): migration 0027 supprimant users.is_active | Development | backend/alembic/versions/0027_*.py |
| FT-17.b | refactor(authz): retire la propriété et les usages de is_active | Development | backend/app/ |
| FT-17.c | test(authz): adapte les tests | Testing | backend/tests/ |
| FT-17.R | Relecture de la PR (checklist du modèle, CI verte, revue sécurité si applicable) | Review | - |
| FT-17.G | Revue de gate (go / no-go avec le dashboard) | Review | - |

### 9.6 Scénarios fonctionnels (validation de haut niveau)

| ID | Parcours | Gate | Tests composants |
|---|---|---|---|
| F-01 | Invitation puis activation par mot de passe | authz-15 | T-07-001, T-05-002, T-04-005, T-01-002, T-06-009, T-06-003 |
| F-02 | Invitation puis activation par SSO | authz-15 | T-08-001, T-08-008, T-06-009 |
| F-03 | Invitation expirée puis renvoi | authz-15 | T-04-007, T-07-005, T-04-005, T-04-013 |
| F-04 | Retrait de licence en cours de session | authz-15 | T-07-010, T-06-006, T-06-007, T-11-004, T-12-007 |
| F-05 | Désactivation en cours de session | authz-15 | T-07-007, T-01-004, T-04-003, T-04-004 |
| F-06 | Isolation entre workspaces | authz-15 | T-09-002, T-09-003, T-09-004, T-09-005, T-09-009 |
| F-07 | Tentatives d'escalade | authz-15 | T-07-002, T-09-006, T-03-002 |
| F-08 | Panne SMTP à l'invitation | authz-15 | T-05-003, T-05-005, T-07-005 |
| F-09 | Migration sur données hétérogènes et retour arrière | authz-02 | T-02-001, T-02-002, T-02-003, T-02-004, T-02-005 |
| F-10 | Bascule du flag de licences | authz-15 | T-06-001, T-06-002, T-12-001 |
| F-11 | Rejeu et concurrence du jeton | authz-15 | T-04-009, T-04-006 |
| F-12 | Parcours frontend dynamique | authz-15 | T-11-001, T-12-002, T-12-003, T-12-006, T-12-007 |
| F-13 | Inactivité puis reconnexion | authz-15 | T-14-001, T-14-004, T-11-007 |
| F-14 | Réactivation d'un compte désactivé | authz-15 | T-07-013, T-01-004 |
| F-15 | Non-régression des parcours existants | authz-15 | T-06-001, T-01-002, T-09-001, T-08-007 |

### 9.7 EP-7 - Tâches de l'agent de test

L'agent exécute `plan-testing.md` : il écrit les tests, le dashboard et le rapport final, sans modifier le code applicatif.

| ID | Tâche | Livrable |
|---|---|---|
| AG-01 | Inventaire du code réel : chemins, variables, conftest, routeurs, services Angular | docs/testing/inventory.md |
| AG-02 | Socle de test : marqueurs, hook de diagnostic, factories, fixtures | backend/tests/authz/conftest.py |
| AG-03 | Génération de catalog.json depuis le catalogue | tools/test-dashboard/catalog.json |
| AG-04 | Tests des modules 00 à 04 | tests m00 à m04 |
| AG-05 | Tests des modules 05 à 10 | tests m05 à m10 |
| AG-06 | Tests frontend des modules 11 à 14 | *.spec.ts |
| AG-07 | Scénarios fonctionnels F-01 à F-15 | scenarios/ |
| AG-08 | Tests des modules 16 et 17 | tests m16, m17 |
| AG-09 | Dashboard : générateur, règles de diagnostic, jeu d'exemple, tests du générateur | tools/test-dashboard/ |
| AG-10 | Intégration pipeline : publication JUnit, bundles et job authz_test_report | azure-pipelines.yml |
| AG-11 | Test de sensibilité par injection de défauts sur une branche jetable | docs/testing/sensitivity.md |
| AG-12 | Rapport final de test | docs/testing/report-final.md |

## 10. Séquencement proposé en sprints

Capacité de l'équipe inconnue : les regroupements suivent les dépendances, pas des durées. À recaler en planification (CR-05).

| Sprint | Contenu | Résultat attendu |
|---|---|---|
| Sprint 0 - Cadrage et socle | CN-01 à CN-10 (décisions), GV-01 à GV-06, FT-00 (CI), AG-01, AG-02 | Cérémonies CR-01 à CR-03 ; CI PostgreSQL opérationnelle ; décisions bloquantes prises |
| Sprint 1 - Base de données et sessions | FT-01, FT-02, FT-03, AG-03, AG-04 (modules 00 à 03) | Migration 0026 validée en CI ; permissions testées |
| Sprint 2 - Compte, e-mail, SSO, isolation | FT-04, FT-05, FT-08, FT-09, AG-04 (module 04), AG-05 (modules 05, 08, 09) | Activation par jeton et SSO ; isolation prouvée ; gates 04, 05, 08, 09 |
| Sprint 3 - Licences et administration | FT-06, FT-07, FT-10, AG-05 (modules 06, 07, 10) | Flag licences prêt ; API admin complète ; contrat figé |
| Sprint 4 - Frontend | FT-11, FT-12, FT-13, FT-14, AG-06 | Menu et routes dynamiques ; écrans d'administration ; autologout |
| Sprint 5 - Validation et documentation | FT-15, FT-16, AG-07 à AG-12, CR-11, CR-12 | Matrice E2E verte ; dashboard publié ; PR integration vers dev |
| Release suivante | FT-17 | Suppression de is_active après période sans incident |

Chemin critique : FT-00 (CI) > FT-01 > FT-02 > FT-04 > FT-06 > FT-07 > FT-10 > FT-11 > FT-12 > FT-15 > livraison. FT-03, FT-05, FT-08, FT-09 et FT-13/14 sont parallélisables une fois leurs dépendances fusionnées.

## 11. Processus de revue

- **Pull request :** brouillon dès le premier push ; passage en « Prête » après checklist (tests, migration, sécurité, retour arrière) et CI verte ; un relecteur (deux pour `main`) ; squash vers `integration/authz-licences` ; merge commit vers `dev`.
- **Politiques de branches :** CI obligatoire (unitaires, intégration PostgreSQL, migrations, nommage), commentaires résolus, work item lié.
- **Revues spécifiques :** sécurité (CN-08, CR-03) avant FT-04 et FT-06 ; revue de contrat d'API (CN-09) avant FT-10 ; revue de gate (CR-08) à chaque fin de Feature ; revue de pré-livraison (CR-11).
- **Rebase :** rebase sur la branche d'intégration, jamais de merge de `dev` dans une sous-branche.

## 12. Definition of Ready et Definition of Done

**Prête (une Feature) :** décisions bloquantes prises ; dépendances fusionnées ; critères d'acceptation et gate écrits ; module de test identifié ; chemins de fichiers confirmés par l'inventaire (AG-01).

**Terminée (une Feature) :** sous-fonctions committées ; tests du module écrits et actifs (plus de `xfail`) et verts en CI ; aucun test ignoré ; migration réversible et testée (si applicable) ; flag à `false` par défaut ; checklist de PR complétée ; relecture faite ; gate « go » dans le dashboard ; documentation mise à jour.

**Terminé (le chantier) :** FT-00 à FT-16 fusionnées ; scénarios F-01 à F-15 verts ; dashboard publié par la CI ; test de sensibilité réalisé (AG-11) ; plan de déploiement et de retour arrière validé ; rapport final distinguant ce qui a été exécuté de ce qui ne l'a pas été.

## 13. Risques

| Réf. | Risque | Probabilité | Impact | Réponse proposée |
|---|---|---|---|---|
| R-01 | La migration `0025` n'a jamais été exécutée et peut contenir des défauts qui bloquent tout | Moyenne | Élevé | FT-01 en premier, base jetable en CI |
| R-02 | Aucune machine locale : cycles de validation lents par la CI | Élevée | Moyen | PR petites, tests ciblés, options devcontainer ou serveur de dev (Q-G) |
| R-03 | Tests écrits sans exécution : erreurs de fixtures | Élevée | Moyen | Premier cycle de CI dédié à stabiliser (classes TEST et DONNEES) |
| R-04 | Reconnexion générale au déploiement (tokens sans `sid` refusés) | Certaine | Moyen | Communication CR-12, fenêtre de déploiement |
| R-05 | Dérive entre DDL de démarrage et Alembic | Moyenne | Élevé | Une seule migration en vol, contrôle de tête unique |
| R-06 | Décisions ouvertes (Q-001, Q-A, Q-C, Q-D) retardent FT-08, FT-07, FT-09 | Moyenne | Moyen | Traiter en Sprint 0 |
| R-07 | Fuite entre workspaces côté Neo4j | Faible à moyenne | Élevé | FT-09 et F-06 prioritaires |
| R-08 | Absence de sauvegarde Neo4j avant déploiement | Moyenne | Élevé | Q-H, action DevOps |
| R-09 | Hypothèses de chemins et de variables erronées | Élevée | Faible à moyen | AG-01 avant toute écriture de test |
| R-10 | Features trop grosses (FT-04, FT-06, FT-07, FT-15) | Moyenne | Moyen | Sous-branches `authz-NN-1-...` autorisées |

## 14. Instructions de sortie pour le LLM de gestion de projet

Produire, à partir de ce document et de `backlog-seed.json` :

1. **Backlog hiérarchique** (Epic, Feature, User Story ou Tâche) avec : identifiant, type, titre, description, critères d'acceptation, parent, dépendances, activité (Design, Development, Testing, Documentation, Deployment), taille, étiquettes (`authz`, numéro de branche, niveau de test), références (ARCH, TASK, Q).
2. **Plan de sprints** à partir de la section 10, en demandant la capacité réelle de l'équipe si elle manque.
3. **Calendrier des réunions** à partir de la section 7.
4. **Registre des risques et des décisions** (sections 5, 6 et 13).
5. **Definition of Ready et Definition of Done** (section 12).
6. **Tableau de suivi** reprenant les gates, avec statut initial « non démarré ».
7. **Format d'import** adapté à l'outil cible (par défaut Azure Boards, car la CI est Azure Pipelines) : CSV ou JSON, un élément par ligne.

**Contraintes :** ne pas inventer de dates, de noms de personnes, d'estimations en jours ou de décisions non prises ; signaler explicitement toute hypothèse ; conserver les identifiants (`EP-`, `FT-`, `CN-`, `GV-`, `AG-`, `CR-`, `T-`, `F-`, `Q-`, `D-`, `R-`) pour la traçabilité.

## 15. Glossaire et références

- **Gate :** condition de validation d'une branche avant merge.
- **Flag :** interrupteur de fonctionnalité qui permet de fusionner sans activer.
- **ARCH-0xx :** fiche de constat de l'audit d'architecture.
- **TASK-xxx, Q-001 :** éléments de `solution-analysis/` (tâches et questions ouvertes d'origine).
- **FT-NN :** Feature correspondant à la branche `authz-NN` de `Plan.md`.
- **T-NN-NNN, F-NN :** cas de test et scénarios de `plan-testing.md`.

