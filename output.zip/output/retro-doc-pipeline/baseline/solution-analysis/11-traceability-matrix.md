# 11 - Traceability matrix

| Epic | US | Requirement | Existing component | Gap | Solution | Task | Test | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EP01 | US01.1.01 | R-001 | `backend/app/api/auth_router.py`, `frontend/src/app/services/auth.service.ts` | SSO missing | `SOL-001` | `TASK-001` | `TEST-001` | redirect and safe rejection |
| EP01 | US01.1.02 | R-002 | `backend/app/core/config.py`, `backend/app/core/security.py` | session invalidation missing | `SOL-001` | `TASK-001` | `TEST-002` | expiry and logout |
| EP01 | US01.1.03 | R-003 | role and user model | revocation tracking missing | `SOL-001` | `TASK-002` | `TEST-003` | immediate block and audit |
| EP01 | US01.1.04 | R-004 | `app/models/orm/user.py` | technical account model missing | `SOL-001` | `TASK-002` | `TEST-004` | restricted account model |
| EP02 | US01.2.01 | R-005 | `workspace_router.py`, `workspace_repo.py` | lifecycle / metadata model partial | `SOL-002` | `TASK-003` | `TEST-005` | workspace create/admin |
| EP02 | US01.2.02 | R-006 | `user_workspace_association`, `authorization.py` | membership history missing | `SOL-002` | `TASK-003` | `TEST-006` | access attach/remove |
| EP02 | US01.2.03 | R-007 | route guards and workspace navigation | context selector missing | `SOL-002` | `TASK-004` | `TEST-007` | active context selector |
| EP02 | US01.2.04 | R-008 | `authorization.py` | cross-workspace regression tests missing | `SOL-002` | `TASK-005` | `TEST-008` | logical isolation |
| EP02 | US01.2.05 | R-009 | admin user UI and workspace membership API | visual reassignment and named user groups missing | `SOL-002` | `TASK-006` | `TEST-009` | authorized drag-and-drop persists audited membership changes; groups grant no access |

## Notes

- `NONE (reason)` is not used because all user stories have an identified gap or partially covered implementation.
- The solutions remain `PROPOSED` because they are design-level decisions pending validation against the actual codebase and enterprise constraints.
