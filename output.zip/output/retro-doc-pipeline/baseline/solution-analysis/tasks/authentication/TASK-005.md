## TASK-005

### Objective

Create cross-workspace security validation and audit visibility.

### Source

- `EP02`
- `US01.2.04`
- `SOL-002`

### Files / Modules

- `backend/app/core/authorization.py`
- `backend/app/api/workspace_router.py`
- `backend/app/repositories/graph_repo.py`

### Implementation

- add regression tests for cross-workspace access denial
- add audit event output for workspace membership and data access attempts
- verify that the current access checks reject access without revealing resource existence

### Dependencies

- `TASK-003`
- `TASK-004`

### Tests

- `TEST-008`: cross-workspace isolation and denial behavior

### Acceptance Criteria

- a user from workspace A cannot access workspace B resources
- denial messages do not disclose existence of hidden resources
- audits capture the denied access event

### Definition of Done

- validation suite passes
- documentation explains the security boundary
- audit logs are usable for investigation

### Estimated Effort

S
