## TASK-001

### Objective

Implement the enterprise identity foundation and secure session handling.

### Source

- `EP01`
- `US01.1.01`
- `US01.1.02`
- `SOL-001`

### Files / Modules

- `backend/app/core/config.py`
- `backend/app/core/security.py`
- `backend/app/api/auth_router.py`
- `frontend/src/app/services/auth.service.ts`
- `frontend/src/app/app.routes.ts`

### Implementation

- add OIDC-compatible identity adapter abstraction
- move session lifecycle management to a session registry
- validate token claims centrally
- update the frontend login flow to work with the provider-backed identity model

### Dependencies

None

### Tests

- `TEST-001`: enterprise login redirect and rejection
- `TEST-002`: expiry and logout behavior

### Acceptance Criteria

- enterprise SSO redirect works for valid accounts
- unknown/disabled accounts are rejected without sensitive leakage
- tokens expire and logout invalidates the session server-side

### Definition of Done

- auth flow documented and covered by tests
- no secrets stored in source control
- rollback path documented for provider outage

### Estimated Effort

M
