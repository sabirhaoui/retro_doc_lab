## TASK-004

### Objective

Add active context selection and scope propagation in the UI and API.

### Source

- `EP02`
- `US01.2.03`
- `SOL-002`

### Files / Modules

- `frontend/src/app/app.routes.ts`
- `frontend/src/app/guards/auth.guard.ts`
- `frontend/src/app/services/auth.service.ts`
- `backend/app/api/workspace_router.py`

### Implementation

- add a persisted active workspace/project/environment state in the frontend
- ensure all requests include or rehydrate the selected context
- centralize query scoping in the backend for workspace access

### Dependencies

- `TASK-003`

### Tests

- `TEST-007`: context selection and restoration

### Acceptance Criteria

- selected context is visible in the app shell
- switching context refreshes the graph and workspace views
- the last context is restored after re-login

### Definition of Done

- active context is persisted and enforced
- scope propagation is validated in the UI and API

### Estimated Effort

M
