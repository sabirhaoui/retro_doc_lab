## TASK-002

### Objective

Implement access revocation, technical account governance, and auth audit events.

### Source

- `EP01`
- `US01.1.03`
- `US01.1.04`
- `SOL-001`

### Files / Modules

- `backend/app/models/orm/user.py`
- `backend/app/repositories/user_repo.py`
- `backend/app/api/admin_router.py`
- `backend/app/core/security.py`

### Implementation

- add session revocation model and admin APIs
- add technical account type and scope model
- add audit events for revocation and credential rotation

### Dependencies

- `TASK-001`

### Tests

- `TEST-003`: immediate revocation blocks active sessions
- `TEST-004`: restricted technical account behavior

### Acceptance Criteria

- revoked users cannot continue using their active token
- technical accounts cannot perform interactive sessions
- all relevant actions emit audit evidence

### Definition of Done

- admin revocation API implemented
- technical account restrictions enforced
- logs produced in a format suitable for audit review

### Estimated Effort

M
