## TASK-003

### Objective

Implement the administrator workspace governance model and membership enforcement.

### Source

- `EP02`
- `US01.2.01`
- `US01.2.02`
- `SOL-002`

### Files / Modules

- `backend/app/models/orm/workspace.py`
- `backend/app/repositories/workspace_repo.py`
- `backend/app/core/authorization.py`
- `backend/app/api/workspace_router.py`

### Implementation

- add workspace lifecycle state and governance metadata
- add membership history and revocation semantics
- enforce access checks at the route layer consistently

### Dependencies

- `TASK-001`

### Tests

- `TEST-005`: workspace creation and admin listing
- `TEST-006`: membership attach/remove and cross-role access

### Acceptance Criteria

- workspace creation and access assignment work reliably
- removed users lose access on next protected request
- workspace lifecycle is explicit and non-destructive by default

### Definition of Done

- workspace policy is centralized and audited
- access checks are enforced on all relevant routes
- admin operations are covered by tests

### Estimated Effort

M
