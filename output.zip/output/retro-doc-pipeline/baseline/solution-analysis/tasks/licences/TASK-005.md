TASK-005.md : Harnais de Seeding des Comptes Techniques & Isolation

    Périmètre : scripts/seed_technical_accounts.sql, tests/conftest.py

    Actions :

        Créer le script SQL d'injection des comptes de test (Tech Admin, Tech Studio, Tech Analytics, Tech Restricted).

        Rédiger la fixture Pytest pour le chargement dynamique sur instance vierge.

    Critères d'acceptation :

        L'exécution de la suite de tests E2E s'exécute sur une BDD propre et injectée en < 5s.