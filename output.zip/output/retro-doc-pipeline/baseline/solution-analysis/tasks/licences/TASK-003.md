TASK-003.md : Refactoring & Résilience du Service Mail

    Périmètre : app/modules/email/service.py

    Actions :

        Entourer les appels provider.send() d'un bloc try/except.

        Ajouter le logging explicite en INFO du lien d'activation (setup_link) pour faciliter le débogage en local/dev sans serveur SMTP.

    Critères d'acceptation :

        La création d'un utilisateur renvoie 201 Created même si le SMTP remonte une erreur réseau.