TASK-004.md : Route Guard Angular & Feature Gating UI

    Périmètre : src/app/core/guards/license.guard.ts, src/app/app.routes.ts

    Actions :

        Implémenter le Functional Guard licenseGuard('studio_v2').

        Appliquer le Guard sur les sous-modules de l'application Angular.

        Masquer visuellement les éléments de navigation non autorisés dans le menu.

    Critères d'acceptation :

        Tentative de navigation directe via l'URL sur un module non souscrit redirige vers /unauthorized.