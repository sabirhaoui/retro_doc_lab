TASK-002.md : Dépendance FastAPI de Feature Gating par Licence

    Périmètre : app/modules/identity/dependencies.py, app/modules/studio_v2/router.py

    Actions :

        Implémenter require_license(required_license: str).

        Injecter la dépendance sur l'ensemble des routes protégées par souscription (Studio V2, Analytics, Admin).

    Critères d'acceptation :

        Un utilisateur sans la licence requise reçoit une réponse 403 Forbidden structurée JSON.