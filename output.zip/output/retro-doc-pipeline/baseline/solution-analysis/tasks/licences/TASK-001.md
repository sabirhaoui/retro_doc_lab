TASK-001.md : Migration de Base de Données & Refactoring user_repo

    Périmètre : app/models/orm/user.py, app/repositories/user_repo.py, alembic/versions/

    Actions :

        Générer le fichier de migration Alembic pour ajouter licenses (JSONB) et permissions (JSONB).

        Mettre à jour le modèle SQLAlchemy User.

        Adapter create_user et update_user dans user_repo.py pour manipuler ces attributs.

    Critères d'acceptation :

        Les requêtes d'insertion et de mise à jour fonctionnent sans repasser par le DTO legacy.

        Test unitaire vert.