# TASK-006 : Gestion graphique des affectations et groupes d'utilisateurs

## Objectif

Permettre à un administrateur autorisé de déplacer visuellement des utilisateurs d'un projet (workspace) à un autre et de les organiser dans des groupes nommés, au moyen d'une interface glisser-déposer.

Les groupes sont des outils d'organisation uniquement : leur appartenance ne confère et ne modifie aucun rôle, permission, licence ou droit d'accès. L'accès au projet cible doit résulter d'une adhésion explicite validée côté backend.

## Périmètre

- Interface d'administration des utilisateurs, en cohérence avec `frontend/src/app/pages/admin/users/admin-users.component.ts`.
- API et persistance des adhésions aux projets/workspaces et des groupes d'utilisateurs associés à un projet.
- Contrôles d'accès, audit et tests des changements d'affectation.

## Actions

1. Définir le modèle des groupes nommés, leur portée (projet/workspace), les règles d'unicité du nom dans cette portée et les opérations de création, renommage et suppression.
2. Ajouter une interaction glisser-déposer pour déplacer un utilisateur entre les listes de projets et l'affecter ou le retirer d'un groupe.
3. Implémenter l'API de mutation des adhésions et appartenances de groupe. Chaque requête doit vérifier côté serveur que l'acteur peut administrer le projet source et le projet cible ; ne jamais se fier aux contrôles de l'interface.
4. Appliquer le retrait du projet source et l'ajout au projet cible comme une opération cohérente et atomique. Refuser proprement les projets inexistants, les adhésions déjà modifiées et les demandes non autorisées, sans laisser d'affectation partielle.
5. Émettre un événement d'audit pour chaque ajout/retrait d'adhésion et changement de groupe, avec l'acteur, l'utilisateur concerné, les projets, le groupe et la date.
6. Actualiser l'interface après succès ; en cas d'échec, conserver un état cohérent, informer l'administrateur et permettre une nouvelle tentative.

## Critères d'acceptation

- Un administrateur autorisé peut déplacer un utilisateur d'un projet source vers un projet cible par glisser-déposer ; l'adhésion est persistée et l'utilisateur obtient uniquement les droits explicitement associés à sa nouvelle adhésion.
- Après déplacement, l'accès au projet source est révoqué sauf si l'utilisateur dispose d'une autre adhésion ou d'un autre droit valide ; il conserve ses accès indépendants.
- Un administrateur peut créer, renommer et supprimer un groupe nommé dans un projet, puis y ajouter ou retirer un utilisateur ; les changements persistent après rechargement.
- Les noms de groupes sont uniques au sein d'un même projet selon la règle de casse documentée ; un nom identique reste permis dans deux projets distincts.
- Un utilisateur sans droit d'administration sur le projet source ou cible reçoit une réponse 403 (ou 404 conformément à la politique anti-énumération), et aucune mutation n'est persistée.
- Les rôles, permissions et licences de l'utilisateur ne changent pas lorsqu'il est déplacé ou regroupé.
- Une erreur lors de l'opération ne laisse ni adhésion ni appartenance de groupe partiellement mise à jour ; l'interface affiche le résultat réel renvoyé par l'API.
- Les actions réussies sont auditables ; les tests unitaires, d'intégration et E2E couvrent les mutations autorisées, refusées et les cas d'échec.

## Dépendances

- `../authentication/TASK-003.md` : gouvernance workspace et enforcement des adhésions.
- `../authentication/TASK-004.md` : contexte actif projet/workspace dans l'interface.
- `../authentication/TASK-005.md` : audit et validation de sécurité inter-workspaces.
- `TASK-004.md` (licences) : guard Angular et feature gating de l'administration.
- `TASK-005.md` (licences) : comptes de test et harnais E2E multi-projets.

## Tests attendus

- UT : validation des groupes, de leur portée et de l'absence d'effet sur les rôles/licences.
- INT : mutations atomiques d'adhésions/groupes, permissions insuffisantes et conflits d'état.
- SEC/E2E : déplacement entre deux projets par drag-and-drop, tentative inter-projets non autorisée et vérification après rechargement.
