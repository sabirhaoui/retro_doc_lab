# 09 - Target architecture

## 1. Recommended direction from the audit

The repo audit explicitly recommends keeping the modular monolith and reinforcing contracts and operations before extracting services. The target architecture is therefore not a rewrite: it is a hardened and clearer version of the current system.

## 2. Architecture principles

- keep Angular + FastAPI monolith
- preserve PostgreSQL as the source of truth for identity, ACLs, job state, and catalogs
- preserve Neo4j for graph data and canonical graph states
- keep Redis/Celery for durable async work, but require real extraction and status correctness
- centralize secret resolution and outbound egress control
- enforce immediate security checks on access tokens and connector routes

## 3. Target state

$$
\text{Browser} \rightarrow \text{Angular UI} \rightarrow \text{FastAPI API} \rightarrow \{\text{Postgres}, \text{Neo4j}, \text{Redis/Celery}\}
$$

with the following operational hardening layers:

$$
\text{Secret resolver} \rightarrow \text{Outbound allowlist} \rightarrow \text{Token validation} \rightarrow \text{Job status control} \rightarrow \text{Observability}
$$

## 4. Proposed changes

### Existing components kept

- Angular UI shell and admin/review surfaces
- FastAPI route and service structure
- PostgreSQL + Neo4j hybrid storage model
- Redis/Celery job layer

### Proposed additions

- secret resolver / credential adapter
- connector egress allowlist and validation layer
- access-token `is_active` check in the auth dependency
- durable async job lifecycle with truthful status transitions
- stronger API contract validation and proxy configuration tests

## 5. Migration plan

The audit recommends a staged sequence:

1. fix proxy and frontend configuration defaults
2. resolve credentials/SSRF/auth issues without changing the overall paradigm
3. replace placeholder ingest jobs with durable tasks
4. remove startup DDL after Alembic transition is verified
5. add readiness, backups, and reliability checks before scaling out

## 6. Risks

- If secrets remain in URLs, the system remains vulnerable even without a full refactor.
- If outbound connector destinations are not allowlisted, the backend becomes a network pivot point.
- If job states remain misleading, the business will trust a false-success workflow.

## 7. Conclusion

The right target architecture is a hardened monolith with explicit contracts, config validation, secret handling, secure connector egress, and truthful async job behavior. This is exactly the direction described by the repository audit and the domain architecture docs.
