# 03 - Current architecture

## 1. Facts from the repo audit and code

### Architecture summary

The repo audit is explicit: the system is a modular Angular 22 + FastAPI/Python monolith backed by PostgreSQL, Neo4j, Redis/Celery, Nginx and Azure Pipelines. The current architecture is designed as a single application with clear module boundaries, not as a distributed microservice platform.

This is confirmed by:

- `input/Audit/architecture-audit/00-executive-summary.md`
- `input/Audit/architecture-audit/03-current-architecture.md`
- `input/Audit/architecture-audit/FINAL-REPORT.md`
- `README.md`

### Backend

The backend remains a layered monolith with route, service, and repository boundaries. The actual code in the repo confirms route-level logic in `backend/app/api/*`, database/auth logic in `backend/app/core/*`, and graph persistence in `backend/app/repositories/graph_repo.py`.

### Data stores

- PostgreSQL: user accounts, ACLs, workflow state, job state metadata
- Neo4j: graph domain model and canonical graph data
- Redis/Celery: async task broker and result handling
- Nginx: frontend and proxy entrypoint in deployment

### Frontend

The frontend is Angular-based and uses separate pages and route guards, with the UI being a testable studio shell and admin/review surfaces. The audit describes a Studio v2 model with lazy-loaded, route-specific functionality and a central API contract.

## 2. Architecture flow

$$
\text{Browser} \rightarrow \text{Angular UI} \rightarrow \text{FastAPI API} \rightarrow \{\text{Postgres}, \text{Neo4j}, \text{Redis/Celery}\}
$$

## 3. Key observations from audit

- The architecture is coherent and modular, but not yet fully hardened.
- The P1 risks are operational/security issues rather than a structural rewrite problem.
- The repo audit explicitly advises to keep the monolith modular and improve contracts before extracting services.
- Several findings are directly associated with real application paths and not with hypothetical future architecture.

## 4. Conclusion

The current architecture is a valid starting point and matches the repo audit’s target direction: keep the modular monolith, fix the P1 findings, strengthen contracts and process boundaries, and then only consider extraction if it is actually justified by operational metrics.
