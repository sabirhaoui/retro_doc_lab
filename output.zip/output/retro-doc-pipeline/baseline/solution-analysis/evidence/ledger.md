# Evidence ledger

| ID | Chemin / commande | Observation | Utilisé par |
| --- | --- | --- | --- |
| E-001 | `README.md:1-44` | The project is described as a PMIS Twin Knowledge Studio with Angular, FastAPI, Postgres, and Neo4j. | 00, 01, 02, 03 |
| E-002 | `backend/app/main.py:1-31` | The API registers admin, auth, and workspace routes and exposes `/health`. | 00, 01, 03 |
| E-003 | `backend/app/core/config.py:1-20` | JWT and database settings are centralized in `Settings`, including `SECRET_KEY`, Postgres URI, and Neo4j URI. | 00, 03, 07 |
| E-004 | `backend/app/core/security.py:1-31` | Password verification and JWT creation are implemented for access and refresh tokens. | 03, 05, 07 |
| E-005 | `backend/app/api/auth_router.py:1-79` | Login and refresh endpoints exist; local username/password auth is implemented. | 03, 05, 07 |
| E-006 | `backend/app/core/authorization.py:1-38` | Workspace access is enforced via `assert_workspace_access` and `accessible_workspace_ids`. | 03, 06, 07 |
| E-007 | `backend/app/repositories/workspace_repo.py:1-80` | Workspace membership and workspace CRUD are defined. | 03, 06, 07 |
| E-008 | `backend/app/api/workspace_router.py:1-80` | Workspace create/list/get/update/delete and graph/category operations are implemented. | 01, 03, 06 |
| E-009 | `frontend/src/app/services/auth.service.ts:1-54` | Browser token management and login/refresh flow are implemented on the client. | 01, 03, 05 |
| E-010 | `frontend/src/app/app.routes.ts:1-31` | Routing includes login, setup-account, workspace, and admin pages with guards. | 01, 03 |
| E-011 | `input/Enabler/Epic.md:1-15` | Epic EP01 defines enterprise identity and session requirements. | 00, 02, 04 |
| E-012 | `input/Enabler/Epic2.md:1-15` | Epic EP02 defines workspace administration and logical isolation. | 00, 02, 04 |
| E-013 | `input/Enabler/UserStory/EpicUS.md:1-75` | EP01’s detailed user stories cover SSO, sessions, revocation, and technical accounts. | 00, 02, 04, 05 |
| E-014 | `input/Enabler/UserStory/Epic2US.md:1-74` | EP02’s detailed user stories cover workspace creation, membership, context, and isolation. | 00, 02, 04, 05 |
| E-015 | `git -C /workspace/twins_project ...` | Repository status check failed because this directory is not a git checkout. | 00, STATE |
