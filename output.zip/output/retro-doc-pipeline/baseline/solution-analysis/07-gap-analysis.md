# 07 - Gap analysis

## GAP-001 — Credentials are exposed in query strings

### Requirement

- Security requirement from the repo audit, high-priority issue `ARCH-004`

### Current state (FACT + E-###)

The repo audit states that credentials and session tokens are added to `HttpParams` in the frontend and read directly as query parameters by the backend connector routes. See `input/Audit/architecture-audit/findings/ARCH-004-credentials-in-query.md`.

### Missing capability

Secret-bearing credentials must not be sent in URL query strings.

### Technical impact

- credentials can leak through reverse proxies and access logs
- account-level secrets may be copied into monitoring systems
- ERP service access becomes more fragile and less auditable

### Root cause

The connector API accepts credentials in URL query parameters instead of a server-side secure transport or opaque reference model.

### Recommended resolution

- replace query credentials with POST bodies or server-side secret resolution
- purge historical logs and rotate exposed credentials
- enforce sensitive-field redaction in proxies/APM

## GAP-002 — Connector routes allow caller-controlled outbound destinations (SSRF risk)

### Requirement

- Security requirement from repo audit, high-priority issue `ARCH-005`

### Current state (FACT + E-###)

The audit documents that connector routes accept `base_url` from the caller and that the HTTP clients call those destinations with no effective allowlist or network validation. See `ARCH-005-ssrf-connectors.md`.

### Missing capability

Restrictive outbound destination validation and egress control for connector traffic.

### Technical impact

- backend may be abused as a proxy to internal network services
- private services and metadata endpoints may be reachable from the app layer
- TLS bypass options increase risk further when `insecure` is enabled

### Root cause

The connector layer accepts attacker-controlled destination URLs and does not validate them against an enforceable allowlist.

### Recommended resolution

- allowlist internal connector hosts
- block loopback, link-local, private, and metadata destinations
- disable insecure TLS configuration outside controlled environments
- restrict test routes to administrators

## GAP-003 — Disabled users can still present valid access tokens

### Requirement

- Security requirement from repo audit, priority `ARCH-006`

### Current state (FACT + E-###)

The audit states that login and refresh validate `is_active`, but the dependency that loads the current user does not. See `ARCH-006-disabled-user-token.md`.

### Missing capability

Immediate denial of access for disabled users at every protected request.

### Technical impact

- residual access window after account deactivation
- unauthorized action with a non-expired access token

### Root cause

The auth dependency verifies JWT structure and loads the user, but omits the `is_active` check.

### Recommended resolution

- add `is_active` enforcement in the request dependency
- add regression tests for disabled-user access denial
- add a policy for immediate revocation if required

## GAP-004 — Ingestion jobs falsely report success with no data extracted

### Requirement

- Operational risk from repo audit, priority `ARCH-008`

### Current state (FACT + E-###)

The audit identifies a placeholder job that sleeps, sets `records=0`, and marks SUCCESS while no real extraction occurs. See `ARCH-008-ingestion-placeholder.md`.

### Missing capability

A durable, truthful ingest workflow with explicit status transitions and real extraction validation.

### Technical impact

- users see fake completion states
- monitoring can treat empty snapshots as valid data
- cancellations can be overwritten by a later success state

### Root cause

The job pipeline exposes a placeholder implementation instead of a real registry-backed extractor and atomic status transitions.

### Recommended resolution

- return `unsupported` or `failed` instead of `success` while the connector is not implemented
- replace placeholder with durable task model and real extraction checks
- enforce atomic job transitions and cancellation status

## GAP-005 — The architecture is correct but not fully hardened against the repo’s current high-risk findings

### Requirement

- Repo audit priorities and target architecture

### Current state (FACT + E-###)

The audit package names the main risks as proxy/import misconfiguration, credentials in URLs, SSRF on connector routes, and placeholder ingestion; these are the immediate priorities before any larger architecture change. See `00-executive-summary.md`, `FINAL-REPORT.md`, and `findings/INDEX.md`.

### Missing capability

Production-safe defaults for connectivity, credentials, and job state.

### Technical impact

- security incidents and operational drift
- reduced trust in integrations and monitoring data
- slow or fragile scaling in production environments

### Root cause

The monolith is structurally sound, but the implementation has not yet closed the security and operational loops required for regulated production usage.

### Recommended resolution

- fix the P1 list before extraction or large architectural changes
- keep the modular monolith and improve contracts, secrets handling, and durable job transitions
- use the audit target architecture as the migration direction
