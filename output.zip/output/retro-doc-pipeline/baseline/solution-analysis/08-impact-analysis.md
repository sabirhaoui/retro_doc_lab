# 08 - Impact analysis

## Change | Components | Risk | Dependencies | Tests

| Change | Components | Risk | Dependencies | Tests |
| --- | --- | --- | --- | --- |
| Add enterprise identity integration | `backend/app/api/auth_router.py`, `frontend/src/app/services/auth.service.ts`, `frontend/src/app/app.routes.ts` | Medium | IdP client configuration, token mapping | API auth tests, frontend login tests |
| Add session registry and revocation | `backend/app/core/security.py`, `backend/app/core/config.py`, `backend/app/dependencies/auth.py` | High | DB schema, auth middleware | unit + integration tests for logout/revocation |
| Harden workspace authorization | `backend/app/core/authorization.py`, `workspace_repo.py`, `workspace_router.py` | High | membership model, audit events | cross-workspace access tests |
| Model active context and lifecycle | `backend/app/models/orm/workspace.py`, graph model, frontend context selector | Medium | project/environment metadata | UI + integration tests |
| Add audit events and observability | backend logging, access logs, admin screens | Medium | identity events, workspace events | security regression tests |

## Primary regression areas

- authentication flow in the frontend and backend
- workspace access restrictions in all graph and workspace endpoints
- token expiry and refresh behavior
- any code path that touches data access without workspace validation

## Key conclusion

The impact is contained to a few security-critical boundaries rather than the whole app. This supports incremental implementation without a full platform rewrite.
