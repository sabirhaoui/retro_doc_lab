# 04 - Epics analysis

## EP01 — Accès sécurisé, identités et espaces de travail

### Objective

Establish a secure enterprise identity layer, session lifecycle management, revocation, and technical account governance.

### Actors

- end users
- administrators
- platform operators

### Observed repository alignment

- The login flow exists for local username/password and JWT creation. See `E-004`, `E-005`.
- The system can define roles, users, and workspace membership. See `E-006`, `E-007`.
- A workspace authorization model exists, but it is not yet enterprise SSO-integrated. See `E-006`, `E-008`.

### Key requirements from backlog

- enterprise SSO redirect and safe rejection for unknown/disabled accounts
- session expiry, explicit logout, and invalidation
- immediate access revocation
- restricted technical accounts

## EP02 — Administration de la plateforme

### Objective

Allow administrators to govern workspaces, users, and logical data partitioning across client/program/project/runtime contexts.

### Actors

- administrators
- RSSI / compliance
- project users

### Observed repository alignment

- Workspaces and owner membership exist at the backend model level. See `E-006`, `E-007`.
- The workspace router exposes create/list/get/update/delete operations and logical access filtering. See `E-008`.
- No clear evidence yet of workspace lifecycle states such as archive-only or per-workspace project/environment metadata management beyond the model itself.

### Key requirements from backlog

- create and administer workspaces
- attach and remove users to/from a workspace
- choose active context
- guarantee logical isolation across workspaces
- let authorized administrators visually move users between projects and organize them in named groups, without groups granting access

## Conclusion

The two epics are aligned with the existing platform architecture, but the repository currently provides only partial implementation of their must-haves. The gap analysis should therefore focus on enterprise identity, governance, and secure multi-tenant enforcement rather than on a complete rewrite.
