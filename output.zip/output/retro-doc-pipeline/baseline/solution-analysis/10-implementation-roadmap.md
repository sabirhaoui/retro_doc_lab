# 10 - Implementation roadmap

## 1. Delivery order

1. Security foundation (P0)
2. Workspace governance and access policy (P0)
3. Context selector and UI integration (P1)
4. Audit/logging and observability (P1)
5. Regression and security validation (P0/P1)

## 2. Task groups

### Phase 1 — Security foundation

- add enterprise IdP abstraction and secure token validation
- define session registry and revocation model
- add technical account scope model

### Phase 2 — Workspace governance

- extend workspace lifecycle state and membership history
- enforce access checks across all graph and workspace endpoints
- expose governance API for admin flows

### Phase 3 — Context and UX

- add active workspace/project/environment selector in UI
- scope queries and dashboard state to current context
- maintain persisted user context on re-login
- add administrator drag-and-drop for project membership changes and named user groups (TASK-006); groups do not grant access

### Phase 4 — Audit and validation

- add security audit log events
- create automated cross-workspace tests
- verify access refusal messages and security behavior

## 3. Roadmap table

| Phase | Tasks | Dependencies | Risk | Result |
| --- | --- | --- | --- | --- |
| P1 | SSO adapter + session registry | none | High | secure enterprise login |
| P2 | workspace governance and membership model | P1 | High | tenant-safe workspace management |
| P3 | context selector and scope propagation | P2 | Medium | correct active context |
| P3 | graphical membership management and named groups (`tasks/licences/TASK-006.md`) | workspace governance and active-context foundations | Medium | auditable, authorization-checked user assignment UX |
| P4 | audit, tests, and validation | P1-P3 | Medium | security regression coverage |

## 4. Critical path

The critical path is: auth foundation -> session governance -> workspace access policy -> context scoping -> validation.

## 5. Execution principle

The implementation should be incremental and backward-compatible. It should not replace the graph repository or Angular stack wholesale, but layer enterprise identity and governance on top of the existing architecture.
