# plan-testing.md - Plan de tests automatiques, diagnostic et dashboard (chantier authz-licences)

> **Destinataire : un agent d'ingénierie de test.** Ce document est une consigne exécutable. Il décrit ce qu'il faut tester, comment organiser les tests, comment diagnostiquer les échecs et comment produire le dashboard de rapport.
> Il complète `Plan.md` (branches et pull requests). Chaque module de test correspond à une branche `authz-NN`.
> **Règle d'honnêteté :** ne jamais déclarer un test « vert » sans l'avoir vu s'exécuter en CI. Tout ce qui n'a pas été exécuté est rapporté comme `non exécuté`.

## 0. Rôle, périmètre et règles

**Mission.** Produire, pour chaque fonctionnalité du chantier, des tests automatiques de validation (le comportement attendu existe), de vérification (les cas limites et refus sont corrects) et de diagnostic (en cas d'échec, le rapport indique où chercher). Produire ensuite le dashboard qui agrège les résultats.

**Tu peux** créer ou modifier : `backend/tests/authz/`, `frontend/**/*.spec.ts`, `tools/test-dashboard/`, `docs/testing/`, les jobs de test de `azure-pipelines.yml`.
**Tu ne dois pas** modifier le code applicatif (`backend/app/`, `frontend/src/` hors fichiers de test). Si un test révèle un défaut, tu le rapportes (classification `PRODUIT`) ; tu ne le corriges pas en silence.
**Environnement.** Il n'existe pas de machine de développement locale : l'exécution se fait dans la CI Azure Pipelines. Si tu ne peux pas déclencher la CI, livre les tests et marque-les `non exécuté`.
**Secrets.** Aucun mot de passe, jeton, hash ou clé réels dans le dépôt, les fixtures ou les rapports. Les comptes de test sont créés à l'exécution avec des secrets générés ; les rapports n'affichent que des valeurs expurgées.
**Hypothèses à vérifier avant d'écrire** (voir tâche AG-01) : noms des fichiers de `Plan.md`, variable de connexion (`POSTGRES_URI`), contenu de `backend/tests/integration/conftest.py`, disposition des routeurs, noms des services Angular.

## 1. Entrées à lire d'abord

1. `Plan.md` (branches, sous-fonctions, gates).
2. `architecture-audit/` : surtout `10-security.md`, `11-testing.md`, `13-devops-and-cicd.md`, `findings/ARCH-006`, `ARCH-009`, `ARCH-014`, `ARCH-015`.
3. `solution-analysis/` : `FINAL-SOLUTION.md`, `OPEN-QUESTIONS.md`, `implementation/HANDOFF.md`.
4. `auth-licences-sequence.mermaid` (comportement cible).
5. `azure-pipelines-authz-jobs.yml` (jobs CI de la branche 00).

## 2. Organisation modulaire des tests

### 2.1 Niveaux

| Code | Niveau | Outil | Dépendances |
|---|---|---|---|
| U | Unitaire pur | pytest | aucune (ni base ni réseau) |
| I | Intégration PostgreSQL / Neo4j / Celery | pytest, TestClient, SAVEPOINT | services éphémères de la CI |
| M | Migration | pytest + Alembic | base vierge dédiée |
| C | Contrat | pytest sur le schéma OpenAPI | aucune |
| J | Frontend | Jest (Angular) | API simulée |
| E | Scénario fonctionnel bout en bout (API, multi-étapes) | pytest | services éphémères |
| P | Pipeline et dépôt | scripts CI | agent CI |

### 2.2 Arborescence cible

```
backend/tests/authz/
  conftest.py                  # marqueurs, fixtures, hook de diagnostic
  diagnostics.py               # collecte et expurgation du bundle
  factories.py                 # utilisateurs, workspaces, licences, jetons
  m00_ci/        m01_sessions/    m02_schema/    m03_permissions/
  m04_lifecycle/ m05_email/       m06_licenses/  m07_admin/
  m08_sso/       m09_isolation/   m10_contract/  m16_docs/   m17_drop/
  scenarios/                   # F-01 ... F-15 (niveau E)
frontend/src/app/**/*.spec.ts  # modules 11 à 14, titres préfixés [T-NN-NNN]
tools/test-dashboard/
  build_dashboard.py           # JUnit + bundles + catalogue -> results.json + dashboard.html
  catalog.json                 # catalogue des tests (généré depuis ce document)
  diagnostic_rules.yml         # règles de diagnostic déterministes
  tests/                       # tests du générateur lui-même
docs/testing/inventory.md      # résultat de AG-01
```

### 2.3 Identification et traçabilité

- Chaque test porte un identifiant du catalogue, `T-<module>-<NNN>` (exemple `T-04-006`).
- Python : `@pytest.mark.tid("T-04-006")` et `@pytest.mark.gate("authz-04")`. L'identifiant est écrit dans le JUnit (propriété `tid`).
- Jest : le titre commence par `[T-12-003]`.
- Un test sans identifiant est refusé par la CI. Un identifiant du catalogue sans test apparaît `manquant` dans le dashboard.
- Le numéro dans le catalogue est l'ordre d'écriture de la ligne dans le module (001, 002, ...).

### 2.4 Tests écrits avant la fonctionnalité

Les tests des branches non encore fusionnées sont écrits dès maintenant et marqués :

```python
@pytest.mark.xfail(strict=True, reason="authz-06 non fusionnée")
```

Le dashboard les affiche `en attente` (ni vert ni rouge). Quand la branche est fusionnée, retirer le `xfail` fait basculer le test en validation réelle ; un `xfail` strict qui passe fait échouer la CI et signale qu'il faut l'activer.

### 2.5 Règles de qualité

- Un test = un comportement. Pas d'assertion sur des détails d'implémentation.
- Déterminisme : horloge contrôlée (pas de `sleep`), identifiants générés, ordre indépendant.
- Isolation : transaction SAVEPOINT par test ; graphe Neo4j nettoyé par préfixe de workspace de test.
- Tout refus est testé en négatif **et** la mutation évitée est vérifiée (exemple : après un 404, le graphe est inchangé).
- Pas de `skip` silencieux : un test non exécutable est `blocked` avec une raison.
- Les messages d'erreur testés sont ceux de l'API, jamais des détails de bibliothèque.

### 2.6 Données de test (fixtures)

| Fixture | Contenu |
|---|---|
| `admin` | rôle admin, status active, aucune licence |
| `member_licensed` | member active, licences `studio_v2` et `analytics` |
| `member_unlicensed` | member active, aucune licence |
| `member_expired_license` | licence `studio_v2` expirée |
| `member_revoked_license` | licence `studio_v2` révoquée |
| `invited_user` | status invited, mot de passe NULL, jeton d'activation valide |
| `invited_expired` | jeton expiré |
| `disabled_user` | status disabled, sessions révoquées |
| `workspace_a`, `workspace_b` | un workspace chacun, entités de graphe de test |
| `memberships` | viewer, editor, owner sur A ; aucun sur B |
| `flags(on/off)` | active ou désactive `AUTHZ_ENFORCE_LICENSES` |
| `clock` | horloge pilotable |
| `smtp_down`, `smtp_slow` | simulateurs d'erreur et de lenteur |

## 3. Ordre d'exécution et gates

Ordre : P, U, M, C, I, E, puis J. En cas d'échec d'un niveau amont, les niveaux suivants du même module sont exécutés quand même (pour le diagnostic) mais marqués `consécutif`.

**Règle de gate d'une branche `authz-NN` :** go si 100 % des tests actifs du module NN passent, aucun échec classé `PRODUIT` ouvert, aucun test `blocked` sans justification, et les scénarios F liés à la gate passent.

| Gate | Modules requis |
|---|---|
| authz-00 | 00 |
| authz-01 | 01 |
| authz-02 | 02 et F-09 |
| authz-03 | 03 |
| authz-04 | 04 |
| authz-05 | 05 |
| authz-06 | 06 |
| authz-07 | 07 |
| authz-08 | 08 |
| authz-09 | 09 |
| authz-10 | 10 |
| authz-11 | 11 |
| authz-12 | 12 |
| authz-13 | 13 |
| authz-14 | 14 |
| authz-15 | tous les modules et F-01 à F-15 |
| authz-16 | 16 |
| authz-17 | 17 |

## 4. Catalogue modulaire


Le catalogue compte **154 cas de test**, répartis en 17 modules, plus 15 scénarios fonctionnels (section 5). Colonnes : niveau, situation de départ et action, résultat attendu, piste de diagnostic en cas d'échec.


### Module 00 - CI et infrastructure de test

Branche : `authz-00`. Aucun écart toléré : cette base conditionne la fiabilité de tous les autres modules.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-00-001 | P | Un test d'intégration volontairement cassé est poussé | Le job backend_integration échoue | Job vert : continueOnError ou code retour de pytest masqué dans azure-pipelines.yml |
| T-00-002 | P | PostgreSQL est indisponible | Le job échoue (aucun test ignoré toléré) | Fixture de session qui saute : garde JUnit absente ou contournée |
| T-00-003 | P | Deux têtes Alembic existent | backend_migrations échoue | Migration créée sur une base divergente : voir alembic heads |
| T-00-004 | P | Base vierge | upgrade head, downgrade base, upgrade head réussissent | Migration non réversible : downgrade() manquant ou incomplet |
| T-00-005 | P | Noms de branche valides et invalides (feat/authz-06-x, Feat/authz-6-x, nom trop long) | Seuls les noms conformes passent branch_naming | Regex du job modifiée : comparer avec Plan.md section 0 |
| T-00-006 | P | Exécution Jest en CI | Un rapport de couverture est produit | Option --coverage=false encore présente |
| T-00-007 | P | Un job CI est en échec | Le stage CD ne se déclenche pas | dependsOn ou condition du stage CD |

### Module 01 - Registre de sessions (migration 0025)

Branche : `authz-01`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-01-001 | M | Base vierge | 0025 upgrade puis downgrade sans erreur | Ordre des opérations DDL, contraintes nommées |
| T-01-002 | I | Login valide | Une session est créée et le token porte un sid | Création de session absente du chemin de login |
| T-01-003 | U | Token signé sans claim sid | Le décodage est accepté par le décodeur mais la dépendance renvoie 401 | Compatibilité ascendante non refusée dans get_current_user |
| T-01-004 | I | Session révoquée, access token encore valide | 401 à la requête suivante | Vérification de session absente ou mise en cache trop longue |
| T-01-005 | I | Refresh avec session active | Nouvel access token émis, session inchangée (ou rotation documentée) | Logique de refresh : comparer avec l'ADR |
| T-01-006 | I | Refresh avec session révoquée | Refus, cookie effacé | Le refresh ne consulte pas le registre |
| T-01-007 | I | Deux sessions pour un utilisateur, logout de l'une | Seule la session courante est révoquée | Révocation par user_id au lieu de sid |
| T-01-008 | I | Session au-delà de sa durée absolue | 401 | Calcul d'expiration, fuseau horaire, horloge |
| T-01-009 | I | Échec de login (mot de passe faux, e-mail inconnu) | Même code, même message, aucun détail ; événement d'audit émis | Message d'erreur différencié : fuite d'énumération |
| T-01-010 | I | Cookie refresh émis | HttpOnly, SameSite, Secure selon l'environnement | Paramètres du cookie dans le routeur auth |
| T-01-011 | U | JWT à signature invalide, expiré, alg none | Tous rejetés | Options de decode (algorithms, verify_exp) |

### Module 02 - Schéma de données (migration 0026)

Branche : `authz-02`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-02-001 | M | Utilisateur is_active=true | status = active | Règle de rattrapage SQL de 0026 |
| T-02-002 | M | is_active=false avec mot de passe placeholder | status = invited | Comparaison avec la valeur exacte du placeholder |
| T-02-003 | M | is_active=false avec hash réel | status = disabled | Règle de rattrapage : ordre des conditions |
| T-02-004 | M | Lignes migrées | Le placeholder est remplacé par NULL, hashed_password est nullable | ALTER COLUMN manquant |
| T-02-005 | M | downgrade de 0026 | is_active est cohérent avec status ; la perte invited/disabled est documentée | Mapping inverse incomplet |
| T-02-006 | I | Deux licences actives identiques (user, clé) | Refus par contrainte d'unicité | Index unique partiel absent (revoked_at IS NULL) |
| T-02-007 | I | Licence révoquée puis ré-attribuée | Autorisé | Index unique non partiel |
| T-02-008 | I | Deux jetons de même token_hash | Refus par contrainte | Contrainte unique manquante |
| T-02-009 | I | Valeur de status hors enum | Refus par la base | Type enum non appliqué |
| T-02-010 | I | Suppression d'un utilisateur ayant jetons et licences | Comportement conforme à l'ADR (cascade ou refus) | ON DELETE non défini |
| T-02-011 | I | Chaque statut | is_active dérivé vaut true uniquement pour active | Propriété du modèle |
| T-02-012 | M | Après 0026 | Une seule tête Alembic | Numérotation ou down_revision |

### Module 03 - Noyau de permissions

Branche : `authz-03`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-03-001 | U | Rôle admin | Possède users:manage et licenses:manage | Table ROLE_PERMS |
| T-03-002 | U | Rôle member | Aucune permission plateforme | Table ROLE_PERMS trop large |
| T-03-003 | U | Niveaux viewer, editor, owner | read ; read+write ; read+write+admin | Table LEVEL_PERMS |
| T-03-004 | U | Rôle plus niveau combinés | Union des permissions applicables | authorize() ignore l'un des deux axes |
| T-03-005 | U | Permission inconnue | Refus par défaut | authorize() permissif par défaut |
| T-03-006 | U | Permission de workspace sans workspace_id | Refus | Absence de contrôle d'argument |
| T-03-007 | U | Utilisateur non membre du workspace | Refus | Appartenance non consultée |
| T-03-008 | U | Cohérence du catalogue | Chaque Permission figure dans au moins une table | Permission ajoutée sans mapping |
| T-03-009 | U | Tables de permissions | Non modifiables à l'exécution | Dictionnaires mutables partagés |

### Module 04 - Cycle de vie du compte

Branche : `authz-04`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-04-001 | I | Compte invited | Login refusé avec la réponse générique | Statut non vérifié dans le login |
| T-04-002 | I | Compte disabled | Login refusé avec la réponse générique | Statut non vérifié dans le login |
| T-04-003 | I | Compte disabled avec access token émis avant | 401 | get_current_user ne contrôle pas status (ARCH-006) |
| T-04-004 | I | Compte disabled, refresh | Refus | Refresh sans contrôle du statut |
| T-04-005 | I | setup-account avec jeton valide et mot de passe conforme | Compte active, mot de passe défini, jeton consommé | Transaction partielle : statut ou jeton non mis à jour |
| T-04-006 | I | Même jeton rejoué | 400 générique | consumed_at non testé |
| T-04-007 | I | Jeton expiré | 400 générique identique au rejeu | Comparaison d'horodatage, fuseau |
| T-04-008 | I | Jeton inconnu | Même code et même corps que expiré et rejoué | Message distinct : énumération |
| T-04-009 | I | Deux requêtes simultanées avec le même jeton | Une seule réussit | Consommation non atomique (SELECT puis UPDATE) |
| T-04-010 | I | Mot de passe trop faible | 422 et jeton non consommé | Validation après consommation |
| T-04-011 | I | setup-account sur un compte déjà actif | Refus | Absence de contrôle du statut |
| T-04-012 | I | Jeton généré | La base ne contient que le hash | Jeton en clair persisté |
| T-04-013 | I | Renvoi d'invitation | Les anciens jetons deviennent invalides | Anciens jetons non invalidés |
| T-04-014 | I | Activation réussie | Un seul événement user.activated | Audit dupliqué ou absent |
| T-04-015 | U | Génération de jeton | Longueur et unicité suffisantes | Générateur non cryptographique |
| T-04-016 | I | Compte avec hashed_password NULL | Aucun mot de passe n'ouvre l'accès | Comparaison de hash sur NULL |

### Module 05 - Envoi asynchrone de l'e-mail d'invitation

Branche : `authz-05`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-05-001 | U | Tâche send_invitation_email | Reçoit user_id et jeton clair, jamais le hash | Signature de la tâche |
| T-05-002 | I | Création d'un utilisateur | Une tâche est publiée (broker simulé) | Appel direct au lieu de .delay() |
| T-05-003 | I | SMTP en erreur | La création renvoie 201 et invitation.email_failed est audité | Exception remontée au routeur |
| T-05-004 | I | APP_ENV=development | Le lien est journalisé | Condition d'environnement inversée |
| T-05-005 | I | APP_ENV=production | Le lien n'apparaît dans aucun log | Garde d'environnement absente (secret en clair) |
| T-05-006 | U | Contenu du message | Lien HTTPS, aucun mot de passe, jeton présent une fois | Gabarit d'e-mail |
| T-05-007 | I | Échec temporaire puis succès | Retry borné, un seul e-mail livré | Idempotence de la tâche |
| T-05-008 | I | SMTP lent simulé | La latence de l'endpoint ne dépend pas de SMTP | Envoi synchrone résiduel |

### Module 06 - Contrôle des licences et /auth/me

Branche : `authz-06`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-06-001 | I | Flag désactivé, échantillon de routes gated | Réponses identiques au comportement actuel | Dépendance appliquée sans test du flag |
| T-06-002 | I | Flag activé, aucune licence | 403 {code: license_required, license} | Format d'erreur ou dépendance absente |
| T-06-003 | I | Flag activé, licence active | 200 | Lecture de la licence : filtre revoked_at ou expires_at |
| T-06-004 | I | Licence expirée | 403 | Comparaison avec l'heure courante |
| T-06-005 | I | Licence révoquée | 403 | Filtre revoked_at |
| T-06-006 | I | Licence retirée pendant une session | 403 à la requête suivante sans reconnexion | Licence lue dans le JWT ou mise en cache |
| T-06-007 | I | Refus de licence | Événement access.denied_license émis | Audit non appelé |
| T-06-008 | I | Utilisateur admin sans licence | 403 sur le module | Passe-droit implicite pour admin |
| T-06-009 | I | GET /auth/me | Statut, rôle, licences actives uniquement, permissions effectives | Construction de la réponse |
| T-06-010 | I | GET /auth/me sans token | 401 | Route non protégée |
| T-06-011 | C | Introspection des routeurs gated | Aucune route sans require_license | Route ajoutée en dehors du routeur |
| T-06-012 | I | Licence d'un autre utilisateur | Aucun effet sur l'utilisateur courant | Jointure ou filtre user_id |
| T-06-013 | I | Attribution d'une clé inconnue | Rejet 422 | Enum non validé en entrée |
| T-06-014 | U | expires_at égal à maintenant | Comportement de borne documenté et testé | Opérateur < au lieu de <= |

### Module 07 - Endpoints d'administration

Branche : `authz-07`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-07-001 | I | Admin crée un utilisateur | 201, status invited, mot de passe NULL, jeton créé, audit user.invited | Étape manquante dans la transaction |
| T-07-002 | I | Member appelle la création | 403 | Dépendance require_role absente |
| T-07-003 | I | E-mail déjà utilisé | 409 | Contrainte unique non traduite |
| T-07-004 | I | E-mail invalide | 422 | Schéma Pydantic |
| T-07-005 | I | Renvoi d'invitation | Ancien jeton invalide, nouveau valide | Invalidation manquante |
| T-07-006 | I | Renvoi sur compte actif | Refus | Absence de contrôle du statut |
| T-07-007 | I | Désactivation | status disabled et toutes les sessions révoquées | Révocation hors transaction |
| T-07-008 | I | Erreur pendant la désactivation | Rollback complet, aucun état partiel | Deux commits successifs |
| T-07-009 | I | Admin se désactive lui-même ou dernier admin (règle à confirmer) | Refus selon la règle retenue | Règle non implémentée |
| T-07-010 | I | PUT licenses | L'ensemble est remplacé, différentiel audité (granted, revoked) | Fusion au lieu de remplacement |
| T-07-011 | I | PUT licenses identique deux fois | Idempotent, aucun événement superflu | Écriture inutile |
| T-07-012 | I | Liste des utilisateurs | Statut, licences, pagination, réservée à l'admin | Requête N+1 ou accès ouvert |
| T-07-013 | I | Réactivation d'un disabled par admin | active ; anciennes sessions toujours révoquées | Sessions ressuscitées |
| T-07-014 | I | Changement de rôle | Effet immédiat sur les permissions | Rôle mis en cache |

### Module 08 - Activation via Microsoft SSO

Branche : `authz-08`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-08-001 | I | Compte invited, e-mail correspondant | active et session créée | Rapprochement par e-mail |
| T-08-002 | I | Compte disabled | 403 générique, aucune activation | Auto-activation OAuth (comportement actuel du HANDOFF) |
| T-08-003 | I | E-mail inconnu | Refus ou provisioning selon la décision Q-001 | Décision non appliquée |
| T-08-004 | I | state absent ou invalide | Refus | Contrôle CSRF |
| T-08-005 | I | Tenant ou domaine non autorisé | Refus | Contrôle du tid ou du domaine |
| T-08-006 | I | E-mail avec casse ou espaces différents | Correspondance normalisée | Normalisation manquante |
| T-08-007 | I | Compte déjà actif | Connexion normale, aucun doublon | Création d'un second compte |
| T-08-008 | I | Activation par SSO | Événement user.activated avec source sso | Audit sans source |

### Module 09 - Cloisonnement des workspaces (Neo4j)

Branche : `authz-09`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-09-001 | I | Membre de A lit A | 200 | Filtre trop strict |
| T-09-002 | I | Membre de A lit B | 404 | Filtre absent dans graph_repo |
| T-09-003 | I | Membre de A écrit ou supprime dans B | 404 et graphe inchangé | Requête Cypher sans clause d'appartenance |
| T-09-004 | I | Recherche et listing | Uniquement les données de A | Requête globale |
| T-09-005 | I | Identifiant de nœud de B via le workspace A | 404 (IDOR) | Nœud résolu sans vérifier son workspace |
| T-09-006 | I | Viewer, editor, owner | Écriture refusée au viewer ; autorisée à l'editor ; administration à l'owner | LEVEL_PERMS ou dépendance |
| T-09-007 | I | Retrait d'appartenance | Effectif à la requête suivante | Cache d'appartenance |
| T-09-008 | I | Relation entre nœuds de deux workspaces | Refus | Création de relation sans contrôle |
| T-09-009 | I | Workspace inexistant et workspace non autorisé | Réponses indiscernables | Oracle d'existence |
| T-09-010 | I | Admin plateforme sans appartenance (règle à confirmer) | Aucun accès implicite aux données | Contournement de rôle |

### Module 10 - Contrat OpenAPI

Branche : `authz-10`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-10-001 | C | Schéma généré | Identique à l'instantané versionné | Instantané non régénéré |
| T-10-002 | C | Route ajoutée sans mise à jour de l'instantané | La CI détecte la dérive | Comparaison inactive |
| T-10-003 | C | Contrat | /auth/me et les endpoints admin présents avec leurs erreurs | Annotations de réponses manquantes |
| T-10-004 | C | Sécurité | Toute route porte un schéma de sécurité hors liste blanche (login, setup-account, health, callback SSO) | Route publique involontaire |
| T-10-005 | C | Paramètres de requête | Aucun token ni mot de passe en query string | Paramètre sensible déclaré en query |
| T-10-006 | C | Codes d'erreur | 401, 403 license_required et 404 documentés | Réponses non déclarées |

### Module 11 - Frontend : AuthStore et intercepteur

Branche : `authz-11`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-11-001 | J | Après login | /auth/me remplit le store | Chargement non déclenché |
| T-11-002 | J | /auth/me répond 401 | Déconnexion et réinitialisation du store | Gestion d'erreur du store |
| T-11-003 | J | Plusieurs requêtes 401 simultanées | Une seule redirection, aucune boucle | Intercepteur non protégé contre la concurrence |
| T-11-004 | J | 403 license_required | /auth/me rafraîchi une fois et message affiché | Intercepteur trop large ou boucle de refresh |
| T-11-005 | J | 403 d'une autre nature | Aucun rafraîchissement | Test du code d'erreur absent |
| T-11-006 | J | Access token expiré | Refresh transparent puis requête rejouée | File d'attente de refresh |
| T-11-007 | J | Changement d'utilisateur | Aucune licence de l'ancien utilisateur ne subsiste | Store non réinitialisé |
| T-11-008 | J | Stockage du token | Aucun token en localStorage ni sessionStorage | Persistance involontaire |
| T-11-009 | J | Signaux dérivés | hasLicense et hasPermission réagissent aux mises à jour | Signal non dérivé |

### Module 12 - Frontend : guards, menu, page non autorisé

Branche : `authz-12`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-12-001 | J | Flag désactivé | Navigation et menu identiques à l'existant | Flag ignoré dans le guard |
| T-12-002 | J | Flag activé, licence présente | Navigation autorisée | Lecture du store |
| T-12-003 | J | Flag activé, licence absente | Redirection vers /unauthorized | Guard mal enregistré |
| T-12-004 | J | Utilisateur non connecté | Redirection vers /login avec returnUrl | Ordre des guards |
| T-12-005 | J | Directive *hasLicense | Affiche ou masque et réagit aux changements du store | Détection de changement |
| T-12-006 | J | Menu | Entrées masquées, sous-menus vides masqués | Filtre récursif |
| T-12-007 | J | URL saisie directement sur une route gated | /unauthorized (le masquage seul ne suffit pas) | Route non protégée |
| T-12-008 | J | Page /unauthorized | Accessible sans licence, aucune information sensible | Page elle-même protégée ou bavarde |
| T-12-009 | J | Module chargé en lazy loading sans licence | Le module n'est pas téléchargé | canMatch absent |

### Module 13 - Frontend : administration des utilisateurs

Branche : `authz-13`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-13-001 | J | Liste | Statuts et licences affichés correctement | Mapping d'enum |
| T-13-002 | J | Formulaire d'invitation | Validation e-mail, rôle, licences ; envoi une fois | Double soumission |
| T-13-003 | J | Compte invited ou actif | Renvoi proposé uniquement pour invited | Condition d'affichage |
| T-13-004 | J | Désactivation | Confirmation, état mis à jour, session de la cible non touchée côté UI | Rafraîchissement de liste |
| T-13-005 | J | Édition des licences | Sélection, enregistrement, gestion d'erreur | Appel PUT et rechargement |
| T-13-006 | J | Erreur API | Message utile sans détail sensible | Message brut du serveur affiché |
| T-13-007 | J | Utilisateur non admin | Route inaccessible | Guard de rôle |
| T-13-008 | J | Accessibilité de base | Labels, focus, navigation clavier | Composants sans label |

### Module 14 - Frontend : déconnexion sur inactivité

Branche : `authz-14`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-14-001 | J | Inactivité atteinte (timers simulés) | Déconnexion après le délai | Calcul du délai |
| T-14-002 | J | Activité utilisateur | Le compteur est réinitialisé | Écouteurs d'événements |
| T-14-003 | J | Approche de l'échéance | Avertissement affiché avant la déconnexion | Seuil d'avertissement |
| T-14-004 | J | Réseau en erreur au logout | Nettoyage local malgré l'erreur | Promesse rejetée non gérée |
| T-14-005 | J | Plusieurs onglets | Déconnexion propagée (si retenu dans la conception) | Événement storage |
| T-14-006 | J | Utilisateur non connecté | Aucun timer actif | Service démarré trop tôt |
| T-14-007 | J | Destruction du service | Écouteurs et timers libérés | Fuite mémoire |

### Module 16 - Documentation

Branche : `authz-16`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-16-001 | P | Documents modifiés | Tous les liens relatifs sont valides | Fichier renommé sans mise à jour |
| T-16-002 | P | Diagrammes Mermaid | La syntaxe est valide | Erreur de syntaxe dans .mmd |
| T-16-003 | P | Fiches d'audit citées | Les fichiers référencés existent | Référence obsolète |

### Module 17 - Suppression de is_active (0027)

Branche : `authz-17`.

| ID | Niv. | Situation et action | Attendu | Diagnostic probable |
|---|---|---|---|---|
| T-17-001 | M | 0027 upgrade | La colonne is_active n'existe plus | Migration incomplète |
| T-17-002 | M | 0027 downgrade | La colonne est recréée et cohérente avec status | Mapping inverse |
| T-17-003 | P | Recherche statique | Plus aucune référence à is_active dans le code | Usage résiduel |

## 5. Scénarios fonctionnels de haut niveau

Ces scénarios assemblent les tests modulaires en parcours métier. Ils sont implémentés en niveau E dans `backend/tests/authz/scenarios/` (et côté Jest pour F-12 et F-13). Un scénario est vert si **tous** les tests qui le composent sont verts et si son déroulé complet passe.


| ID | Parcours | Étant donné | Quand | Alors | Tests composants | Gate |
|---|---|---|---|---|---|---|
| F-01 | Invitation puis activation par mot de passe | Un admin connecté | Il invite un utilisateur ; celui-ci ouvre le lien, définit son mot de passe, se connecte puis ouvre un module licencié | L'utilisateur voit exactement les modules licenciés et ses workspaces | T-07-001, T-05-002, T-04-005, T-01-002, T-06-009, T-06-003 | authz-15 |
| F-02 | Invitation puis activation par SSO | Un compte invited | L'utilisateur se connecte par Microsoft avec l'e-mail invité | Compte active, session créée, accès identique à F-01 | T-08-001, T-08-008, T-06-009 | authz-15 |
| F-03 | Invitation expirée puis renvoi | Un jeton expiré | L'utilisateur échoue, l'admin renvoie, l'utilisateur active avec le nouveau jeton | Ancien jeton refusé, nouveau accepté, réponses indiscernables | T-04-007, T-07-005, T-04-005, T-04-013 | authz-15 |
| F-04 | Retrait de licence en cours de session | Un utilisateur connecté avec licence | L'admin retire la licence | 403 à la requête suivante sans reconnexion ; menu mis à jour après rafraîchissement | T-07-010, T-06-006, T-06-007, T-11-004, T-12-007 | authz-15 |
| F-05 | Désactivation en cours de session | Un utilisateur connecté | L'admin le désactive | Accès coupé immédiatement, refresh refusé, audit présent | T-07-007, T-01-004, T-04-003, T-04-004 | authz-15 |
| F-06 | Isolation entre workspaces | Deux utilisateurs membres de workspaces différents | Chacun tente d'accéder, d'écrire et de deviner les identifiants de l'autre | Aucune donnée ni information d'existence ne fuit | T-09-002, T-09-003, T-09-004, T-09-005, T-09-009 | authz-15 |
| F-07 | Tentatives d'escalade | Un member et un viewer | Le member appelle l'administration ; le viewer tente d'écrire | 403 et 404 attendus, aucune mutation | T-07-002, T-09-006, T-03-002 | authz-15 |
| F-08 | Panne SMTP à l'invitation | SMTP indisponible | L'admin invite un utilisateur | 201, échec audité, renvoi possible, aucun secret dans les logs | T-05-003, T-05-005, T-07-005 | authz-15 |
| F-09 | Migration sur données hétérogènes et retour arrière | Base avec comptes actifs, invités et désactivés | upgrade 0026, contrôle, downgrade | Statuts conformes aux règles, aucune perte hors perte documentée | T-02-001, T-02-002, T-02-003, T-02-004, T-02-005 | authz-02 |
| F-10 | Bascule du flag de licences | Flag off puis on | Mêmes requêtes avant et après | Parité à flag off, refus structurés à flag on, retour à l'état initial en repassant off | T-06-001, T-06-002, T-12-001 | authz-15 |
| F-11 | Rejeu et concurrence du jeton | Un jeton valide | Deux activations simultanées puis un rejeu | Une seule réussit, les autres reçoivent la réponse générique | T-04-009, T-04-006 | authz-15 |
| F-12 | Parcours frontend dynamique | Deux profils de licences | Connexion, navigation par menu, saisie directe d'URL | Menu et routes cohérents ; /unauthorized pour l'accès direct interdit | T-11-001, T-12-002, T-12-003, T-12-006, T-12-007 | authz-15 |
| F-13 | Inactivité puis reconnexion | Utilisateur connecté inactif | Le délai expire | Déconnexion, store vidé, reconnexion propre | T-14-001, T-14-004, T-11-007 | authz-15 |
| F-14 | Réactivation d'un compte désactivé | Un compte disabled | L'admin le réactive | Connexion possible ; anciennes sessions toujours invalides | T-07-013, T-01-004 | authz-15 |
| F-15 | Non-régression des parcours existants | Flag off | Login local, Microsoft OAuth existant, ACL de workspace | Comportement strictement identique à la version précédente | T-06-001, T-01-002, T-09-001, T-08-007 | authz-15 |

## 6. Diagnostic en cas d'échec

### 6.1 Bundle de diagnostic (un par test en échec)

Écrit dans `test-artifacts/diagnostics/<tid>.json`, **expurgé**. Contenu :

| Rubrique | Contenu | Règle d'expurgation |
|---|---|---|
| `test` | id, module, niveau, gate, durée, tentative | - |
| `error` | type, message, extrait de trace (30 lignes) | secrets remplacés par `[REDACTED]` |
| `http` | dernières requêtes et réponses (méthode, chemin, statut, corps) | `Authorization`, `Set-Cookie`, jetons, mots de passe masqués |
| `db` | lignes concernées de `users`, `auth_sessions`, `user_licenses`, `account_tokens` | aucun hash de mot de passe ; jetons : hash tronqué |
| `audit` | 20 derniers événements d'audit | - |
| `migrations` | `alembic current`, `alembic heads` | - |
| `flags` | valeurs de `AUTHZ_ENFORCE_LICENSES`, `APP_ENV` | - |
| `logs` | logs applicatifs du test | filtre sur les motifs secrets |
| `front` (Jest) | état du store, derniers appels HTTP simulés, extrait de DOM | jetons masqués |
| `env` | commit, branche, version Python/Node, image PostgreSQL | - |

### 6.2 Classification automatique

| Classe | Critère | Action |
|---|---|---|
| `ENV` | connexion refusée, délai dépassé vers un service, fixture de session sautée | relancer le job ; si persistant, corriger la CI |
| `DONNEES` | échec dans la construction des fixtures (contrainte, enum) | corriger les données de test |
| `TEST` | exception dans le code de test, assertion sur un détail non spécifié | corriger le test |
| `FLAKY` | échec puis succès à la relance unique | marquer, ouvrir une action de stabilisation ; ne jamais masquer |
| `PRODUIT` | assertion de comportement échoue avec un environnement sain | rapporter au développeur avec le bundle |

Une relance automatique unique est autorisée pour détecter le flaky ; le premier échec reste visible.

### 6.3 Arbre de diagnostic (règles à encoder dans `diagnostic_rules.yml`)

| Symptôme observé | Hypothèses ordonnées | Vérifications du bundle | Fichiers à examiner |
|---|---|---|---|
| 401 sur un login valide après migration | statut mal rattrapé ; hash NULL | `db.users.status`, présence du hash | migration 0026, `user_repo` |
| 200 au lieu de 401 pour disabled | statut non vérifié ; session non consultée | `db.users.status`, `db.sessions` | `identity/dependencies.py` |
| 403 absent sans licence | flag off ; dépendance non branchée | `flags`, routeur concerné | `core/config.py`, routeur |
| 403 présent avec licence valide | licence expirée ou révoquée ; horloge | `db.user_licenses` (dates), `clock` | `license_repo` |
| Jeton rejoué accepté | consommation non atomique | `db.account_tokens.consumed_at` | `account_tokens` repo |
| Deux activations concurrentes réussissent | SELECT puis UPDATE | journal des requêtes | repo des jetons |
| Réponses différentes selon la cause du jeton | messages distincts | `http` comparés | routeur `setup-account` |
| Lien d'invitation dans les logs en production | garde d'environnement absente | `flags.APP_ENV`, `logs` | `email_service.py` |
| 200 sur workspace d'un autre utilisateur | filtre manquant | requête exécutée, `db.memberships` | `graph_repo.py`, `workspace_repo.py` |
| Tests d'intégration ignorés | PostgreSQL absent ; fixture qui saute | `env`, sortie du job | `tests/integration/conftest.py` |
| Migration à deux têtes | branche divergente | `migrations.heads` | `alembic/versions/` |
| Boucle de redirection 401 côté front | intercepteur non protégé | `front.http` répétitions | intercepteur HTTP |
| Menu non masqué malgré l'absence de licence | store non initialisé ; flag | `front.store`, `flags` | `AuthStore`, directive |
| Déconnexion non effectuée à l'inactivité | timers non simulés ; écouteurs | `front.store` | `AutoLogoutService` |
| Dérive du contrat OpenAPI | route modifiée sans instantané | diff du schéma | instantané `docs/api/openapi.json` |

Les règles sont déterministes (correspondance de motifs). Aucune génération automatique d'hypothèses par un modèle de langage dans la CI.

### 6.4 Mise en œuvre du hook (référence)

```python
# backend/tests/authz/conftest.py
import pytest
from .diagnostics import collect_bundle

def pytest_configure(config):
    config.addinivalue_line("markers", "tid(id): identifiant du catalogue, ex. T-04-006")
    config.addinivalue_line("markers", "gate(name): gate concernée, ex. authz-04")

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    tid = item.get_closest_marker("tid")
    if tid:
        rep.user_properties.append(("tid", tid.args[0]))
    if rep.when == "call" and rep.failed:
        rep.user_properties.append(("diagnostic_bundle", str(collect_bundle(item))))
```

À valider en CI : le transfert de `user_properties` vers le JUnit dépend de la version de pytest.

```python
@pytest.mark.tid("T-04-006")
@pytest.mark.gate("authz-04")
def test_setup_account_token_replay_is_rejected(client, invited_user, activation_token):
    first = client.post("/v1/auth/setup-account", json={"token": activation_token, "password": VALID_PASSWORD})
    assert first.status_code == 200
    replay = client.post("/v1/auth/setup-account", json={"token": activation_token, "password": VALID_PASSWORD})
    assert replay.status_code == 400
    assert replay.json() == GENERIC_TOKEN_ERROR
```

```ts
// Jest
describe('[T-12-003] licenseGuard sans licence', () => {
  it('redirige vers /unauthorized', async () => { /* ... */ });
});
```

## 7. Dashboard de rapport des tests (livrable prioritaire)

### 7.1 Objectif

Un tableau de bord unique, lisible en moins d'une minute, répondant à : *où en est chaque gate, qu'est-ce qui est cassé, pourquoi, et par où commencer ?* Il est publié par la CI à chaque exécution.

### 7.2 Forme

- Un fichier `dashboard.html` **autonome** (CSS et JavaScript intégrés, aucune dépendance réseau), plus `results.json`.
- Généré par `tools/test-dashboard/build_dashboard.py` (bibliothèque standard Python uniquement, pas de CDN).
- Thèmes clair et sombre, utilisable sur mobile, navigation clavier, contrastes suffisants, statut jamais indiqué par la couleur seule (icône et texte).
- Chargement sans erreur même si certaines entrées sont absentes (résultats partiels autorisés, signalés).

### 7.3 Données d'entrée

| Source | Usage |
|---|---|
| JUnit XML (pytest backend, Jest) | statuts, durées, propriété `tid` |
| `test-artifacts/diagnostics/*.json` | panneau de diagnostic |
| `tools/test-dashboard/catalog.json` | catalogue complet (détecte les tests manquants) |
| `diagnostic_rules.yml` | pistes de diagnostic |
| rapports de couverture (pytest-cov, Jest) | indicateurs de couverture |
| `history.json` (artefact de la dernière exécution réussie sur la branche d'intégration) | tendances |

### 7.4 Contrat de données `results.json`

```json
{
  "schema_version": 1,
  "run": {
    "build_id": "", "commit": "", "branch": "", "target_branch": "",
    "started_at": "", "finished_at": "",
    "flags": {"AUTHZ_ENFORCE_LICENSES": false},
    "executed": true
  },
  "summary": {"total": 0, "passed": 0, "failed": 0, "pending": 0, "skipped": 0, "blocked": 0, "missing": 0, "not_run": 0, "flaky": 0, "duration_ms": 0},
  "tests": [{
    "id": "T-04-006", "module": "04", "level": "I", "gate": "authz-04",
    "title": "", "status": "passed|failed|error|pending|skipped|blocked|missing|not_run",
    "duration_ms": 0, "attempts": 1,
    "classification": "PRODUIT|TEST|ENV|DONNEES|FLAKY|null",
    "scenarios": ["F-03", "F-11"],
    "error": {"type": "", "message": "", "trace_excerpt": ""},
    "diagnostic": {"bundle": "diagnostics/T-04-006.json", "hints": [], "suspect_files": []}
  }],
  "gates": [{"gate": "authz-04", "status": "go|no-go|incomplete", "reasons": []}],
  "coverage": {"backend_pct": null, "frontend_pct": null},
  "history": [{"build_id": "", "date": "", "passed": 0, "failed": 0, "pending": 0}]
}
```

Statut de gate : `go` (règle de la section 3 satisfaite), `no-go` (au moins un échec actif ou une classe `PRODUIT` ouverte), `incomplete` (tests manquants, `not_run` ou `blocked`).

### 7.5 Vues obligatoires

1. **Synthèse.** Verdict global, compteurs par statut, taux de réussite, durée totale, commit et branche, flags actifs, bandeau « non exécuté » si `run.executed` est faux.
2. **Gates.** Tableau des branches `authz-00` à `authz-17` avec statut go, no-go ou incomplete, raisons et lien vers les tests concernés. C'est la vue de décision de merge.
3. **Matrice module x niveau.** Carte de chaleur (compteurs réussis sur total) ; un clic filtre la liste.
4. **Scénarios fonctionnels.** Les 15 scénarios F avec statut calculé, étapes (tests composants) et premier test en échec.
5. **Échecs et diagnostic.** Liste triée par gravité (PRODUIT d'abord) : classification, symptôme, hypothèses ordonnées, fichiers suspects, extraits expurgés du bundle, commande de reproduction ciblée (`pytest -k`, ou `jest -t`).
6. **Traçabilité.** Pour chaque exigence ou fiche d'audit (ARCH-006, ARCH-014, TASK licences, ...), les tests qui la couvrent et leur statut.
7. **Stabilité et performance.** Tests instables (relances), 10 plus lents, évolution de durée.
8. **Tendances.** Courbes sur les dernières exécutions : réussis, échecs, en attente, couverture.
9. **Couverture.** Pourcentages backend et frontend et écart avec l'exécution précédente.

Filtres communs : module, niveau, gate, statut, classification, recherche texte par ID ou titre. Exports : CSV et JSON de la vue filtrée.

### 7.6 Calculs

- Taux de réussite = réussis / (réussis + échoués + erreurs). Les tests `pending` sont exclus du dénominateur et affichés à part.
- Un test du catalogue sans résultat est `missing` (jamais compté comme réussi).
- Un scénario F est `passed` si tous ses tests composants sont `passed` et que son propre test de parcours est `passed`.
- Verdict global : `FAIL` si une gate active est `no-go` ; `INCOMPLETE` si des tests sont `missing`, `not_run` ou `blocked` ; sinon `PASS`.

### 7.7 Critères d'acceptation du dashboard

- Le fichier s'ouvre hors ligne et sans erreur de console.
- Avec le jeu d'exemple `tools/test-dashboard/tests/fixtures/` : 1 test réussi, 1 échoué `PRODUIT`, 1 `pending`, 1 `missing` et 1 flaky sont tous visibles avec la bonne classification.
- Un JUnit invalide ou vide produit un dashboard `INCOMPLETE` avec un message clair (et non une page blanche).
- Les secrets présents dans un bundle de test (fixture contenant un faux jeton) n'apparaissent jamais dans le HTML ni dans `results.json`.
- Tests du générateur : calcul des gates, calcul des scénarios, expurgation, résultats partiels.

### 7.8 Publication (Azure Pipelines)

```yaml
- job: authz_test_report
  displayName: Rapport de tests authz
  dependsOn: [backend_unit, backend_integration, backend_migrations, frontend]   # noms à adapter
  condition: succeededOrFailed()
  pool: { vmImage: ubuntu-latest }
  steps:
    - download: current
      patterns: '**/test-artifacts/**'
    - script: >
        python tools/test-dashboard/build_dashboard.py
        --junit "$(Pipeline.Workspace)/**/junit-*.xml"
        --diagnostics "$(Pipeline.Workspace)/**/diagnostics"
        --catalog tools/test-dashboard/catalog.json
        --out "$(Build.ArtifactStagingDirectory)/dashboard"
      displayName: Générer le dashboard
    - script: echo "##vso[task.uploadsummary]$(Build.ArtifactStagingDirectory)/dashboard/summary.md"
      displayName: Résumé sur la page du build
    - task: PublishPipelineArtifact@1
      condition: always()
      inputs:
        targetPath: '$(Build.ArtifactStagingDirectory)/dashboard'
        artifact: test-dashboard
```

Les jobs de test doivent publier leurs JUnit et bundles (`PublishPipelineArtifact`) même en cas d'échec (`condition: always()`). Le générateur produit aussi `summary.md` (verdict, compteurs, gates, 5 premiers échecs) pour la page du build.

## 8. Tâches de l'agent (dans cet ordre)

| ID | Tâche | Livrable | Critère d'acceptation |
|---|---|---|---|
| AG-01 | Inventaire du code réel : chemins, noms de variables, `conftest.py`, routeurs, services Angular ; confirmer ou corriger les hypothèses de `Plan.md` | `docs/testing/inventory.md` | Chaque hypothèse du §0 est marquée confirmée, corrigée ou inconnue |
| AG-02 | Socle : marqueurs, hook de diagnostic, `diagnostics.py`, factories, fixtures du §2.6 | `backend/tests/authz/conftest.py` et modules | Un test d'exemple produit un JUnit avec `tid` et un bundle expurgé |
| AG-03 | Génération de `catalog.json` à partir des sections 4 et 5 | `tools/test-dashboard/catalog.json` | Nombre d'entrées = catalogue de ce document |
| AG-04 | Modules 00 à 04, tests écrits (xfail strict si non fusionné) | tests `m00` à `m04` | Chaque ligne du catalogue a un test ou une raison `blocked` |
| AG-05 | Modules 05 à 10 | tests `m05` à `m10` | idem |
| AG-06 | Modules 11 à 14 (Jest) | `*.spec.ts` | Titres `[T-NN-NNN]`, API simulée |
| AG-07 | Scénarios F-01 à F-15 | `scenarios/` | Chaque scénario liste ses tests composants |
| AG-08 | Modules 16 et 17 | tests `m16`, `m17` | idem |
| AG-09 | Dashboard : générateur, règles de diagnostic, jeu d'exemple, tests du générateur | `tools/test-dashboard/` | Critères du §7.7 |
| AG-10 | Intégration pipeline : publication des JUnit et bundles, job `authz_test_report` | `azure-pipelines.yml` | Dashboard publié sur une PR de test, même avec un test en échec |
| AG-11 | Test de sensibilité : sur une branche jetable, introduire une mutation par risque critique (statut non vérifié, jeton non consommé, filtre workspace retiré, licence lue dans le JWT) | `docs/testing/sensitivity.md` | Chaque mutation fait échouer au moins un test, rapporté avec son ID |
| AG-12 | Rapport final | `docs/testing/report-final.md` | Voir §9 |

Chaque tâche : une branche et une PR selon `Plan.md` (type `test/`, `ci/` ou `docs/`), PR en brouillon jusqu'à CI verte.

## 9. Rapport final et définition de terminé

Le rapport final contient : nombre de tests écrits, exécutés, réussis, en attente, bloqués, manquants ; liste des défauts `PRODUIT` trouvés avec leur bundle ; liste des hypothèses non confirmées ; limites ; preuve du test de sensibilité ; lien du dashboard.

**Terminé** quand :
1. Chaque ligne du catalogue a un test ou une raison documentée.
2. Tous les tests d'une branche fusionnée sont actifs (plus de `xfail`) et verts.
3. Le dashboard est publié par la CI et conforme au §7.7.
4. Le test de sensibilité prouve que les tests détectent les régressions critiques.
5. Le rapport final distingue ce qui a été exécuté de ce qui ne l'a pas été.

## 10. Risques et points ouverts

- Les tests écrits sans exécution locale peuvent contenir des erreurs de fixtures : le premier cycle de CI sert à les stabiliser (classe `TEST` ou `DONNEES`, pas `PRODUIT`).
- Plusieurs règles dépendent de décisions ouvertes (`OPEN-QUESTIONS.md`) : dernier admin protégé, accès admin aux données de workspace, provisioning SSO, durée de l'invitation. Les tests concernés sont marqués « règle à confirmer » et doivent être alignés sur la décision avant activation.
- La migration `0025` n'a jamais été exécutée : le module 01 peut révéler des défauts préexistants.
- La conservation de l'historique du dashboard suppose un artefact stable de la branche d'intégration.

