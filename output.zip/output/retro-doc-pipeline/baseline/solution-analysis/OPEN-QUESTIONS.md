# OPEN-QUESTIONS.md

## Q-001

### Question

Which enterprise identity provider is expected in production: OIDC-only, SAML, or a custom enterprise gateway?

### Why it matters

The repository currently supports only local JWT issuance. The final design differs materially depending on the chosen identity standard and policy model.

### Possible interpretations

1. The platform should support generic OIDC with a pluggable provider.
2. The platform should integrate a single enterprise SSO vendor and use provider-specific claims.
3. The platform should support both, with an adapter layer.

### Technical impact

- token validation patterns
- session revocation strategy
- claim-to-role mapping
- operational support and governance

### Blocking

NO — the design can proceed with a generic OIDC-first assumption.

### Working assumption

The system should support a generic OIDC-compatible enterprise identity layer, with role mapping based on provider claims.

## Q-002

### Question

Does the workspace lifecycle distinguish only active vs archive, or are there additional project/environment objects to govern at the data level?

### Why it matters

This determines the scope of the context selector and the authorization model across project and environment boundaries.

### Possible interpretations

1. Only workspace-level isolation is necessary.
2. Workspace + project + environment dimensions are all required.
3. Workspace is the tenant boundary and project/environment are UI semantics only.

### Technical impact

- API query scoping
- data granularity
- frontend context state
- future multi-tenant expansion

### Blocking

NO — the design can proceed with a workspace-first model and allow project/environment context to be added as a later extension.

### Working assumption

Workspace remains the primary security boundary, while project and environment are layered contextual dimensions on top of it.
