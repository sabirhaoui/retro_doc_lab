# Follow-ups bloquants / hors lot

## Q-003 — Séparer compte invité et compte désactivé

**Constat contre le code :** `backend/app/modules/identity/router.py` délègue l’auth Microsoft à `IdentityService.login_with_microsoft`; `backend/app/modules/identity/service.py` active tout user trouvé avec `is_active=False`. La route d’invitation produit aussi des utilisateurs inactifs avant activation. `User.is_active` ne distingue donc pas « invitation en attente » de « compte désactivé par un administrateur ».

**Décision utilisateur appliquée pour ce lot :** contourner ce point en ne modifiant pas la création/activation des comptes. Le comportement Microsoft existant d’activation au premier SSO pour les invitations est préservé; la dépendance API refuse les sessions dont l’utilisateur est inactif.

**Périmètre différé :** `is_active` ne distingue pas « invitation en attente » de « désactivé par un administrateur ». Aucune modification de ce cycle n’est incluse conformément à l’instruction utilisateur. Le critère disabled-account reste à traiter dans une tâche séparée si requis.

## Q-004 — Redécouper TASK-001 autour de l’existant

Microsoft OAuth2/OIDC avec state cookie, échange de code, whitelist et cookie refresh était déjà livré. Cette implémentation ajoute un port `IdentityProvider` avec adaptateur Microsoft, un registre de sessions, `sid`/`jti`, rotation et révocation au logout. Proposition de découpage logique (partie technique livrée mais non vérifiée) :

1. TASK-001A : session registry, sid dans tokens, révocation logout, contrôle utilisateur/session et réponse HTTP sans refresh token; fichiers modifiés et migration `0025_auth_sessions`.
2. TASK-001B : décision lifecycle invité/désactivé; ajouter état admin disabled et refuser SSO si cette exigence est confirmée. Un nouveau provider n’est pas ajouté sans IdP/config discovery choisi.

Le sous-slice technique est porté à `DONE-UNVERIFIED`; les tests n’ont pas été exécutés et le cycle compte reste hors portée de ce lot.

## Q-005 — Mettre à jour les chemins TASK-001

La tâche cite `backend/app/core/config.py`, `backend/app/core/security.py`, `backend/app/api/auth_router.py`; dans le code actuel, les responsabilités sont sous `backend/app/modules/shared/config.py`, `backend/app/modules/identity/security.py` et `backend/app/modules/identity/router.py`. Les routes réelles sont `/api/v1/auth/*`, avec `/api/v1/auth/microsoft/*` déjà présentes.

## Contraintes d’exécution restantes

- Git absent : aucune branche, comparaison de commit ou commit de tâche ne peut être produit dans ce workspace.
- Baseline/tests : `pytest` n’est pas reconnu comme commande; l’appel de fallback `python -m pytest` a été ignoré. Tests = NOT RUN.
- Auth sessions : cleanup/purge des sessions expirées non inclus dans TASK-001 et à dimensionner avant une rétention longue.
- Technical accounts : `TASK-002` demande un type et des scopes pour comptes techniques. Ce sous-scope de création/provisionnement est omis conformément à la consigne de bypass; le lot couvre uniquement sessions admin/révocation/audit.
- Rollback applicatif vers un auth backend stateless : il ignorerait les SID révoqués; avant rollback, rotation du secret JWT nécessaire pour invalider les tokens en circulation. Aucun rollback/migration n’a été exécuté.
