# Progression de l’implémentation

Mode autorisé par l’utilisateur : travailler sur l’état courant sans Git. Aucune branche ni commit ne peuvent être créés; ne pas prétendre le contraire. Les tests ciblés ne sont pas exécutables/confirmés, voir `BASELINE.md`.

| TASK-ID | Statut | Branche / commit | Tests exécutés | Écarts vs plan | Notes |
| --- | --- | --- | --- | --- | --- |
| TASK-001A | DONE-UNVERIFIED | Aucun Git disponible; workspace courant utilisé; aucun commit | TEST-001/002 ajoutés; NOT RUN — `pytest` absent et fallback ignoré | OAuth Microsoft réutilisé derrière provider port; sessions sid/jti, rotation, révocation, cookie-only et migration 0025 présents. | Tests/migration non exécutés. |
| TASK-001B | SKIPPED(user instruction) | — | Tests non ajoutés/exécutés | Règles de création/activation et distinction invited/disabled non modifiées. | Critère de rejet d’un compte administrativement désactivé reste hors lot. |
| TASK-002A | DONE-UNVERIFIED | Aucun Git disponible; aucun commit | TEST-003 ajouté; NOT RUN | API admin sessions/audit et journal d’événements durable implémentés dans migration 0025. | Session revoke par admin, listing sans jti, événements create/refresh rotation/revoke. |
| TASK-002B | SKIPPED(user instruction) | — | TEST-004 non écrit/exécuté | Type/scope de compte technique et création/provisionnement exclus conformément à la demande de bypass. | Suivi conservé dans `FOLLOW-UPS.md`; ne pas déclarer US01.1.04 satisfaite. |
| TASK-003 | TODO | — | NOT RUN | Dépend de TASK-001 | Hors EPIC-01. |
| TASK-004 | TODO | — | NOT RUN | Dépend de TASK-003 | Hors lot. |
| TASK-005 | TODO | — | NOT RUN | Dépend de TASK-003 et TASK-004 | Hors lot. |
