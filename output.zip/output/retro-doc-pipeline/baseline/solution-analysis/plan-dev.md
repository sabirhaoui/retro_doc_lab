# Plan.md - Mise en place locale des branches et des pull requests (chantier authz-licences)

> **Mode d'emploi.** Ce plan sert à préparer, en local, chaque branche de fonctionnalité et chaque sous-fonction, puis à ouvrir la pull request associée. Il ne contient aucun développement : chaque fiche porte un bloc `DEV` à remplacer par le travail réel (code, tests, liens, preuves).
> Rien ici n'a été exécuté : les commandes sont à relire à la première utilisation.

## 0. Principes

- Une branche par fonctionnalité (`authz-NN`), un commit par sous-fonction (`NN.a`, `NN.b`, ...). Le commit porte l'identifiant de la sous-fonction dans son message.
- Toutes les branches partent de `integration/authz-licences` à jour et y reviennent par PR (squash). Une branche n'est créée qu'une fois ses dépendances fusionnées.
- Nommage : `<type>/authz-<NN>-<description-kebab-case>` (contrôlé par le job CI `branch_naming`).
- Une PR reste en **brouillon** jusqu'à ce que les tests de sa fiche soient écrits et la CI verte.
- Les flags (`AUTHZ_ENFORCE_LICENSES`, `authz.enforceLicenses`) sont à `false` par défaut : on peut fusionner sans changer le comportement visible.
- Une seule migration Alembic à la fois : seules les branches 02 et 17 en créent.
- Option de découpage : si une branche devient trop grosse, créez une sous-branche `<type>/authz-NN-1-<detail>` qui revient dans la branche de fonctionnalité (pas dans l'intégration).

## 1. Prérequis

```powershell
git --version
az --version
az extension add --name azure-devops
az login
az devops configure --defaults organization=https://dev.azure.com/<ORG> project=<PROJET>

git config pull.ff only
git config rebase.autoStash true
git config fetch.prune true
```

Variables utilisées par les commandes :

```powershell
$Integration = 'integration/authz-licences'
$Base        = 'dev'          # branche de départ de l'intégration
```

## 2. Fonctions d'aide PowerShell

Copiez-les dans `scripts/authz-git.ps1` puis chargez-les avec `. .\scripts\authz-git.ps1`.

```powershell
$Script:Integration = 'integration/authz-licences'

function Initialize-AuthzIntegration {
  param([string]$From = 'dev')
  git fetch origin
  git switch $From; git pull --ff-only
  git switch -c $Script:Integration
  git push -u origin $Script:Integration
}

function New-AuthzBranch {
  param(
    [Parameter(Mandatory)][ValidateSet('feat','fix','refactor','test','ci','chore','docs')][string]$Type,
    [Parameter(Mandatory)][ValidatePattern('^\d{2}$')][string]$Num,
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9]+(-[a-z0-9]+)*$')][string]$Slug
  )
  $name = "$Type/authz-$Num-$Slug"
  git fetch origin
  git switch $Script:Integration
  git pull --ff-only
  git switch -c $name

  # Stub de suivi : à supprimer dans le dernier commit de développement
  $stub = "docs/authz/wip/$Num-$Slug.md"
  New-Item -ItemType Directory -Force -Path (Split-Path $stub) | Out-Null
  "# authz-$Num ($Slug)`n`nBranche initialisée. Voir Plan.md, fiche $Num.`n`n<!-- DEV : remplacé par les développements -->" |
    Set-Content -Encoding utf8 $stub
  git add $stub
  git commit -m "chore(authz): initialise la branche $Num"
  git push -u origin $name
  Write-Host "Branche prête : $name"
}

function New-AuthzPr {
  param(
    [Parameter(Mandatory)][string]$Branch,
    [Parameter(Mandatory)][string]$Title,
    [string]$Target = $Script:Integration,
    [string]$Refs = '',
    [string]$DependsOn = '',
    [string]$WorkItem = ''
  )
  $desc = @(
    "Branche : $Branch",
    "Cible : $Target",
    "Dépend de : $DependsOn",
    "Refs : $Refs",
    "",
    "Compléter la checklist du modèle de PR (tests, migration, sécurité, retour arrière)."
  )
  $azArgs = @('repos','pr','create','--source-branch',$Branch,'--target-branch',$Target,
            '--title',$Title,'--description') + $desc +
          @('--draft','true','--squash','true','--delete-source-branch','true')
  if ($WorkItem) { $azArgs += @('--work-items',$WorkItem) }
  az @azArgs
}

function Sync-AuthzBranch {
  # Rebase de la branche courante sur l'intégration (pas de merge de dev dans une sous-branche)
  git fetch origin
  git rebase "origin/$Script:Integration"
  git push --force-with-lease
}

function Remove-AuthzBranch {
  param([Parameter(Mandatory)][string]$Branch)
  git switch $Script:Integration; git pull --ff-only
  git branch -d $Branch
}
```

## 3. Ordre de réalisation

| Vague | Branches | Prérequis |
|---|---|---|
| 0 | 00 | - |
| 1 | 01, 03 | 00 |
| 2 | 02 | 01 |
| 3 | 04 | 02 |
| 4 | 05, 06, 08, 09 | 04 (06 aussi 02 et 03 ; 09 seulement 03) |
| 5 | 07 | 04, 06 |
| 6 | 10 | 06, 07 |
| 7 | 11 | 10 |
| 8 | 12, 13, 14 | 11 |
| 9 | 15 | 07, 08, 09, 12, 13, 14 |
| 10 | 16 | 15 |
| 11 | 17 | 16 (release suivante) |

Les branches d'une même vague sont indépendantes : elles peuvent avancer en parallèle.

## 4. Initialisation (une seule fois)

```powershell
. .\scripts\authz-git.ps1
Initialize-AuthzIntegration -From dev
# Ensuite : politiques de branches (set-branch-policies.ps1) et modèle de PR (.azuredevops/pull_request_template.md)
```

## 5. Fiches par branche

Pour chaque fiche : créer la branche, développer un commit par sous-fonction, puis ouvrir la PR en brouillon. Les chemins de fichiers sont des **pistes probables** à confirmer dans le code réel.


### 00 - `ci/authz-00-postgres-integration-job`

**Job CI PostgreSQL pour les tests d'intégration**

| | |
|---|---|
| Dépend de | - |
| Refs | ARCH-014 |
| Flag | — |
| Gate de validation | Baseline CI documentée ; le job échoue sur un test volontairement cassé ; aucun test ignoré. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 00.a | `ci(authz): ajoute le conteneur PostgreSQL et le job backend_integration (00.a)` | azure-pipelines.yml |
| 00.b | `ci(authz): refuse les tests ignorés via le rapport JUnit (00.b)` | azure-pipelines.yml |
| 00.c | `ci(authz): ajoute le job backend_migrations (tête unique, upgrade/downgrade/upgrade) (00.c)` | azure-pipelines.yml |
| 00.d | `ci(authz): réactive la couverture Jest dans le job frontend (00.d)` | azure-pipelines.yml, frontend/package.json |
| 00.e | `ci(authz): ajoute le job branch_naming (00.e)` | azure-pipelines.yml |
| 00.f | `docs(authz): documente la baseline CI (durée, tests, couverture) (00.f)` | docs/authz/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type ci -Num 00 -Slug postgres-integration-job
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 00 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch ci/authz-00-postgres-integration-job `
  -Title "[authz-00] Job CI PostgreSQL pour les tests d'intégration" `
  -Refs "ARCH-014" `
  -DependsOn "-" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 00.a à 00.f committées
- [ ] Stub `docs/authz/wip/00-postgres-integration-job.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Baseline CI documentée ; le job échoue sur un test volontairement cassé ; aucun test ignoré.


### 01 - `fix/authz-01-session-registry-baseline`

**Valider le registre de sessions existant (migration 0025)**

| | |
|---|---|
| Dépend de | 00 |
| Refs | HANDOFF (DONE-UNVERIFIED), ARCH-006 |
| Flag | — |
| Gate de validation | alembic upgrade/downgrade de 0025 et tests auth/sessions verts en CI. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 01.a | `test(authz): ajoute les tests de migration 0025 (up/down) (01.a)` | backend/tests/integration/ |
| 01.b | `test(authz): couvre sid, révocation, refresh et logout (01.b)` | backend/tests/ |
| 01.c | `fix(authz): corrige les écarts révélés par la CI (corrections seules, pas de nouvelle fonctionnalité) (01.c)` | backend/app/ |
| 01.d | `docs(authz): passe les éléments du HANDOFF de DONE-UNVERIFIED à vérifié (01.d)` | solution-analysis/implementation/HANDOFF.md |

**Créer la branche**

```powershell
New-AuthzBranch -Type fix -Num 01 -Slug session-registry-baseline
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 01 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch fix/authz-01-session-registry-baseline `
  -Title "[authz-01] Valider le registre de sessions existant (migration 0025)" `
  -Refs "HANDOFF (DONE-UNVERIFIED), ARCH-006" `
  -DependsOn "00" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 01.a à 01.d committées
- [ ] Stub `docs/authz/wip/01-session-registry-baseline.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : alembic upgrade/downgrade de 0025 et tests auth/sessions verts en CI.


### 02 - `feat/authz-02-db-schema`

**Schéma de données : statut, licences, jetons (migration 0026)**

| | |
|---|---|
| Dépend de | 01 |
| Refs | ARCH-009, TASK licences |
| Flag | — |
| Gate de validation | Migration testée sur des données invitées, actives et désactivées ; downgrade vérifié ; une seule tête Alembic. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 02.a | `feat(authz): ajoute l'enum user_status et la colonne users.status avec règle de rattrapage (02.a)` | backend/alembic/versions/0026_*.py |
| 02.b | `feat(authz): rend hashed_password nullable et remplace le placeholder par NULL (02.b)` | backend/alembic/versions/0026_*.py |
| 02.c | `feat(authz): crée la table user_licenses (02.c)` | backend/alembic/versions/0026_*.py, backend/app/models/ |
| 02.d | `feat(authz): crée la table account_tokens (token_hash unique) (02.d)` | backend/alembic/versions/0026_*.py, backend/app/models/ |
| 02.e | `refactor(authz): is_active devient une propriété dérivée de status (02.e)` | backend/app/models/user.py |
| 02.f | `test(authz): teste la migration et la règle de rattrapage (02.f)` | backend/tests/integration/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 02 -Slug db-schema
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 02 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-02-db-schema `
  -Title "[authz-02] Schéma de données : statut, licences, jetons (migration 0026)" `
  -Refs "ARCH-009, TASK licences" `
  -DependsOn "01" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 02.a à 02.f committées
- [ ] Stub `docs/authz/wip/02-db-schema.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Migration testée sur des données invitées, actives et désactivées ; downgrade vérifié ; une seule tête Alembic.


### 03 - `feat/authz-03-permissions-core`

**Noyau de permissions : rôle, niveau de workspace, authorize()**

| | |
|---|---|
| Dépend de | 00 |
| Refs | TASK RBAC |
| Flag | — |
| Gate de validation | Tests unitaires purs (sans base de données) verts, table rôle/niveau exhaustive. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 03.a | `feat(authz): ajoute l'enum Permission (03.a)` | backend/app/identity/permissions.py |
| 03.b | `feat(authz): ajoute ROLE_PERMS et LEVEL_PERMS (03.b)` | backend/app/identity/permissions.py |
| 03.c | `feat(authz): ajoute authorize(user, permission, workspace_id) (03.c)` | backend/app/identity/ |
| 03.d | `test(authz): tests unitaires de la matrice rôle et niveau (03.d)` | backend/tests/unit/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 03 -Slug permissions-core
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 03 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-03-permissions-core `
  -Title "[authz-03] Noyau de permissions : rôle, niveau de workspace, authorize()" `
  -Refs "TASK RBAC" `
  -DependsOn "00" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 03.a à 03.d committées
- [ ] Stub `docs/authz/wip/03-permissions-core.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Tests unitaires purs (sans base de données) verts, table rôle/niveau exhaustive.


### 04 - `feat/authz-04-account-lifecycle`

**Cycle de vie du compte : statut vérifié, jetons, setup-account**

| | |
|---|---|
| Dépend de | 02 |
| Refs | ARCH-006, ARCH-015, TASK-001B |
| Flag | — |
| Gate de validation | invited et disabled refusés au login, au refresh et sur un access token émis ; jeton rejoué ou concurrent géré. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 04.a | `fix(authz): get_current_user vérifie la session active et status=active (04.a)` | backend/app/identity/dependencies.py |
| 04.b | `feat(authz): ajoute le dépôt account_tokens (hachage, consommation atomique) (04.b)` | backend/app/repositories/ |
| 04.c | `feat(authz): ajoute POST /v1/auth/setup-account (réponse générique) (04.c)` | backend/app/api/ |
| 04.d | `fix(authz): login et refresh refusent invited et disabled (04.d)` | backend/app/api/auth*.py |
| 04.e | `feat(authz): émet les événements d'audit user.activated (04.e)` | backend/app/repositories/ |
| 04.f | `test(authz): rejeu, concurrence, expiration, comptes invalides (04.f)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 04 -Slug account-lifecycle
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 04 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-04-account-lifecycle `
  -Title "[authz-04] Cycle de vie du compte : statut vérifié, jetons, setup-account" `
  -Refs "ARCH-006, ARCH-015, TASK-001B" `
  -DependsOn "02" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 04.a à 04.f committées
- [ ] Stub `docs/authz/wip/04-account-lifecycle.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : invited et disabled refusés au login, au refresh et sur un access token émis ; jeton rejoué ou concurrent géré.


### 05 - `feat/authz-05-email-async`

**Envoi asynchrone de l'e-mail d'invitation (Celery)**

| | |
|---|---|
| Dépend de | 04 |
| Refs | INT-CELERY-01 |
| Flag | — |
| Gate de validation | Panne SMTP simulée : la création renvoie 201 et l'échec est audité ; lien loggé uniquement en développement. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 05.a | `feat(authz): ajoute la tâche Celery send_invitation_email (05.a)` | backend/app/tasks/ |
| 05.b | `feat(authz): repli par log du lien réservé à APP_ENV=development (05.b)` | backend/app/services/email_service.py |
| 05.c | `feat(authz): audite l'échec d'envoi sans annuler la création (05.c)` | backend/app/services/ |
| 05.d | `test(authz): tests avec SMTP simulé (05.d)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 05 -Slug email-async
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 05 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-05-email-async `
  -Title "[authz-05] Envoi asynchrone de l'e-mail d'invitation (Celery)" `
  -Refs "INT-CELERY-01" `
  -DependsOn "04" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 05.a à 05.d committées
- [ ] Stub `docs/authz/wip/05-email-async.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Panne SMTP simulée : la création renvoie 201 et l'échec est audité ; lien loggé uniquement en développement.


### 06 - `feat/authz-06-api-license-enforcement`

**Routes de l'API : licences, /auth/me, flag backend**

| | |
|---|---|
| Dépend de | 02, 03, 04 |
| Refs | TASK licences, ARCH-006 |
| Flag | AUTHZ_ENFORCE_LICENSES (backend), défaut false |
| Gate de validation | 403 {code: license_required} avec flag actif ; comportement strictement inchangé flag off. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 06.a | `feat(authz): ajoute license_repo.has_active (expiration, révocation) (06.a)` | backend/app/repositories/ |
| 06.b | `feat(authz): ajoute require_license et l'audit access.denied_license (06.b)` | backend/app/identity/dependencies.py |
| 06.c | `feat(authz): ajoute le flag AUTHZ_ENFORCE_LICENSES (06.c)` | backend/app/core/config.py |
| 06.d | `refactor(authz): applique require_license au niveau des routeurs concernés (06.d)` | backend/app/api/ |
| 06.e | `feat(authz): ajoute GET /v1/auth/me (statut, rôle, licences, permissions) (06.e)` | backend/app/api/ |
| 06.f | `test(authz): 403 structuré, flag off inchangé, licence expirée ou révoquée (06.f)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 06 -Slug api-license-enforcement
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 06 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-06-api-license-enforcement `
  -Title "[authz-06] Routes de l'API : licences, /auth/me, flag backend" `
  -Refs "TASK licences, ARCH-006" `
  -DependsOn "02, 03, 04" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 06.a à 06.f committées
- [ ] Stub `docs/authz/wip/06-api-license-enforcement.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : 403 {code: license_required} avec flag actif ; comportement strictement inchangé flag off.


### 07 - `feat/authz-07-admin-user-endpoints`

**Endpoints d'administration des utilisateurs**

| | |
|---|---|
| Dépend de | 04, 06 |
| Refs | TASK-001B, TASK licences |
| Flag | — |
| Gate de validation | Désactivation : session morte à la requête suivante ; licences remplacées avec audit du différentiel. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 07.a | `feat(authz): ajoute POST /v1/admin/users (création en invited et jeton) (07.a)` | backend/app/api/admin*.py |
| 07.b | `feat(authz): ajoute POST /v1/admin/users/{id}/resend-invite (07.b)` | backend/app/api/admin*.py |
| 07.c | `feat(authz): ajoute POST /v1/admin/users/{id}/disable (révocation des sessions, même transaction) (07.c)` | backend/app/api/admin*.py |
| 07.d | `feat(authz): ajoute PUT /v1/admin/users/{id}/licenses (différentiel audité) (07.d)` | backend/app/api/admin*.py |
| 07.e | `feat(authz): ajoute la liste des utilisateurs avec statut et licences (07.e)` | backend/app/api/admin*.py |
| 07.f | `test(authz): contrôle d'accès admin, désactivation, renvoi, licences (07.f)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 07 -Slug admin-user-endpoints
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 07 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-07-admin-user-endpoints `
  -Title "[authz-07] Endpoints d'administration des utilisateurs" `
  -Refs "TASK-001B, TASK licences" `
  -DependsOn "04, 06" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 07.a à 07.f committées
- [ ] Stub `docs/authz/wip/07-admin-user-endpoints.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Désactivation : session morte à la requête suivante ; licences remplacées avec audit du différentiel.


### 08 - `feat/authz-08-sso-activation`

**Activation via Microsoft SSO**

| | |
|---|---|
| Dépend de | 04 |
| Refs | Q-001 (OPEN-QUESTIONS) |
| Flag | — |
| Gate de validation | Un invited s'active si l'e-mail correspond ; un disabled ou inconnu n'est jamais activé ; réponse sans détail. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 08.a | `feat(authz): active un compte invited au callback Microsoft (e-mail correspondant) (08.a)` | backend/app/api/auth*.py |
| 08.b | `fix(authz): refuse disabled et inconnu avec une réponse générique (08.b)` | backend/app/api/auth*.py |
| 08.c | `feat(authz): contrôle le tenant ou le domaine autorisé (à confirmer, Q-001) (08.c)` | backend/app/core/config.py |
| 08.d | `test(authz): tests du callback avec fournisseur simulé (08.d)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 08 -Slug sso-activation
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 08 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-08-sso-activation `
  -Title "[authz-08] Activation via Microsoft SSO" `
  -Refs "Q-001 (OPEN-QUESTIONS)" `
  -DependsOn "04" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 08.a à 08.d committées
- [ ] Stub `docs/authz/wip/08-sso-activation.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Un invited s'active si l'e-mail correspond ; un disabled ou inconnu n'est jamais activé ; réponse sans détail.


### 09 - `feat/authz-09-graph-isolation`

**Cloisonnement des workspaces dans Neo4j**

| | |
|---|---|
| Dépend de | 03 |
| Refs | TASK isolation, ARCH (graph_repo) |
| Flag | — |
| Gate de validation | Aucune lecture ou écriture de graphe possible hors des workspaces de l'utilisateur ; 404 pour un workspace non autorisé. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 09.a | `feat(authz): applique le filtre d'appartenance dans graph_repo.py (09.a)` | backend/app/repositories/graph_repo.py |
| 09.b | `fix(authz): renvoie 404 pour un workspace non autorisé (09.b)` | backend/app/api/ |
| 09.c | `test(authz): tests de non-fuite entre workspaces (09.c)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 09 -Slug graph-isolation
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 09 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-09-graph-isolation `
  -Title "[authz-09] Cloisonnement des workspaces dans Neo4j" `
  -Refs "TASK isolation, ARCH (graph_repo)" `
  -DependsOn "03" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 09.a à 09.c committées
- [ ] Stub `docs/authz/wip/09-graph-isolation.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Aucune lecture ou écriture de graphe possible hors des workspaces de l'utilisateur ; 404 pour un workspace non autorisé.


### 10 - `chore/authz-10-openapi-contract`

**Contrat OpenAPI figé et contrôlé en CI**

| | |
|---|---|
| Dépend de | 06, 07 |
| Refs | TASK-API-01 |
| Flag | — |
| Gate de validation | La CI échoue si le contrat dérive ; /auth/me et les endpoints admin sont documentés. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 10.a | `chore(authz): génère le schéma OpenAPI (10.a)` | backend/scripts/ |
| 10.b | `chore(authz): versionne l'instantané de contrat (10.b)` | docs/api/openapi.json |
| 10.c | `ci(authz): échoue si le contrat dérive de l'instantané (10.c)` | azure-pipelines.yml |
| 10.d | `docs(authz): documente les erreurs structurées (license_required, …) (10.d)` | docs/api/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type chore -Num 10 -Slug openapi-contract
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 10 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch chore/authz-10-openapi-contract `
  -Title "[authz-10] Contrat OpenAPI figé et contrôlé en CI" `
  -Refs "TASK-API-01" `
  -DependsOn "06, 07" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 10.a à 10.d committées
- [ ] Stub `docs/authz/wip/10-openapi-contract.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : La CI échoue si le contrat dérive ; /auth/me et les endpoints admin sont documentés.


### 11 - `feat/authz-11-front-auth-store`

**Frontend : AuthStore, /auth/me, intercepteur**

| | |
|---|---|
| Dépend de | 10 |
| Refs | TASK front |
| Flag | — |
| Gate de validation | Tests Jest verts avec /auth/me simulé ; 401 et 403 gérés de façon centralisée. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 11.a | `feat(authz): types TypeScript issus du contrat OpenAPI (11.a)` | frontend/src/app/core/ |
| 11.b | `feat(authz): ajoute l'AuthStore (Signals) (11.b)` | frontend/src/app/core/auth/ |
| 11.c | `feat(authz): charge /auth/me après login et refresh (11.c)` | frontend/src/app/core/auth/ |
| 11.d | `feat(authz): intercepteur 401 (déconnexion) et 403 license_required (rafraîchit /auth/me) (11.d)` | frontend/src/app/core/ |
| 11.e | `test(authz): tests Jest du store et de l'intercepteur (11.e)` | frontend/src/app/core/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 11 -Slug front-auth-store
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 11 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-11-front-auth-store `
  -Title "[authz-11] Frontend : AuthStore, /auth/me, intercepteur" `
  -Refs "TASK front" `
  -DependsOn "10" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 11.a à 11.e committées
- [ ] Stub `docs/authz/wip/11-front-auth-store.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Tests Jest verts avec /auth/me simulé ; 401 et 403 gérés de façon centralisée.


### 12 - `feat/authz-12-front-guards-menu`

**Frontend dynamique : guards, menu, page non autorisé**

| | |
|---|---|
| Dépend de | 11 |
| Refs | TASK front, TASK licences |
| Flag | authz.enforceLicenses (environnement Angular), défaut false |
| Gate de validation | Menu et routes suivent les licences ; flag off = interface actuelle ; guards testés. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 12.a | `feat(authz): ajoute licenseGuard (12.a)` | frontend/src/app/core/guards/ |
| 12.b | `feat(authz): ajoute la directive *hasLicense (12.b)` | frontend/src/app/shared/ |
| 12.c | `feat(authz): masque dynamiquement les entrées du menu (12.c)` | frontend/src/app/layout/ |
| 12.d | `feat(authz): ajoute la page /unauthorized (12.d)` | frontend/src/app/pages/ |
| 12.e | `feat(authz): ajoute le flag authz.enforceLicenses (12.e)` | frontend/src/environments/ |
| 12.f | `test(authz): tests des guards et du menu selon les licences (12.f)` | frontend/src/app/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 12 -Slug front-guards-menu
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 12 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-12-front-guards-menu `
  -Title "[authz-12] Frontend dynamique : guards, menu, page non autorisé" `
  -Refs "TASK front, TASK licences" `
  -DependsOn "11" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 12.a à 12.f committées
- [ ] Stub `docs/authz/wip/12-front-guards-menu.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Menu et routes suivent les licences ; flag off = interface actuelle ; guards testés.


### 13 - `feat/authz-13-front-admin-ui`

**Frontend : écrans d'administration des utilisateurs**

| | |
|---|---|
| Dépend de | 11 |
| Refs | TASK-001B, TASK licences |
| Flag | — |
| Gate de validation | Invitation, renvoi, désactivation et licences utilisables depuis l'interface ; tests de composants verts. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 13.a | `feat(authz): liste des utilisateurs avec statut et licences (13.a)` | frontend/src/app/admin/ |
| 13.b | `feat(authz): formulaire d'invitation (13.b)` | frontend/src/app/admin/ |
| 13.c | `feat(authz): gestion des licences d'un utilisateur (13.c)` | frontend/src/app/admin/ |
| 13.d | `feat(authz): actions renvoyer l'invitation et désactiver (13.d)` | frontend/src/app/admin/ |
| 13.e | `test(authz): tests de composants (API simulée) (13.e)` | frontend/src/app/admin/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 13 -Slug front-admin-ui
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 13 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-13-front-admin-ui `
  -Title "[authz-13] Frontend : écrans d'administration des utilisateurs" `
  -Refs "TASK-001B, TASK licences" `
  -DependsOn "11" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 13.a à 13.e committées
- [ ] Stub `docs/authz/wip/13-front-admin-ui.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Invitation, renvoi, désactivation et licences utilisables depuis l'interface ; tests de composants verts.


### 14 - `feat/authz-14-front-autologout`

**Frontend : déconnexion sur inactivité**

| | |
|---|---|
| Dépend de | 11 |
| Refs | TASK-SESSION |
| Flag | — |
| Gate de validation | Timers simulés vérifiés ; appel à POST /auth/logout ; avertissement avant expiration. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 14.a | `feat(authz): ajoute AutoLogoutService (détection d'inactivité) (14.a)` | frontend/src/app/core/auth/ |
| 14.b | `feat(authz): appelle POST /v1/auth/logout à l'expiration (14.b)` | frontend/src/app/core/auth/ |
| 14.c | `feat(authz): avertissement avant déconnexion (14.c)` | frontend/src/app/layout/ |
| 14.d | `test(authz): tests avec timers simulés (14.d)` | frontend/src/app/core/auth/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type feat -Num 14 -Slug front-autologout
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 14 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch feat/authz-14-front-autologout `
  -Title "[authz-14] Frontend : déconnexion sur inactivité" `
  -Refs "TASK-SESSION" `
  -DependsOn "11" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 14.a à 14.d committées
- [ ] Stub `docs/authz/wip/14-front-autologout.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Timers simulés vérifiés ; appel à POST /auth/logout ; avertissement avant expiration.


### 15 - `test/authz-15-e2e-matrix`

**Matrice de tests E2E rôle × licence × workspace**

| | |
|---|---|
| Dépend de | 07, 08, 09, 12, 13, 14 |
| Refs | Stratégie de test |
| Flag | — |
| Gate de validation | Matrice complète verte en CI ; comptes de test générés à l'exécution, aucun secret versionné. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 15.a | `test(authz): fixtures conftest.py (comptes générés à l'exécution) (15.a)` | backend/tests/conftest.py |
| 15.b | `test(authz): matrice rôle × licence × workspace (15.b)` | backend/tests/ |
| 15.c | `test(authz): scénarios activation, désactivation, révocation (15.c)` | backend/tests/ |
| 15.d | `test(authz): scénarios SSO (15.d)` | backend/tests/ |
| 15.e | `test(authz): scénarios frontend (guards, menu) (15.e)` | frontend/ |
| 15.f | `ci(authz): publie le rapport de la matrice (15.f)` | azure-pipelines.yml |

**Créer la branche**

```powershell
New-AuthzBranch -Type test -Num 15 -Slug e2e-matrix
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 15 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch test/authz-15-e2e-matrix `
  -Title "[authz-15] Matrice de tests E2E rôle × licence × workspace" `
  -Refs "Stratégie de test" `
  -DependsOn "07, 08, 09, 12, 13, 14" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 15.a à 15.f committées
- [ ] Stub `docs/authz/wip/15-e2e-matrix.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Matrice complète verte en CI ; comptes de test générés à l'exécution, aucun secret versionné.


### 16 - `docs/authz-16-docs-adr`

**Documentation et décisions d'architecture**

| | |
|---|---|
| Dépend de | 15 |
| Refs | ARCH-013, docs gaps |
| Flag | — |
| Gate de validation | Relecture validée ; fiches d'audit concernées mises à jour. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 16.a | `docs(authz): ADR du modèle de droits (rôle, workspace, licence) (16.a)` | docs/adr/ |
| 16.b | `docs(authz): README du parcours d'activation (16.b)` | README.md |
| 16.c | `docs(authz): diagramme de séquence dans diagrams/authentication/ (16.c)` | architecture-audit/diagrams/authentication/ |
| 16.d | `docs(authz): runbook de déploiement et de retour arrière (16.d)` | docs/runbooks/ |
| 16.e | `docs(authz): met à jour les fiches d'audit traitées (16.e)` | architecture-audit/findings/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type docs -Num 16 -Slug docs-adr
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 16 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch docs/authz-16-docs-adr `
  -Title "[authz-16] Documentation et décisions d'architecture" `
  -Refs "ARCH-013, docs gaps" `
  -DependsOn "15" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 16.a à 16.e committées
- [ ] Stub `docs/authz/wip/16-docs-adr.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : Relecture validée ; fiches d'audit concernées mises à jour.


### 17 - `chore/authz-17-drop-is-active`

**Suppression de is_active (migration 0027)**

| | |
|---|---|
| Dépend de | 16 |
| Refs | — |
| Flag | — |
| Gate de validation | À livrer dans une release suivante, après une période sans incident ; downgrade testé. |

**Sous-fonctions (un commit chacune)**

| ID | Message de commit | Fichiers probables |
|---|---|---|
| 17.a | `feat(authz): migration 0027 supprimant users.is_active (17.a)` | backend/alembic/versions/0027_*.py |
| 17.b | `refactor(authz): retire la propriété et les usages de is_active (17.b)` | backend/app/ |
| 17.c | `test(authz): adapte les tests (17.c)` | backend/tests/ |

**Créer la branche**

```powershell
New-AuthzBranch -Type chore -Num 17 -Slug drop-is-active
```

**Développement**

```powershell
# Pour chaque sous-fonction :
git add <fichiers>
git commit -m "<message exact du tableau ci-dessus>"
git push
```

<!-- DEV 17 : à remplacer par les développements (code, tests, liens CI, captures) -->

**Ouvrir la PR (brouillon)**

```powershell
New-AuthzPr -Branch chore/authz-17-drop-is-active `
  -Title "[authz-17] Suppression de is_active (migration 0027)" `
  -Refs "—" `
  -DependsOn "16" `
  -WorkItem <ID_WORK_ITEM>
```

**Avant de passer en "Prête"**
- [ ] Toutes les sous-fonctions 17.a à 17.c committées
- [ ] Stub `docs/authz/wip/17-drop-is-active.md` supprimé
- [ ] Tests de la fiche écrits et CI verte
- [ ] Checklist du modèle de PR complétée
- [ ] Gate de validation atteinte : À livrer dans une release suivante, après une période sans incident ; downgrade testé.


## 6. Cycle de vie d'une branche

1. `New-AuthzBranch ...` (depuis l'intégration à jour).
2. Un commit par sous-fonction, `git push` régulier.
3. `New-AuthzPr ...` : PR en brouillon dès le premier push utile.
4. Si l'intégration avance : `Sync-AuthzBranch` (rebase, jamais de merge de `dev`).
5. Passer la PR en "Prête" quand la checklist de la fiche est complète.
6. Relecture, squash merge dans `integration/authz-licences`.
7. `Remove-AuthzBranch -Branch <nom>` puis créer la branche suivante de la vague.

## 7. Livraison finale vers `dev`

Après la branche 15 verte et les flags activés sur un environnement de dev :

```powershell
New-AuthzPr -Branch integration/authz-licences `
  -Target dev `
  -Title "[authz] Authentification, licences et activation de compte" `
  -Refs "voir les PR authz-00 à authz-16" `
  -WorkItem <ID_EPIC>
```

- Merge commit (pas de squash) pour conserver l'historique des branches.
- Prévenir les utilisateurs : les tokens sans claim `sid` seront refusés (reconnexion).
- Retour arrière : `git revert` de la PR avec les flags à `false` ; `downgrade` des migrations 0026 puis 0025 si nécessaire.
- La branche 17 (suppression de `is_active`) est livrée dans une release ultérieure.

## 8. Suivi d'avancement

| Branche | Statut | PR | Remarques |
|---|---|---|---|
| 00 `ci/authz-00-postgres-integration-job` | À faire | | |
| 01 `fix/authz-01-session-registry-baseline` | À faire | | |
| 02 `feat/authz-02-db-schema` | À faire | | |
| 03 `feat/authz-03-permissions-core` | À faire | | |
| 04 `feat/authz-04-account-lifecycle` | À faire | | |
| 05 `feat/authz-05-email-async` | À faire | | |
| 06 `feat/authz-06-api-license-enforcement` | À faire | | |
| 07 `feat/authz-07-admin-user-endpoints` | À faire | | |
| 08 `feat/authz-08-sso-activation` | À faire | | |
| 09 `feat/authz-09-graph-isolation` | À faire | | |
| 10 `chore/authz-10-openapi-contract` | À faire | | |
| 11 `feat/authz-11-front-auth-store` | À faire | | |
| 12 `feat/authz-12-front-guards-menu` | À faire | | |
| 13 `feat/authz-13-front-admin-ui` | À faire | | |
| 14 `feat/authz-14-front-autologout` | À faire | | |
| 15 `test/authz-15-e2e-matrix` | À faire | | |
| 16 `docs/authz-16-docs-adr` | À faire | | |
| 17 `chore/authz-17-drop-is-active` | À faire | | |