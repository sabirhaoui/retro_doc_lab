# 01 - Repository overview

## 1. Structure

The repository contains a containerized application composed of:

- `backend/` — Python FastAPI application
- `frontend/` — Angular frontend
- `input/` — backlog and audit material
- `docker-compose.yml` — local dev stack
- `.env.example` — environment variable template

## 2. Runtime footprint

The stack is defined in `docker-compose.yml` and includes:

- PostgreSQL on port 5432
- Neo4j on ports 7474/7687
- backend on port 8000
- frontend on port 4200

This is a concrete fact from `docker-compose.yml`. The backend is started as a container with POSTGRES_URI, NEO4J_URI, and SECRET_KEY environment variables. See `E-002` and `E-003`.

## 3. Backend architecture

The backend is organized in layers:

- `app/api/` — routers for auth, admin, workspace
- `app/core/` — config, database, security, authorization
- `app/dependencies/` — auth guards
- `app/models/` — Pydantic domain + SQLAlchemy ORM
- `app/repositories/` — database access logic for SQL and graph

This structure matches the description in `README.md` and the code layout in the backend package. See `E-001`, `E-002`, `E-005`, `E-006`, `E-007`.

## 4. Frontend architecture

The frontend uses Angular routing with guard-based access controls:

- `/login` route
- `/setup-account` route
- `/` workspace route behind `authGuard`
- `/admin` route behind `adminGuard`

See `frontend/src/app/app.routes.ts` and `frontend/src/app/guards/auth.guard.ts`. See `E-008` to `E-010`.

## 5. Observed constraints

- Access is enforced in FastAPI via JWT and workspace authorization code.
- Database access is split between relational Postgres (users and workspaces) and graph Neo4j (workspace graph model).
- There is a clear separation between relational user ownership and graph-based knowledge structure.
- The repo is not yet a full enterprise auth implementation; it remains a baseline identity and workspace access foundation.

## 6. Assessment

This is a feature-complete starter platform for a graph knowledge studio, but the backlog’s must-haves for enterprise SSO and strict workspace isolation still exceed the implementation as currently checked in.
