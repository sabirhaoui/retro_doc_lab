# 00 - Inputs and scope

## 1. Repository baseline

- Repository path: `/workspace/twins_project`
- Branch / commit: `NOT VERIFIED` — the directory is not a git checkout (`git -C /workspace/twins_project ...` returned `fatal: not a git repository`).
- Date: 2026-10-01
- Tooling: VS Code workspace, Python, FastAPI, Angular, Docker Compose, Neo4j, PostgreSQL

## 2. Source inventory

### Primary source (most up to date)

- `input/Audit/architecture-audit/` — architecture audit package, target architecture, findings, prioritize, and final report.
- `input/Docs/` — product and domain documentation describing architecture and operational flows.

### Secondary sources

- `README.md` — project overview and V1 scope.
- `TODO.md` — short corrective tasks and remaining bugs.
- `input/Enabler/Epic.md`, `Epic2.md`, `UserStory/EpicUS.md`, `UserStory/Epic2US.md` — backlog requirements, used for obligation coverage, not as the primary technical source.

### Source hierarchy applied

The architecture audit and repo docs are treated as the most current technical evidence. The Enabler backlog is used as a requirement input and is cross-checked against the actual code and audit findings.

## 3. Backlog inventory

### Epic EP01 — Accès sécurisé, identités et espaces de travail

- Source: `input/Enabler/Epic.md`
- Objective: enterprise SSO, sessions, revocation, technical accounts

### Epic EP02 — Administration de la plateforme

- Source: `input/Enabler/Epic2.md`
- Objective: multi-workspace governance and logical isolation

### User stories analyzed

- `US01.1.01` — Se connecter via le SSO d'entreprise
- `US01.1.02` — Gérer l'expiration et la fermeture de session
- `US01.1.03` — Révoquer immédiatement les accès d'un utilisateur
- `US01.1.04` — Gérer les comptes techniques
- `US01.2.01` — Créer et administrer un workspace
- `US01.2.02` — Rattacher des utilisateurs à un workspace
- `US01.2.03` — Sélectionner le contexte de travail actif
- `US01.2.04` — Garantir l'isolation logique entre workspaces

Total: 2 epics and 8 user stories.

## 4. Scope boundaries

In scope:

- enterprise auth and session lifecycle
- workspace management and access control
- logical isolation between workspaces
- baseline application architecture in Angular + FastAPI + Postgres + Neo4j

Out of scope / not yet evidenced:

- real SSO provider integration (OIDC/SAML) details
- production-grade audit retention and SIEM export
- real-time multi-user collaborative editing
- AI features and advanced exports
- migration from local username/password to enterprise SSO

## 5. Decision rules applied

The repository code is treated as the highest source of truth. When the backlog mentions features not yet implemented in code, they are recorded as `PROPOSED` / `GAP`, not as existing implementation.

## 6. Evidence summary

- `README.md` describes the project as a containerized Angular + FastAPI + Postgres + Neo4j platform. See `E-001`.
- The actual backend exposes an auth router and a workspace router. See `E-002`.
- The security configuration still uses a single local JWT secret and environment-based credentials. See `E-003` and `E-004`.
- The backlog requirements for SSO and workspace isolation are not fully covered by the code path; they are treated as architecture gaps. See `E-011` to `E-014` and the mapping in 06.
