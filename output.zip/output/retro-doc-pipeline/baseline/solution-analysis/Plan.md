# Plan de Mise en Œuvre — Refonte Authentification & RBAC Assystan

## Executive Summary
L'objectif est d'évoluer d'un modèle monolithique à accès universel vers une architecture sécurisée multi-tenant basée sur :
1. Le contrôle d'accès basé sur les rôles (RBAC) et l'attribution de licences.
2. Le cloisonnement strict des Workspaces au niveau base de données (Repository layer) et API.
3. L'isolation et le gâte-gardiennage des fonctionnalités (Feature Gating) côté FastAPI et Angular.
4. L'automatisation du provisioning d'instances vierges pour tests E2E/Fonctionnels via des comptes techniques dédiés.

---

## Phases de Déploiement

### Phase 1 : Schéma de Données & Couche Répertoire (Backend Core)
- [ ] Migration Alembic : Ajout des colonnes `licenses` (JSONB) et `permissions` (JSONB) sur la table `users`.
- [ ] Refactoring de `user_repo.py` : suppression des dépendances DTO legacy et support natif de `licenses`/`permissions`.
- [ ] Implémentation du filtrage strict des Workspaces (`workspace_repo.py`).

### Phase 2 : Contrôle d'Accès Backend & Services
- [ ] Mise en place de la dépendance FastAPI `require_license(...)`.
- [ ] Refactoring de `EmailService` : découplage try/catch, fallback logs console pour `setup_link`.
- [ ] Publication de la spécification OpenAPI 3.0 mise à jour.

### Phase 3 : Sécurisation & Router Frontend (Angular)
- [ ] Création du Guard d'activation `licenseGuard`.
- [ ] Intégration du contrôle d'accès sur le routeur et masquage dynamique dans la navigation (IHM).
- [ ] Implémentation du service d'invalidation de session (`AutoLogoutService`).

### Phase 4 : Harnais de Test & Comptes Techniques
- [ ] Script de Seeding SQL (`seed_technical_accounts.sql`) pour instances vierges.
- [ ] Configuration de la fixture Pytest d'intégration (`conftest.py`).
- [ ] Exécution et validation de la matrice de test d'étanchéité et de licences.