# Sécurité

## Contrôles positifs observés

- JWT signé avec algorithme configuré; l’algorithme attendu est passé explicitement au decode.
- Hash de mots de passe par bcrypt/passlib; secret JWT sans valeur par défaut dans Settings.
- Refresh cookie HttpOnly, SameSite=Lax et Secure en production; state OAuth Microsoft en cookie HttpOnly avec vérification d’égalité.
- `get_current_user`, `require_admin`, workspace ACL et niveaux viewer sont présents; plusieurs outils Assystan refont l’ACL.
- L’extraction ZIP vérifie que les chemins restent sous destination.
- CORS utilise des origines explicites dans `main.py`, mais elles sont codées en dur.

## Findings prioritaires

1. Credentials dans les query strings : [ARCH-004](findings/ARCH-004-credentials-in-query.md).
2. URL cible connecteur arbitraire et TLS optionnellement désactivé : [ARCH-005](findings/ARCH-005-ssrf-connectors.md).
3. JWT d’accès encore accepté pour un utilisateur inactif : [ARCH-006](findings/ARCH-006-disabled-user-token.md).
4. `secret_ref` ambigu et consommé comme token : [ARCH-007](findings/ARCH-007-secret-ref-resolution.md).
5. Conversations persistées dans localStorage : [ARCH-012](findings/ARCH-012-chat-localstorage.md).

## Autres observations

- Logout supprime le cookie mais ne révoque pas les JWT déjà émis; refresh vérifie l’état actif, accès non. Durées réelles par défaut: 60 min access, 14 jours refresh, contrairement aux valeurs du README.
- `CORS_ORIGINS` est configuré dans Settings/exemple prod mais `main.py` contient sa propre liste locale. La même origine en production peut rendre CORS non nécessaire; le contrat config reste incohérent.
- Le credential de démonstration documenté/seedé est limité par le code au mode développement; ne pas le traiter comme credential prod sans contre-preuve. Voir [ARCH-015](findings/ARCH-015-dev-seed-credential.md); valeur omise.
- `deploy/ci-fixtures/.env` existe; son contenu n’a pas été lu. Aucun scan de secrets n’a été lancé.

## Limites

Pas de scan SAST/DAST/CVE, d’analyse exhaustive de chaque route ou de test réseau. Les contrôles Caddy/firewall/cloud hors repo ne sont pas vérifiés. Les findings HIGH comportent un contre-check dans leur fiche dédiée.
