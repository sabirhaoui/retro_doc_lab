## [ARCH-014] Les tests d’intégration backend ne sont pas dans le gate CI

### Category
Testing

### Severity
MEDIUM

### Confidence
HIGH sur le YAML; résultats/tests de pipeline non disponibles.

### Evidence
- `E-014` : `azure-pipelines.yml:73,117`; `backend/tests/integration/conftest.py:20-34`.

### Fact
Le job backend du pipeline exécute `pytest tests/unit`; le job frontend exécute Jest avec `--coverage=false`. Le répertoire `backend/tests/integration` existe et son fixture de session requiert un PostgreSQL réel puis skip si indisponible.

### Observation
Les tests d’intégration SQL/repositories ne sont pas inclus dans le gate CI consulté. La couverture est configurée côté Jest mais désactivée explicitement dans la commande pipeline.

### Inference
Les écarts de mapping ORM/migration/SQL, de transaction réelle et de contrats inter-couches peuvent passer le gate sans exercer les tests d’intégration existants.

### Risk & Impact
Régressions data-layer et confiance excessive dans un pipeline vert; l’impact réel dépend de la couverture des tests unitaires.

### Counter-check (Anti-biais)
Le pipeline exécute tout de même les tests unitaires backend et frontend, lint/typecheck/build; certains unit tests couvrent les contrats importants. Aucune couverture réelle n’a été mesurée pendant l’audit.

### Recommendation & Suggested Remediation
Ajouter un service PostgreSQL éphémère à un job CI distinct et exécuter au minimum les tests d’intégration pertinents; conserver l’isolation SAVEPOINT. Publier les rapports de couverture si le seuil est utile au projet.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- P2, particulièrement important avant les modifications ORM/migrations.

### Verification Method
Job CI avec PostgreSQL isolé, exécution `pytest tests/integration`, publication JUnit; preuve que le job échoue sur un test volontairement cassé.