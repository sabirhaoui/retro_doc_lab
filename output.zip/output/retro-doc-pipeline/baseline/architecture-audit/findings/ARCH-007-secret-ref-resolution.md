## [ARCH-007] Le pointeur `secret_ref` est utilisé directement comme token

### Category
Security / Code

### Severity
MEDIUM

### Confidence
HIGH sur l’absence de résolution dans les chemins consultés; MEDIUM sur la valeur réellement stockée en runtime.

### Evidence
- `E-007` : contrat `catalog_schemas.py:50-64`; consommation `agent_context.py:74`, `entity_mappings/service.py:74`; colonne `models/orm/connector.py:39`.

### Fact
Le schéma décrit `secret_ref` comme pointeur de coffre, non secret, et le repository le stocke en chaîne SQL. Les agents et jobs copient cette chaîne directement dans `credentials["token"]`; aucun adaptateur de coffre/décryptage n’a été observé dans le chemin examiné.

### Observation
Si la donnée est un vrai identifiant de coffre (URI/clé), elle est envoyée à l’API ERP comme token. Si la valeur stockée est au contraire le token utilisable, elle est persistée en clair dans PostgreSQL malgré le contrat « pointeur ».

### Inference
Le modèle actuel laisse ambigu le contrôle de secret et peut produire soit une intégration non fonctionnelle, soit une exposition de credential lors d’un accès DB/backup.

### Risk & Impact
Fuite de secrets ERP et confusion entre référence et valeur; difficulté à faire rotation/audit des credentials.

### Counter-check (Anti-biais)
Le champ est renvoyé par l’API sous le nom `secret_ref`, mais cela ne prouve pas l’existence d’un coffre externe. Aucune résolution n’a été trouvée dans les consommateurs inspectés; un sidecar/secret store hors dépôt reste possible.

### Recommendation & Suggested Remediation
Décider explicitement du contrat : soit intégrer un resolver coffre et ne persister que des références, soit renommer la propriété et protéger les valeurs par chiffrement/secret manager. Ne jamais exposer la valeur secrète dans la réponse catalogue; tester un token factice de bout en bout sans secret réel.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Priorité P1 avant production d’identifiants ERP; nature de la valeur stockée à confirmer immédiatement.

### Verification Method
Tracer un credential factice du formulaire jusqu’au client P6/Unifier, vérifier qu’un resolver est appelé et inspecter une sauvegarde de base expurgée.