## [ARCH-015] Credential d’administration de démonstration publié pour le développement

### Category
Security

### Severity
LOW

### Confidence
HIGH — la valeur est définie dans le seed développement et documentée; le rapport ne la reproduit pas.

### Evidence
- `E-027` : `backend/seed_db.py:54-65`, `README.md:278`, `deploy/docker-compose.deploy.yml` configure `APP_ENV=production`.

### Fact
Un credential d’administration de démonstration est présent dans la documentation et dans le chemin seed conditionné à `APP_ENV == development`. La valeur est volontairement omise ici. Le Compose prod fixe `APP_ENV=production`.

### Observation
La valeur publique est utilisable dans un environnement qui exécuterait le seed en mode développement; elle n’est pas activée par le chemin par défaut de l’image prod tel qu’inspecté.

### Inference
Une erreur de configuration d’environnement ou une réutilisation du seed hors du mode prévu pourrait créer un compte connu.

### Risk & Impact
Accès admin à un environnement de développement/staging mal configuré. Aucun accès prod via ce défaut n’a été démontré.

### Counter-check (Anti-biais)
Le seed n’assigne cette valeur qu’en développement; les opérations production définissent `APP_ENV=production` et le script `create-first-admin.sh` passe un secret temporaire. Donc le constat est une hygiène de credential de démo, pas une preuve de credential production actif.

### Recommendation & Suggested Remediation
Retirer le credential publié du README; générer un mot de passe aléatoire au seed local ou demander une variable locale non versionnée. Garder le bootstrap production one-shot, secret, et vérifier l’absence de compte par défaut après release.

### Estimated Effort
S (≤ 2j)

### Priority Score Matrix
- Impact limité au mode développement établi, effort faible : P3.

### Verification Method
Tester seed sous `APP_ENV=development` et `production` avec base jetable; confirmer qu’aucun credential par défaut n’est créé en production. Aucun seed n’a été exécuté pendant l’audit.