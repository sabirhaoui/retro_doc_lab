## [ARCH-003] Import Unifier asynchrone cible localhost en production

### Category
Code

### Severity
HIGH

### Confidence
HIGH — la branche conditionnelle frontend et les environnements consultés sont explicites.

### Evidence
- `E-003` : `frontend/src/app/services/api.service.ts:145,153`; `frontend/src/environments/environment.prod.ts:4`; `frontend/angular.json` ne déclare pas `fileReplacements`.

### Fact
Les méthodes d’import asynchrone et de polling remplacent toute base API relative (`/api`) par `http://localhost:8001`. L’environnement prod fournit une base relative `/api`; aucune substitution Angular prod n’est configurée.

### Observation
L’import synchrone utilise `${base}/v1/...`; le flux asynchrone et le polling utilisent une URL absolue qui dépend de `base.startsWith('http')`.

### Inference
Dans le navigateur de production, ces appels ciblent le loopback de la machine de l’utilisateur, pas le backend déployé. En HTTPS, le protocole HTTP peut aussi être bloqué comme contenu mixte.

### Risk & Impact
L’import ZIP asynchrone et son suivi sont indisponibles pour les utilisateurs de l’interface en production.

### Counter-check (Anti-biais)
Les autres appels Angular construits sur `/api` restent relatifs et peuvent être routés par le proxy externe. Seules les méthodes asynchrones ont cette branche `localhost`; le flux synchrone n’est pas concerné. Le routage Caddy réel n’a pas été inspecté.

### Recommendation & Suggested Remediation
Construire ces deux appels à partir du même base path relatif que les autres routes ou injecter une configuration runtime publique (origin/API path), sans fallback `localhost` dans le bundle prod.

### Estimated Effort
S (≤ 2j)

### Priority Score Matrix
- Fonction de production complètement touchée, correction locale : P1.

### Verification Method
Ajouter un test Angular avec `apiUrl='/api'` qui vérifie que l’URL reste relative; valider l’import et le polling à travers le proxy de staging.