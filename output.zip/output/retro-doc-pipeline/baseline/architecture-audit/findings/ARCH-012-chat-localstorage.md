## [ARCH-012] Historique de chat métier conservé dans localStorage

### Category
Security / Data

### Severity
MEDIUM

### Confidence
HIGH — le store sérialise explicitement toutes les conversations; contenu exact variable selon usage.

### Evidence
- `E-012` : `frontend/src/app/services/chat-store.service.ts:15-17,165`; persistance backend via `ChatLifecycleService`/tables chat.

### Fact
`ChatStoreService` écrit `_conversations()` en JSON dans localStorage. Le service chat appelle également le backend Assystan et les modèles ORM incluent sessions/messages/citations.

### Observation
Le contenu projet, questions/réponses et extraits peut être présent à la fois côté serveur et dans le profil navigateur durable, accessible au JavaScript exécuté sur l’origine.

### Inference
La suppression serveur, la rétention centralisée et l’effacement du navigateur peuvent diverger; un XSS sur l’origine peut lire les conversations locales.

### Risk & Impact
Exposition de données métier sur poste partagé/compromis et non-conformité possible à la politique de rétention ou de confidentialité.

### Counter-check (Anti-biais)
Le token d’accès n’est pas conservé dans localStorage; il reste en mémoire. L’exposition porte sur l’historique local, pas sur le refresh token HttpOnly. Le contenu réel dépend des conversations utilisateurs.

### Recommendation & Suggested Remediation
Arbitrer une source de vérité et une rétention. Préférer l’historique backend déjà existant; si cache local conservé, le limiter/expurger, prévoir suppression explicite et documenter les données stockées.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Données potentiellement sensibles, contrôle applicatif possible : P2.

### Verification Method
Test navigateur vérifiant contenu local après logout/suppression, politique de rétention, absence de payload sensible dans localStorage après migration.