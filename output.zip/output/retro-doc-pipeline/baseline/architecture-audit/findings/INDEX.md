# Index des findings

| ID | Titre | Sévérité | Priorité | Preuve | État |
| --- | --- | ---: | ---: | --- | --- |
| ARCH-001 | Port publié du Nginx de développement incorrect | HIGH | P1 | E-001 | À corriger |
| ARCH-002 | Le proxy de développement retire le préfixe API | HIGH | P1 | E-002 | À corriger |
| ARCH-003 | Import Unifier asynchrone cible localhost en production | HIGH | P1 | E-003 | À corriger |
| ARCH-004 | Identifiants ERP envoyés dans l’URL | HIGH | P1 | E-004 | À corriger |
| ARCH-005 | Destination HTTP contrôlée par l’appelant (SSRF) | HIGH | P1 | E-005, E-021 | À mitiger |
| ARCH-006 | JWT d’un utilisateur désactivé encore accepté | MEDIUM | P1 | E-006 | À corriger |
| ARCH-007 | `secret_ref` consommé sans résolution de coffre | MEDIUM | P1 | E-007 | À clarifier/corriger |
| ARCH-008 | Job d’ingestion déclare un succès sans extraire | HIGH | P1 | E-008 | À corriger |
| ARCH-009 | DDL de démarrage parallèle aux migrations Alembic | MEDIUM | P2 | E-009 | À converger |
| ARCH-010 | Backup de release PostgreSQL sans backup Neo4j observé | HIGH | P1 | E-010 | À confirmer/mettre en place |
| ARCH-011 | Import ZIP et statut confinés au processus API | MEDIUM | P2 | E-011 | À fiabiliser |
| ARCH-012 | Historique chat sensible dupliqué dans localStorage | MEDIUM | P2 | E-012 | À arbitrer |
| ARCH-013 | Documentation annonce CI seule alors que le YAML déploie | MEDIUM | P2 | E-013 | À aligner |
| ARCH-014 | Tests d’intégration absents du gate CI | MEDIUM | P2 | E-014 | À planifier |
| ARCH-015 | Credential admin de démonstration public en développement | LOW | P3 | E-027 | À confirmer/encadrer |

Les niveaux de confiance, faits, inférences, contre-checks, effort et vérification sont dans les fichiers individuels. Aucun finding CRITICAL n’a été établi par l’analyse statique.
