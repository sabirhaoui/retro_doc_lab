## [ARCH-011] Le traitement ZIP Unifier et son statut sont locaux au processus

### Category
Operational / Architecture

### Severity
MEDIUM

### Confidence
HIGH sur l’état processus; MEDIUM sur l’impact prod, car le nombre de réplicas n’est pas spécifié.

### Evidence
- `E-011` : `backend/app/modules/unifier_package/router.py:38,142-153`.

### Fact
L’état des imports est stocké dans `task_status_store`, un dictionnaire Python, et le traitement démarre par un thread daemon après lecture complète du ZIP.

### Observation
Le task_id ne correspond pas à un job Celery/SQL persistant. La tâche et les bytes ZIP sont en mémoire du worker API qui a reçu l’upload.

### Inference
Un redémarrage peut interrompre le job et effacer son état; derrière plusieurs instances, le polling envoyé à une autre instance peut répondre « introuvable ».

### Risk & Impact
Import interrompu ou statut perdu sans possibilité fiable de reprise/support; mémoire backend proportionnelle à la taille du ZIP.

### Counter-check (Anti-biais)
Le Compose de production actuel décrit une seule instance backend, ce qui réduit le cas de polling cross-replica. Cela ne protège pas des redémarrages ni des arrêts forcés; l’import synchrone existe aussi.

### Recommendation & Suggested Remediation
Déplacer l’import vers une tâche durable avec statut SQL/Celery, stocker le ZIP dans un stockage temporaire durable et borner taille/durée; lier le task_id au workspace/utilisateur et autoriser le polling.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Fiabilité d’exploitation moyenne, prérequis au scaling : P2.

### Verification Method
Test de reprise après redémarrage du worker, polling derrière plusieurs instances, limites taille/durée et accès à un task_id d’un autre utilisateur.