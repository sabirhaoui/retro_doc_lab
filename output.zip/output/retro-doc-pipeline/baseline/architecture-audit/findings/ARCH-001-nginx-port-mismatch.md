# [ARCH-001] Port publié du Nginx de développement incorrect

## Category
Infra

## Severity
HIGH

## Confidence
HIGH — le mapping Compose et le `listen` du fichier monté sont explicites.

## Evidence

- `E-001` : `docker-compose.yml:6` mappe `3000:3000`; `nginx/default.conf:2` écoute sur `80`.

## Fact
Le service Nginx de développement publie le port container 3000 alors que sa configuration fournie écoute sur le port 80.

## Observation
Le README présente `localhost:3000` comme point d’entrée de développement. Le service Angular est attendu séparément sur le port 4200.

## Inference
Aucun listener container 3000 n’étant déclaré dans ce Nginx, Docker transmet le trafic du port hôte 3000 vers un port où le serveur ne semble pas écouter.

## Risk & Impact
Le point d’entrée annoncé peut refuser les connexions; l’utilisateur doit contourner Nginx et accéder directement à Angular/backend.

## Counter-check (Anti-biais)
Le Compose monte bien `nginx/default.conf` et aucun autre bloc serveur/listen 3000 n’a été observé dans ce fichier. Le serveur Nginx prod frontend est une autre image/config et ne corrige pas ce service de développement. Le comportement réseau n’a pas été testé.

## Recommendation & Suggested Remediation
Aligner le port publié sur `3000:80` ou faire écouter explicitement le conteneur sur 3000, puis garder une seule convention documentée.

## Estimated Effort
S (≤ 2j)

## Priority Score Matrix

- Impact élevé, effort faible, reproductibilité élevée : P1 quick win.

## Verification Method
Après correction, valider la config Compose puis vérifier `http://localhost:3000/` et les proxys `/api` depuis un navigateur/test HTTP. Aucun test exécuté pendant cet audit.
