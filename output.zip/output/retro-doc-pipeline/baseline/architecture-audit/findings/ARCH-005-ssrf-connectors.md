## [ARCH-005] Les endpoints connecteurs autorisent des destinations HTTP fournies par l’appelant

### Category
Security

### Severity
HIGH

### Confidence
MEDIUM — chemin d’appel démontré; exploitabilité précise dépend du réseau de déploiement et des contrôles externes non inspectés.

### Evidence
- `E-005` : `backend/app/modules/connectors/router.py:304-314,363-403,467-522`; clients HTTP `p6_client.py:184`, `unifier_client.py:172`.

### Fact
Les routes de test et de lecture P6/Unifier sont accessibles à un utilisateur authentifié et acceptent des `base_url` provenant du body ou de query. Les clients appellent ces URL avec `urlopen`; aucun filtrage de destination/réseau privé n’a été trouvé dans le chemin inspecté.

### Observation
Le fallback évite de transmettre les identifiants enregistrés vers une URL différente, mais conserve l’URL fournie par l’utilisateur. Les routes test acceptent aussi `insecure`, qui désactive la vérification TLS dans les clients.

### Inference
Le service peut être utilisé comme proxy HTTP vers des hôtes internes accessibles depuis le conteneur backend, y compris des services non destinés aux utilisateurs de l’application.

### Risk & Impact
Reconnaissance ou accès indirect à des services internes; l’option TLS non vérifiée facilite en plus les attaques d’interception sur des destinations choisies.

### Counter-check (Anti-biais)
Les routes exigent un JWT; le fallback Unifier/P6 ne transmet pas automatiquement les secrets stockés à une URL différente. Ces protections réduisent le risque de vol des credentials catalogue, mais n’empêchent pas les requêtes SSRF avec URL fournie et données fournies par l’appelant. Aucun filtrage réseau Caddy/firewall n’a été vérifié.

### Recommendation & Suggested Remediation
Restreindre les hôtes à une allowlist de connecteurs administrés, valider schéma/port/DNS et bloquer loopback, link-local, metadata et réseaux privés après résolution DNS; désactiver `insecure` hors configuration d’environnement contrôlée; limiter les routes de test aux administrateurs.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Surface réseau sensible, accès authentifié mais exploitable à distance : P1 jusqu’à preuve d’un contrôle réseau externe.

### Verification Method
Tests unitaires de validation URL (IPv4/IPv6, DNS rebinding, redirects, metadata) et test d’intégration réseau avec destinations internes bloquées. Revue de l’egress firewall en staging.