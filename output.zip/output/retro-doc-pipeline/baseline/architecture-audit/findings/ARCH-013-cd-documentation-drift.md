## [ARCH-013] La documentation nie un stage CD réellement présent

### Category
Documentation / DevOps

### Severity
MEDIUM

### Confidence
HIGH — YAML et descriptions README/TODO ont été comparés.

### Evidence
- `E-013` : `azure-pipelines.yml:2,148-156`; `README.md:348`; section CI/CD de `TODO.md`.

### Fact
Le YAML contient un stage `CD` conditionné à une build réussie sur `refs/heads/dev` hors pull request; ce stage construit les images et appelle le script de release en SSH. README et TODO déclarent « pas de CD ».

### Observation
La CI déclenche sur `dev` et `main`; le CD ne cible que les pushes non-PR sur `dev`. Les notes du dépôt décrivent le déploiement comme hors scope.

### Inference
Les opérateurs et reviewers peuvent ne pas anticiper qu’une fusion/push sur `dev` déclenche un déploiement automatique vers l’environnement `pprod` défini dans la config runtime.

### Risk & Impact
Mauvaise compréhension du contrôle de release, des approvals et du risque opérationnel. Le pipeline n’exprime pas d’approbation d’environnement dans le YAML consulté.

### Counter-check (Anti-biais)
Le CD est restreint à `dev` et exclut les PR; une gate humaine Azure DevOps externe peut exister mais n’est pas vérifiable dans le repository. Le déploiement n’est pas déclenché sur `main` par la condition lue.

### Recommendation & Suggested Remediation
Aligner README/TODO avec le stage conditionnel et documenter l’environnement, gates Azure, rollback et propriétaire. Si la politique voulue est « pas de CD », désactiver le stage via le processus autorisé et mettre à jour la documentation.

### Estimated Effort
S (≤ 2j)

### Priority Score Matrix
- Quick win de gouvernance; P2.

### Verification Method
Comparer le YAML au pipeline Azure actif et à ses Environment approvals; vérifier le comportement sur push `dev` sans exécuter un déploiement.