## [ARCH-010] La procédure de release sauvegarde PostgreSQL mais pas Neo4j

### Category
Operational

### Severity
HIGH

### Confidence
MEDIUM — aucun backup graphe n’a été trouvé dans les scripts examinés; des procédures externes peuvent exister.

### Evidence
- `E-010` : `deploy/scripts/apply-release.sh:139-144`; volume Neo4j dans `deploy/docker-compose.deploy.yml:26`.

### Fact
Avant Alembic, la release produit un `pg_dump` compressé. Le Compose monte les données Neo4j dans un dossier persistant. Les scripts de déploiement consultés ne déclenchent pas d’export/snapshot Neo4j.

### Observation
Neo4j porte les graphes Studio et le modèle canonique; ils ne sont pas reconstruits intégralement par la migration PostgreSQL.

### Inference
Le backup SQL ne permet pas de restaurer seul le contenu métier principal des graphes après corruption ou perte du volume.

### Risk & Impact
Perte de données graphes ou restauration incohérente entre metadata workspace SQL et graphes Neo4j.

### Counter-check (Anti-biais)
La persistance sur volume et l’absence de port hôte en prod protègent contre certains incidents, mais ne constituent pas un backup. L’existence de snapshots disque ou d’un backup opérateur hors dépôt n’a pas pu être vérifiée.

### Recommendation & Suggested Remediation
Documenter le propriétaire et la fréquence des backups Neo4j; intégrer un snapshot cohérent dans le plan de release/DR ou référencer clairement le système externe, avec test périodique de restauration et rétention.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Impact potentiel élevé sur données non régénérables; P1 sous réserve de confirmer le dispositif hors repo.

### Verification Method
Produire un export/snapshot d’une instance de staging, restaurer dans un Neo4j isolé puis vérifier contraintes, workspaces et relations; contrôler le RPO/RTO.