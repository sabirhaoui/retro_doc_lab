## [ARCH-004] Identifiants P6/Unifier transportés dans des URL

### Category
Security

### Severity
HIGH

### Confidence
HIGH — le client Angular ajoute explicitement mots de passe et tokens à `HttpParams`; les routes correspondantes les lisent en query.

### Evidence
- `E-004` : `frontend/src/app/services/api.service.ts:84-116`; `backend/app/modules/connectors/router.py:363-403,512-522`.

### Fact
Les méthodes GET de découverte de projets/BP construisent des paramètres `token`, `username` et `password`. Les routes FastAPI les déclarent en `Query`.

### Observation
Une query string est disponible dans l’URL côté navigateur et peut être copiée dans des journaux d’accès proxy, traces/APM, captures réseau et diagnostics. Le token P6 documenté côté client est un identifiant de session.

### Inference
Des identifiants ERP peuvent survivre au-delà de la requête dans des systèmes de journalisation ou être partagés involontairement.

### Risk & Impact
Compromission de comptes de service ou d’accès ERP, particulièrement si URL/access logs sont conservés ou accessibles à davantage d’opérateurs.

### Counter-check (Anti-biais)
Les endpoints de test de connexion utilisent POST; les routes de lecture des projets/BP restent des GET avec query credentials. Les endpoints requièrent un utilisateur authentifié, ce qui ne supprime pas l’exposition dans les URL.

### Recommendation & Suggested Remediation
Ne jamais placer mot de passe/token en query. Utiliser POST avec body pour les appels ponctuels, ou référencer des identifiants serveur sans les renvoyer au client; expurger les champs de logs et renouveler les secrets déjà exposés dans les URL.

### Estimated Effort
S (≤ 2j)

### Priority Score Matrix
- Risque de fuite de credentials, faible effort de correction : P1.

### Verification Method
Tests HTTP vérifiant l’absence de credentials dans l’URL; vérifier les journaux proxy/APM après migration et remplacer les secrets potentiellement exposés.