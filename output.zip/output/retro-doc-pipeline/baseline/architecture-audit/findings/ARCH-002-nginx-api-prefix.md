# [ARCH-002] Le proxy de développement retire le préfixe API

## Category
Infra

## Severity
HIGH

## Confidence
HIGH — la sémantique Nginx `proxy_pass` avec URI est déterministe et le préfixe FastAPI est déclaré.

## Evidence

- `E-002` : `nginx/default.conf:5-6`, `backend/app/modules/shared/openapi.py:11`, `frontend/src/environments/environment.ts:4`.

## Fact
L’UI utilise une base `/api`; FastAPI déclare `API_PREFIX = /api/v1`. Le proxy local a `location /api/` et `proxy_pass http://backend:8000/` avec une URI de remplacement `/`.

## Observation
Avec cette forme, Nginx remplace le préfixe correspondant `/api/` par `/` lors du proxy : une requête `/api/v1/...` est transmise sous `/v1/...`, alors que l’application expose `/api/v1/...`.

## Inference
Les appels passant par le Nginx du Compose local ne correspondent pas aux routes FastAPI. Le proxy Angular de développement vers le port hôte backend est un chemin séparé et ne prouve pas que Nginx fonctionne.

## Risk & Impact
Authentification, API Studio et appels métier peuvent échouer via l’URL Nginx documentée; le défaut peut être confondu avec une panne de route backend.

## Counter-check (Anti-biais)
Le `proxy.conf.json` Angular cible directement le backend et préserve le chemin `/api`; ce chemin peut fonctionner sans le Nginx du Compose. Le point d’entrée prod déclaré est un Caddy externe non fourni, donc ce finding est circonscrit au Nginx local.

## Recommendation & Suggested Remediation
Choisir une seule convention : préserver l’URI avec `proxy_pass` sans suffixe `/`, ou configurer explicitement le backend pour le chemin réécrit. Ajouter un test de contrat proxy→route.

## Estimated Effort
S (≤ 2j)

## Priority Score Matrix

- Impact élevé sur tous les appels passant par ce proxy, effort faible : P1.

## Verification Method
Tester une requête connue `/api/v1/auth/...` à travers Nginx et confirmer le chemin reçu par FastAPI. À exécuter après correction.
