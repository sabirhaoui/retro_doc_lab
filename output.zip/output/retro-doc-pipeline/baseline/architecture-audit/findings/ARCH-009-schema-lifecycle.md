## [ARCH-009] DDL au démarrage concurrent des migrations Alembic

### Category
Architecture / Operational

### Severity
MEDIUM

### Confidence
HIGH — deux voies de modification du schéma figurent dans le parcours normal.

### Evidence
- `E-009` : `backend/app/core/database.py:15-38`; `backend/app/main.py:68-72`; `deploy/scripts/apply-release.sh:144`.

### Fact
Le startup appelle `Base.metadata.create_all`, ajoute manuellement les colonnes manquantes puis supprime la contrainte `uq_user_dashboard_name`. Le script de release applique aussi `alembic upgrade head`.

### Observation
Alembic versionne une partie des évolutions; la réparation DDL de startup n’est pas représentée dans la table de révision et peut transformer le schéma à chaque démarrage.

### Inference
Les environnements peuvent diverger de l’historique Alembic; une release ne décrit pas à elle seule toutes les mutations possibles du schéma.

### Risk & Impact
Dérive de schéma, difficulté de rollback et autogenerate trompeur; DDL concurrent si plusieurs instances démarrent ensemble.

### Counter-check (Anti-biais)
Le code est explicitement présenté comme pont transitoire `create_all → alembic`; les opérations sont idempotentes/additives sauf une suppression ciblée de contrainte. Le déploiement applique Alembic avant les services.

### Recommendation & Suggested Remediation
Terminer la transition : faire porter toute évolution par Alembic; transformer les réparations startup en migration/commande opératoire versionnée et retirer `ensure_schema()` après vérification des bases existantes.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- Risque de dérive modéré, migration progressive possible : P2.

### Verification Method
Comparer `alembic current/head` et metadata sur copie de DB; tester upgrade depuis baseline et depuis schéma de production anonymisé, puis vérifier qu’un démarrage API ne produit aucun DDL.