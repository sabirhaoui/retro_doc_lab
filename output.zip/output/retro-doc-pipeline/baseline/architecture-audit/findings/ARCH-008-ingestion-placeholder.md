## [ARCH-008] Le job d’ingestion marque succès sans extraire de données

### Category
Domain / Operational

### Severity
HIGH

### Confidence
HIGH — le corps de la tâche décrit lui-même le placeholder.

### Evidence
- `E-008` : `backend/app/modules/connectors/tasks.py:29-52`; dispatch dans `connectors/service.py`; annulation `service.py:123-155`.

### Fact
`run_ingestion_job` dort deux secondes, fixe `records=0`, marque le job SUCCESS et persiste un payload `source=placeholder`; la docstring qualifie la tâche de placeholder. Les clients P6/Unifier existent ailleurs mais cette tâche ne les appelle pas.

### Observation
L’API expose création et statut de job, et le contrat annonce l’envoi à Celery. Le statut terminal donne une apparence de succès alors qu’aucune extraction n’a eu lieu. `cancel_job` écrit CANCELLED en base sans révoquer le message Celery ni faire vérifier l’état par le worker.

### Inference
Les consommateurs UI/monitoring peuvent traiter un snapshot vide comme une ingestion réelle; une annulation concurrente peut être écrasée ensuite par SUCCESS.

### Risk & Impact
Données métier absentes ou trompeuses et incapacité à interrompre un job réellement lancé.

### Counter-check (Anti-biais)
Les endpoints directs de test/liste P6 et Unifier sont implémentés et peuvent fonctionner indépendamment; le finding porte sur le pipeline `jobs` Celery. Le placeholder est explicitement documenté dans la tâche.

### Recommendation & Suggested Remediation
Ne pas renvoyer SUCCESS tant qu’un adaptateur registry n’a pas réalisé l’extraction. Tant que le pipeline est incomplet, répondre `unsupported`/`not_implemented` ou marquer `FAILED`. Implémenter révocation/checkpoint de cancellation avec transitions de statut atomiques.

### Estimated Effort
M (≤ 2 sem.)

### Priority Score Matrix
- La fonctionnalité annoncée n’est pas réalisée et peut corrompre la lecture métier : P1.

### Verification Method
Test tâche avec connecteur simulé : records/snapshot issus du connecteur, échec explicite si absent, annulation non écrasée; test d’intégration worker/DB isolé.