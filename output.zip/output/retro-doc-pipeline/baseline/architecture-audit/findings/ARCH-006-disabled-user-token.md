## [ARCH-006] Un JWT d’accès reste accepté après désactivation du compte

### Category
Security

### Severity
MEDIUM

### Confidence
HIGH — la dépendance d’authentification est explicite.

### Evidence
- `E-006` : `backend/app/modules/identity/dependencies.py:24-43`; contrôles actifs login/refresh dans `identity/service.py:50-56,92-100`.

### Fact
`get_current_user` valide le JWT, charge l’utilisateur puis le retourne si la ligne existe; il ne vérifie pas `user.is_active`. Le login et le refresh vérifient ce champ. Le JWT d’accès a une durée par défaut de 60 minutes.

### Observation
Un administrateur peut désactiver un compte; les nouveaux login/refresh sont bloqués mais la dépendance des routes protégées accepte encore un access token non expiré de ce compte.

### Inference
La révocation d’accès par désactivation n’est pas immédiate et dépend de l’expiration du token ou de la suppression de l’utilisateur.

### Risk & Impact
Fenêtre d’accès résiduelle après révocation, pouvant permettre lecture ou mutation dans les workspaces autorisés.

### Counter-check (Anti-biais)
Le refresh refuse les comptes inactifs et le token a une expiration finie; l’exposition est donc bornée par sa durée (60 min par défaut), pas illimitée. Cela ne remplace pas le contrôle sur chaque requête.

### Recommendation & Suggested Remediation
Vérifier `is_active` dans `get_current_user` avant de retourner l’utilisateur; ajouter un test couvrant une désactivation après émission de token. Si révocation instantanée à grande échelle est requise, introduire un mécanisme de version/révocation adapté.

### Estimated Effort
S (≤ 2j)

### Priority Score Matrix
- Effort faible et scénario de révocation fréquent : P1, sans preuve d’exploitation active.

### Verification Method
Test unitaire/d’intégration : obtenir un JWT actif, désactiver l’utilisateur en DB, appeler une route protégée et attendre 401.