# Analyse des causes racines

## Proxy d’API
**Symptôme :** entrée Nginx dev incompatible avec la topologie/documentation.  
**Cause technique :** port mapping différent du port `listen`; `proxy_pass` réécrit `/api`.  
**Cause architecturale :** contrats de proxy et préfixes API configurés séparément sans test de bout en bout.  
**Conséquence :** UI et API peuvent fonctionner en accès direct mais échouer derrière l’entrée annoncée.  
**Remédiation :** centraliser le contrat d’URL et tester routes réelles à travers le proxy. (ARCH-001/002)

## Secrets connecteurs
**Symptôme :** credentials en URL et référence de secret ambiguë.  
**Cause technique :** API accepte paramètres secrets en GET; le consommateur copie `secret_ref` dans `token`.  
**Cause architecturale :** absence d’adaptateur/port de résolution secret et séparation insuffisante entre configuration UI et credential serveur.  
**Risque :** journaux URL et stockage secret incertain.  
**Remédiation :** faire transiter une référence opaque côté serveur, resolver dédié, secrets hors URL, allowlist egress. (ARCH-004/005/007)

## Réalisation d’ingestion
**Symptôme :** statut SUCCESS avec zéro donnée.  
**Cause technique :** task exécute un stub plutôt qu’un adaptateur registry.  
**Cause architecturale :** contrat de job exposé avant branchement de la capacité réelle; statut n’exprime pas `not implemented`.  
**Risque :** snapshots trompeurs.  
**Remédiation :** état explicite jusqu’à une extraction réelle, puis tests contrat/connecteur et idempotence. (ARCH-008)

## Évolution du schéma
**Symptôme :** modifications SQL possibles sans révision.  
**Cause technique :** `ensure_schema` au startup en plus d’Alembic.  
**Cause architecturale :** transition de bootstrap non clôturée.  
**Risque :** rollback et reconstruction d’environnement incertains.  
**Remédiation :** migration scriptée, audit baseline, retrait startup DDL. (ARCH-009)

## Cohérence documentaire
**Symptôme :** README/TODO décrivent CI seule et des durées d’auth différentes.  
**Cause :** docs métier/opérationnelles mises à jour indépendamment des manifests/code.  
**Risque :** décisions de sécurité/release prises sur une représentation obsolète.  
**Remédiation :** propriétaire doc par domaine et vérifications de liens/config en CI. (ARCH-013, 18-documentation-gaps.md)
