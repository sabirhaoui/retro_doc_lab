# Executive Summary

## System Overview

**FACT** — Plateforme Angular 22 + FastAPI/Python 3.11, Neo4j, PostgreSQL, Redis/Celery, Nginx et Azure Pipelines. Le backend est un monolithe modulaire; le frontend est servi en dev hors Compose et en production par une image Nginx statique. Voir [architecture actuelle](03-current-architecture.md).

## Current Architecture

**OBSERVATION** — Deux modèles Neo4j Studio coexistent; PostgreSQL gère les comptes/ACL, catalogues et états, Redis sert à Celery. Assystan route vers des agents LLM/outils et interroge graphe ou systèmes ERP en direct. L’import ZIP Unifier a un chemin parallèle en mémoire/thread.

## Main Strengths

- Frontières de modules lisibles, couches route/service/repository présentes.
- ACL workspace et rôles, refresh cookie HttpOnly, provider LLM interchangeable.
- Retrieval avec citations; import ZIP protège les chemins d’extraction.
- Studio v2 charge l’arbre par racines/expansion et sépare plusieurs services d’état testables.
- Pipeline CI vérifie backend, frontend et configuration Compose; script release prévoit migrations et backup PostgreSQL.

## Main Risks / Critical Findings

Aucun finding CRITICAL n’a été prouvé. Quatre risques HIGH/P1 sont à traiter d’abord : credentials ERP en query URL ([ARCH-004](findings/ARCH-004-credentials-in-query.md)), endpoints connecteurs permettant des destinations caller-supplied ([ARCH-005](findings/ARCH-005-ssrf-connectors.md)), proxy/import de production mal configurés ([ARCH-002](findings/ARCH-002-nginx-api-prefix.md), [ARCH-003](findings/ARCH-003-unifier-import-localhost.md)) et job d’ingestion qui annonce succès avec un snapshot vide ([ARCH-008](findings/ARCH-008-ingestion-placeholder.md)).

La configuration Nginx dev a également un port publié différent de son listener ([ARCH-001](findings/ARCH-001-nginx-port-mismatch.md)). Le backup Neo4j n’est pas visible dans les scripts examinés ([ARCH-010](findings/ARCH-010-neo4j-backup.md)); la couverture d’un dispositif Ops externe reste à confirmer.

## Security

Contrôles positifs : bcrypt, JWT algorithme explicite, workspace ACL, cookie refresh HttpOnly/SameSite, validation path ZIP. Risques à corriger : query secrets, SSRF/egress, user inactif avec access token non expiré, secret_ref sans résolution prouvée, historique chat local. Aucun scan CVE/SAST/DAST n’a été exécuté.

## Quality & Testing

Les suites unitaires et d’intégration existent; CI n’exécute que les unit tests backend et désactive coverage Jest. Aucun test/build/lint n’a été lancé pendant cet audit. Les rapports détaillent les limites et contrôles requis.

## DevOps & Operations

Le YAML contient un CD conditionnel sur `dev` malgré les déclarations README/TODO « pas de CD ». Images/dependencies partiellement mobiles/non verrouillées; prod suppose un Caddy externe non versionné. `/health` n’est pas une readiness DB.

## Target Architecture

Garder monolithe modulaire et storages actuels; renforcer ports secrets/ERP/queue, rendre jobs durables, retirer DDL startup après migration Alembic et choisir un plan de fin Studio v1. Aucune réécriture massive recommandée.

## Recommended Migration Sequence

1. P1 sécurité/proxy/import; 2. secrets et backup Neo4j; 3. ingestion et async durable; 4. migrations/docs/tests d’intégration; 5. readiness, observabilité et supply chain. Roadmap détaillée : [21-migration-roadmap.md](21-migration-roadmap.md), priorités : [22-prioritization.md](22-prioritization.md).

## Audit Limitations

Analyse statique; Git branch/commit, tests, build, scans, services réels, Caddy et backups hors dépôt non vérifiés. Voir [scope](00-scope-and-environment.md), [ledger](evidence/ledger.md) et [journal](evidence/commands.md).
