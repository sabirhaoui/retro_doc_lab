# Architecture Audit — Final Report

## 1. Executive Summary

La plateforme est un monolithe modulaire Angular/FastAPI avec stores SQL + graphe et workers Celery. Les risques P1 principaux sont les credentials ERP dans les URL, l’egress connecteurs non allowlisté, la configuration proxy/import, et l’ingestion placeholder. Aucun CRITICAL n’est prouvé par une analyse statique. Voir [synthèse exécutive](00-executive-summary.md).

## 2. Current Architecture

Les faits et diagrammes sont dans [03-current-architecture.md](03-current-architecture.md) et `diagrams/`. PostgreSQL porte comptes/ACL et état applicatif; Neo4j porte les modèles v1/v2/canonique; Redis broker/backend Celery. Caddy prod est externe au dépôt.

## 3. Architecture Strengths

- Routeurs/services/repositories identifiables et exceptions centralisées.
- ACL workspace, JWT et cookie refresh HttpOnly; factory LLM OpenAI/Mock.
- Studio v2 paginé/lazy, façade UI qui délègue, tests unitaires/intégration présents.
- Déploiement prod isolant les datastores des ports hôte et script de release avec backup SQL avant migration.

## 4. Critical Risks

Aucun finding CRITICAL retenu. Les HIGH/P1 et leur preuve sont listés dans [findings/INDEX.md](findings/INDEX.md). Priorités : credentials en query, SSRF via base_url, proxy/import de production, ingestion qui annonce un faux succès, backup graphe à confirmer.

## 5. Findings

Quinze fiches détaillent fait, observation, inférence, risque, recommandation, contre-check pour HIGH/CRITICAL, effort et méthode de vérification. Le [registre E-001…E-027](evidence/ledger.md) est la source de preuve; la priorisation est dans [22-prioritization.md](22-prioritization.md).

## 6. Security

Les principaux problèmes constatés sont query credentials, destinations sortantes pilotées par l’appelant, contrôle `is_active` absent sur access token existant, contrat `secret_ref` non résolu dans les consommateurs et conversation locale. Les contrôles et limites sont dans [10-security.md](10-security.md). Aucun secret de `.env` n’a été lu ou écrit.

## 7. Quality & Testing

Configs Ruff/Mypy/ESLint/Jest et tests présents. Le pipeline ne joue pas les tests d’intégration PostgreSQL; Jest coverage est désactivée dans la commande CI. Tests/build/lint non exécutés; aucune conclusion sur leur état actuel n’est formulée.

## 8. DevOps

Le pipeline fait un CD conditionnel vers le chemin `dev`, contrairement au README. Le build CI et Docker prod utilisent Node 24 et 22 respectivement. Le Compose prod attend un proxy externe Caddy et ne montre pas de backup Neo4j.

## 9. Technical Debt

Migration Studio v1/v2, schéma DDL startup en parallèle d’Alembic, ingestion stub, état thread/dict import, references `secret_ref` et docs obsolètes. Causes dans [19-root-cause-analysis.md](19-root-cause-analysis.md).

## 10. Target Architecture

Renforcer ports/adapters au sein du monolithe, source de vérité PostgreSQL pour état des jobs, adaptateurs résolveur secret/ERP, tests proxy et observabilité. Détails : [20-target-architecture.md](20-target-architecture.md).

## 11. Migration Roadmap

Cinq phases progressives : stabilisation P1, secrets/backups, async, schéma/docs/tests, puis observabilité/supply chain. Voir [21-migration-roadmap.md](21-migration-roadmap.md).

## 12. Recommended Next Actions

1. Enlever secrets des query strings et restreindre egress connecteurs.
2. Corriger Nginx/API prefix et base URL import production, avec tests contrat.
3. Bloquer faux succès ingestion; lier annulation à la tâche.
4. Confirmer backup Neo4j; définir resolver de secret et appliquer `is_active` aux access tokens.
5. Ajouter job CI PostgreSQL pour tests d’intégration, puis retirer DDL startup.

## 13. Audit Limitations

Audit statique au 2026-10-01; branche/commit et état Git initial inconnus. Pas de tests, builds, migrations, scans ou accès système externe. Caddy, gates Azure et backups hors repo restent à confirmer. Les commandes non exécutées sont listées dans [evidence/commands.md](evidence/commands.md); avancement dans [STATE.md](STATE.md).
