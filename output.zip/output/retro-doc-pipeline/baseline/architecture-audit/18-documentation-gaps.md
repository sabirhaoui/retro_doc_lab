# Écarts documentation / réalité

| Élément | Déclaration | Réalité observée | Écart / impact |
|---|---|---|---|
| Nginx dev | README annonce `localhost:3000` | Compose mappe 3000→3000, config écoute 80; le proxy `/api/` réécrit aussi le préfixe | Entrée locale probablement non fonctionnelle; ARCH-001/002. |
| API proxy | README représente `/api` vers backend | Le backend expose `/api/v1`; Nginx local transmet `/v1` avec sa config actuelle | Routes non concordantes; ARCH-002. |
| Import async | UI expose progression de tâche | Frontend force `localhost:8001` quand `apiUrl` vaut `/api`; build Angular n’a pas fileReplacement | Import utilisateur prod pointe son propre loopback; ARCH-003. |
| Secrets connecteurs | Schema indique pointer coffre | Agents utilisent `secret_ref` directement comme token | Contrat non implémenté de façon cohérente; ARCH-007. |
| Ingestion | README présente ingestion P6/Unifier/Celery | La tâche connecteurs marque succès avec snapshot placeholder vide | Capability surestimée; ARCH-008. |
| Auth durées | README décrit access 30 min, refresh 7 jours | Defaults code/prod template: 60 min et 14 jours | Durées et menaces mal évaluées; E-006. |
| CI/CD | README et TODO disent « pas de CD » | YAML contient CD conditionnel sur `dev` hors PR | Risque de gouvernance/release mal compris; ARCH-013. |
| Expérimentation | Doc technique cite trois tables/runs et agents avancés | ORM examiné déclare `ExperimentationJourney` et `Experimentation`; phases actuelles différentes | Conception/API ou état des docs obsolète; vérifier le reste avant migration. |
| Store Studio | README nomme `WorkspaceStateV2Service`/fichier versionné | Source définit `WorkspaceStateService` sous `studio/services` | Références et navigation code trompeuses. |
| Redis | README mentionne cache | Usage applicatif observé : broker et backend de résultats Celery; cache non établi | Rôle du datastore à documenter correctement. |
| Environnement frontend | Build prod cite environment.prod | Angular config consultée ne déclare pas de remplacement; imports prennent `environment.ts` | La séparation dev/prod est déclarative mais pas câblée dans ce build. |

## Limites
Comparaison basée sur README, TODO, docs Assystan/Expérimentation sélectionnées, manifests, configs et code consulté; toutes les pages de `doc/` n’ont pas été relues. Écarts prioritaires liés au code : [ARCH-001 à ARCH-004](findings/INDEX.md).