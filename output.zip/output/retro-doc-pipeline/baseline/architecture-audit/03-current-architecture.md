# Architecture actuelle

## Synthèse
**OBSERVATION** — Monolithe FastAPI modulaire, UI Angular autonome, workers Celery réutilisant l’image backend, PostgreSQL + Neo4j, Redis pour Celery. UI appelle `/api/v1` et Studio `/api/v2`.

**FACT** — PostgreSQL porte identités/ACL, catalogues, exécutions et historiques; Neo4j héberge deux modèles Studio distincts et l’ontologie canonique. Le retrieval préfère v2 et retombe sur le dépôt v1. Le package de configuration Unifier est aussi construit en NetworkX en mémoire avant sync Studio v2.

## Topologies
- **Développement :** Compose démarre Nginx, API, DB, Redis, Celery, Flower et Mailpit; frontend container commenté, `ng serve` attendu sur l’hôte. Les ports et chemin proxy Nginx ne sont pas alignés (ARCH-001/002).
- **Production :** Compose démarre Postgres, Neo4j, Redis, API, worker, Beat et image frontend; services applicatifs publiés sur loopback. Le commentaire et les routes OAuth attendent un Caddy externe non inclus.
- **Proxy frontend prod :** Nginx sert assets/fallback Angular; l’API est supposée routée en amont par Caddy.

## Diagrammes actuels
- [Architecture actuelle](diagrams/current-architecture.mmd)
- [Dépendances](diagrams/dependency-flow.mmd)
- [Graphes](diagrams/graph-flow.mmd)
- [Async](diagrams/async-flow.mmd)
- [Auth](diagrams/auth-flow.mmd)
- [IA/RAG](diagrams/ai-rag-flow.mmd)

**LIMITATION** — le Caddy/cloud runtime, le nombre de replicas prod et les sorties P6/Unifier n’ont pas été inspectés; ils ne sont pas présentés comme faits.