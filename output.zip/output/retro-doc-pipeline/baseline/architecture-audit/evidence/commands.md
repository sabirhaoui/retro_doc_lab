# Journal des commandes / contrôles

Le plan v3 interdit les effets de bord hors audit et recommande de ne lancer tests/outils qu’en environnement isolé. Aucun processus backend/frontend, conteneur, migration ou accès réseau n’a été lancé.

| Contrôle | État | Raison / résultat réel |
| --- | --- | --- |
| `git status --short` | NOT EXECUTED | Une tentative depuis le terminal actif a retourné « not a git repository »; le cwd n’était pas le dépôt. |
| `git branch --show-current` | NOT EXECUTED | L’appel terminal correspondant a été ignoré; aucune branche n’est consignée. |
| `git log -1 --oneline` | NOT EXECUTED | L’appel terminal correspondant a été ignoré; aucun commit n’est consigné. |
| `tree` / inventaire CLI | NOT EXECUTED | Remplacé par les outils de recherche/listing du workspace. |
| `ruff`, `mypy`, `pytest`, `npm test`, `ng build` | NOT EXECUTED | Audit statique uniquement; les tests d’intégration requièrent PostgreSQL et aucun résultat de test n’est revendiqué. |
| `docker compose config`, build d’image, migrations | NOT EXECUTED | Pas d’exécution runtime/infra demandée ou nécessaire à la lecture statique. |
| Scan dépendances/secrets/CVE, benchmark | NOT EXECUTED | Aucun outil de scan ou environnement isolé disponible dans cette phase. Aucun contenu `.env` n’a été lu. |

Aucune sortie de commande inexistante n’est simulée. Les constats proviennent des sources listées dans `ledger.md`.
