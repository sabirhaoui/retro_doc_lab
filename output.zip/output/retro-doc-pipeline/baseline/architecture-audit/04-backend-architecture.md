# Architecture backend

## Couches constatées
**FACT** — `main.py` enregistre les routeurs de `app.modules.*`; les routeurs injectent dépendances FastAPI/session SQL et délèguent généralement aux services. Les services portent des règles de cas d’usage et utilisent repositories, ORM, autres modules et adaptateurs. Les repositories encapsulent SQL/Cypher de façon non uniforme.

**OBSERVATION** — Il s’agit d’un monolithe modulaire en couches, pas d’un hexagone strict : plusieurs services importent directement d’autres modules métier et le domaine dépend souvent des modèles ORM/contrats applicatifs.

## Responsabilités principales
- `identity`: JWT, Microsoft OAuth, roles et ACL workspace.
- `studio` / `studio_v2`: workspace et graphe; stockages Neo4j v1/v2 distincts.
- `connectors`: catalogue, credentials, clients P6/Unifier et jobs d’ingestion.
- `assystan`: orchestrateur, routeur sémantique, registre/agents, lifecycle et tools.
- `retrieval`: recherche graphe, ACL et citations; v2 puis fallback v1.
- `twin_builders`, `quality`, `diff`, `entity_mappings`, `twin_canonical`, `twin_health`: construction, gate, comparaison, mappings, modèle et snapshots.
- `alerts`, `schedule_snapshots`, `dashboards`, `experimentation`, `packages`, `document_graph`, `unifier_package`: capacités métier et intégration.
- `shared`: settings, exceptions, schémas, logging et middleware.

## Couplages et état global
**FACT** — `diff` consomme `entity_mappings`; builders appellent quality; Assystan compose retrieval/connecteurs/alerts/dashboards; import Unifier synchronise Studio v2 et réconcilie le canonique. **OBSERVATION** — ces imports transverses sont dans le monolithe et ne passent pas toujours par API publiques dédiées.

`assystan_orchestrator`, drivers Neo4j, `graph_service` NetworkX et task status Unifier sont des singletons/états processus. Le startup API exécute schéma + synchronisation/réparation workspace/catalogue.

## Risques et recommandations
- Documenter les APIs publiques des modules et limiter les imports internes.
- Garder la migration Studio v1/v2 observable et avec un critère de retrait.
- Déplacer effets DDL/réparation hors startup une fois le pont Alembic fermé.
- Rendre les tâches externes durables et injecter les ports providers/credentials.
- Ne pas découper en microservices sans mesure de charge/besoin d’isolement.

Findings associés : ARCH-008, ARCH-009, ARCH-011; modèle des dépendances : [diagramme](diagrams/dependency-flow.mmd).