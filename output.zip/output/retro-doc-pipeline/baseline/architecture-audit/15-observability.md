# Observabilité

## Capacités constatées

- `CorrelationIdMiddleware` reprend/génère `X-Correlation-ID`, le lie au contexte structlog et le retourne dans la réponse.
- Logging structuré et handlers d’exceptions typées sont configurés dans `main.py`.
- `/health` existe; le script deploy le sonde. Son corps retourne un succès fixe et ne teste pas DB/Neo4j/Redis.
- Celery Flower est présent dans le Compose de développement; il n’est pas dans le Compose production consulté.
- Les tâches journalisent des débuts/fins/erreurs; l’état des jobs d’ingestion est stocké SQL. L’import Unifier utilise une map mémoire.

## Gaps

Aucun système métriques/traces/APM, error tracker, endpoint readiness dépendances ou alertes SLO n’a été identifié dans le dépôt analysé. Les tokens/credentials ne doivent pas figurer dans logs; un audit complet des payloads loggés n’a pas été effectué. Les traces Assystan de réponse ne constituent pas à elles seules une télémétrie agrégée.

## Recommandations

- Distinguer liveness et readiness et vérifier au minimum Postgres/Neo4j/broker selon rôle du service.
- Propager correlation ID dans les headers clients sortants, tâches Celery et logs de job.
- Émettre métriques de durée/échec/retry/queue depth, latence provider LLM, appels P6/Unifier et coût/token sans contenu sensible.
- Ajouter alertes de backlog, jobs dépassant leur délai, erreurs externes et résultat de backup.

Le constat de health fixe est référencé par `E-015`; aucun service d’observabilité externe n’a été interrogé.
