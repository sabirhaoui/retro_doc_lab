# Architecture cible réaliste

## Principes
Conserver le monolithe modulaire FastAPI et Angular; renforcer les contrats et l’exploitation avant d’extraire des services. PostgreSQL reste la source d’autorité pour identité, ACL, catalogues, jobs/historiques; Neo4j porte les graphes et versions canoniques; Redis reste broker/résultats Celery tant qu’un besoin cache mesuré n’existe pas.

## Backend cible
- HTTP : routes minces, validations et auth; un middleware commun pour correlation/caching; contrat API publié et proxifié sans réécriture implicite.
- Application : services métier orchestrent ports explicites (credential resolver, graph store, ERP, queue).
- Domain : règles métier indépendantes HTTP/SQL, modèles canoniques stabilisés; DTO d’API distincts des ORM.
- Infrastructure : repos SQL/Neo4j, clients P6/Unifier, provider LLM et notifications adaptateurs.
- Workers : jobs durables/idempotents avec transitions d’état SQL, retry/timeout, task ID corrélé; import package intégré au même système asynchrone.

## Frontend cible
Conserver le Studio v2 et sa façade testable; configuration API runtime unique pour toutes les features; backend history source de vérité du chat avec cache local minimal/purgé; secret handling jamais dans query params. Tests E2E de routes critiques.

## Datastores, sécurité, IA
Maintenir stockage hybride, mais documenter propriétaires et synchronisations SQL↔Neo4j. Résolution secret centralisée, egress allowlist, révocation d’accès tenant en compte de `is_active`, readiness et métriques. Assystan garde `LLM Gateway → orchestrateur → agents → tools ACL → retrieval/connecteurs`, avec provenance outils claire et budgets mesurés.

## Migration graduelle
1. Corriger bugs proxy et config frontend, puis établir tests de contrat.
2. Résoudre les findings credentials/SSRF/auth sans changer de paradigme.
3. Remplacer stubs et threads par tâches durables.
4. Retirer `ensure_schema` après une transition Alembic vérifiée.
5. Définir critères/chronologie de retrait Studio v1 à partir des appels réellement utilisés.
6. Ajouter backups/restores et readiness avant augmenter le nombre d’instances.

Diagramme : [target-architecture.mmd](diagrams/target-architecture.mmd). Les contrôles Caddy/cloud et secrets manager restent dépendants de l’infrastructure hors dépôt.