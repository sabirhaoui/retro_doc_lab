# Runtime et conteneurisation

## Développement

Compose : Nginx, backend, PostgreSQL, Neo4j, Redis, worker, Beat, Flower, Mailpit et seed. Les DB ont healthchecks; Nginx dépend du démarrage du backend. Le frontend Compose est commenté et le Nginx racine reverse-proxy `/` vers `host.docker.internal:4200`. Il y a deux écarts distincts : port hôte/container Nginx et réécriture du préfixe `/api` (ARCH-001/002).

Les ports hôte Postgres 5433, Neo4j 7474/7687 et Redis 6379 sont publiés en dev; cela facilite le développement mais doit rester explicitement local.

## Production

Compose deploy ne publie pas Postgres/Neo4j/Redis; backend 8010 et frontend 3010 sont bindés à `127.0.0.1`. Le commentaire attend Caddy comme unique entrée Internet; son fichier/configuration est hors dépôt. Frontend prod est une image Nginx statique, avec fallback Angular; elle ne fait pas proxy API dans le Nginx livré.

Backend prod tourne sous utilisateur non-root; l’image prod frontend build avec Node 22. Les images de datastore/proxy utilisent plusieurs tags mobiles. Les DB ont healthchecks Compose, mais backend/workers n’en ont pas; `/health` ne vérifie pas les dépendances.

## Exploitation

Le script de release sauvegarde SQL avant migration et attend HTTP après démarrage; il ne sauvegarde pas Neo4j dans le code examiné. Le `.env` prod template est conçu pour être copié sur l’hôte et le script refuse les placeholders. Le fichier `deploy/ci-fixtures/.env` n’a pas été ouvert.

## Actions

Corriger et tester le Nginx local, clarifier la topologie Caddy/API, ajouter un endpoint readiness dépendances si nécessaire, fixer images par digest/version patch et documenter backup/restore Neo4j. Tous les fichiers Compose/build n’ont pas été exécutés.
