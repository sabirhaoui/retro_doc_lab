# Architecture frontend

## Structure et responsabilités
**FACT** — Angular 22 démarre par `bootstrapApplication`; `app.routes.ts` déclare routes lazy-loadées et guards. `HttpClient` utilise interceptors auth/refresh et erreurs. Les services encapsulent l’API.

Le Studio v2 utilise Signals, pagination et chargement lazy de l’arbre. `WorkspaceStateService` délègue réellement à services métadonnées, graph, overview, types, membres et archive; sa spec teste la façade avec services réels et API/notifications mockées. `StudioApiService` est le client HTTP spécialisé.

## Auth et stockage
Le token d’accès est conservé en mémoire; refresh via cookie HttpOnly. `AuthInterceptor` ajoute Bearer et renouvelle sur 401. L’onboarding guard obligatoire est commenté/désactivé dans les routes.

**FACT** — `ChatStoreService` sérialise toutes les conversations en localStorage; `ChatAiService` appelle aussi l’API backend qui peut persister sessions/messages. **INFERENCE** — il y a deux copies de données et des politiques rétention/suppression susceptibles de diverger (ARCH-012).

## Écarts et risques
- Le README nomme `WorkspaceStateV2Service` et un fichier versionné; la classe source est `WorkspaceStateService` sous `frontend/src/app/studio/services/`.
- `environment.apiUrl` est relatif `/api`; les méthodes d’import async construisent localhost:8001 (ARCH-003).
- Méthodes GET P6/Unifier incluent `token`/`password` en query (ARCH-004).
- `tsconfig` active `strict` et `strictTemplates`; Jest/jsdom configure mocks Sigma WebGL.
- Pas d’E2E browser identifié dans le manifeste; 46 specs front recensées. Aucun résultat de test n’a été obtenu.

## Cible d’amélioration
Conserver la façade et la séparation des services, mettre la config d’API à un seul endroit runtime, donner au backend la source de vérité conversationnelle, ajouter test E2E des chemins d’auth/import et garder secrets hors storage/URL.