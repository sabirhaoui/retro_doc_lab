# Cartographie du repository

## Arbre fonctionnel simplifié

```text
backend/
  app/main.py                 assemble FastAPI, middleware, startup, routeurs
  app/core/                   sessions SQL et driver Neo4j
  app/models/domain|orm/      modèles Pydantic et SQLAlchemy
  app/modules/                services/routeurs métier, workers, intégrations
  app/repositories/           SQL et dépôt graphe historique
  migrations/                 Alembic, révisions jusqu’à 0024
  tests/unit|integration/     pytest, intégration PostgreSQL
frontend/
  src/main.ts                 bootstrapApplication
  src/app/app.routes.ts       routes lazy-loadées et guards
  src/app/services|studio/    clients API, state Signals, orchestration UI
  src/app/pages|components/   expérience Angular et graphe WebGL
  jest.config.js              tests Jest/jsdom
nginx/                        reverse proxy du Compose local
 deploy/                      Compose prod, release, runtime, env template
azure-pipelines.yml           CI + CD conditionnel
```

## Composants majeurs
| Zone | Entrée | Responsabilité |
|---|---|---|
| API FastAPI | `backend/app/main.py` | routeurs modules, startup, middleware, `/health` |
| Domaine backend | `backend/app/modules/` | identity, studio/v2, connectors, Assystan, retrieval, twin, quality/diff, alerts, dashboards, experimentation et document/package graph |
| Stockage | `backend/app/core/`, `models/`, `repositories/` | Postgres/SQLAlchemy et Neo4j/Cypher |
| Traitements | `backend/app/celery_app.py`, `modules/*/tasks.py` | worker, Beat et jobs; import ZIP Unifier passe par thread API |
| UI | Angular `main.ts`/routes/services | auth, chat, studio, admin, sources, dashboards et expérimentation |
| Runtime dev | `docker-compose.yml`, `nginx/default.conf` | services locaux, frontend attendu hors Docker |
| Runtime production | `deploy/docker-compose.deploy.yml` | backends/datastores/frontend loopback, Caddy externe présupposé |
| CI/CD | `azure-pipelines.yml` | quality gates, tests, infra config, déploiement conditionnel |

**FACT** — `backend/app/api/` et `dependencies/` existent, mais l’assemblage actuel de `main.py` importe les routeurs actifs depuis `app.modules.*`; l’usage résiduel des dossiers legacy n’a pas été exhaustivement tracé.

## Tests, config et dépendances principales
Tests sous `backend/tests` et specs Jest sous `frontend/src`; fichiers de configuration dans manifests Python/Angular, Compose, Docker, Nginx et Azure Pipeline. FastAPI route vers services; services croisent repositories et modules; SQL et graphe ont deux schémas Studio. Assystan utilise LLM gateway, retrieval, tools et connecteurs ERP. Redis est le broker/backend Celery observé.