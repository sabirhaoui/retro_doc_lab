# Architecture IA / RAG

## Architecture constatée

Assystan est un module du monolithe FastAPI, pas un microservice. Le routeur sémantique sélectionne une cible via la passerelle LLM; l’orchestrateur construit contexte/agents, délègue le tour, forme citations/trace et peut persister en PostgreSQL. Les agents spécialisés couvrent process, Unifier, P6, multi-sources et dashboards; certaines réponses (WP Cost) sont déterministes.

`BaseLLMProvider` découple l’orchestration du provider; la factory sélectionne OpenAI ou Mock. Les outils/clients incluent retrieval graphe avec ACL/citations, exploration du package Unifier NetworkX et données P6/Unifier live. Pas de vector store/embeddings identifié dans les sources consultées. Un endpoint SSE existe pour le chat.

## Garde-fous observés

- `AuthorizedAssystanTools` impose ACL workspace pour les outils graphe/package.
- Schémas stricts de function calls et dispatch par liste de fonctions dans `run_tool_loop`.
- La boucle est bornée à 10 rounds; requête LLM plafonnée par configuration de tokens.
- Réponses portent citations, trace et confidence; le retrieval renvoie clarification si aucune preuve.
- Le provider brut est décrit comme non destiné à l’UI.

## Risques et limites

Le résultat des outils est réinjecté comme message `user`, faute de représentation standard `role=tool` dans le contrat actuel. Cela fonctionne dans la boucle écrite mais brouille la frontière de provenance dans l’historique modèle. Les erreurs d’outils sont converties en `{error: str(exc)}` puis visibles au modèle; l’exposition côté utilisateur doit être revue. Les contenus de graphes/documents sont potentiellement non fiables; des tests dédiés d’injection prompt et d’exfiltration d’outils n’ont pas été identifiés dans le périmètre consulté.

Les agents P6/Unifier utilisent des systèmes externes synchrones; aucune mesure de latence/couts, quota global ou timeout LLM commun n’a été exécutée. La confiance est un champ de sortie métier, pas une preuve de calibration statistique dans les éléments examinés.

## Recommandations

Maintenir les tools derrière des interfaces ACL; formaliser le protocole tool-call (tool role/id), marquer les sorties d’outils comme données non fiables, valider les arguments/réponses par schémas, borner les appels/temps/coûts et ajouter tests adversariaux de prompt injection. Journaliser métriques sans prompt/secret brut. Voir [E-024](evidence/ledger.md) et le diagramme [IA/RAG](diagrams/ai-rag-flow.mmd).
