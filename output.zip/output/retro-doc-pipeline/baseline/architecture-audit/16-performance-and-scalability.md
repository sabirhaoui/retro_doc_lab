# Performance et scalabilité

## Backend et graphes
Studio v2 utilise pagination pour plusieurs listes et chargement lazy de l’arbre; le frontend plafonne les pages aux maxima backend. En revanche, le repository retrieval v2 charge nodes, types et relations d’un workspace en listes, puis filtre/rank en Python. Le modèle v1 peut aussi sérialiser un document de workspace complet. L’impact dépend du volume réel, non mesuré.

Les appels REST P6/Unifier et LLM sont synchrones dans des routes/services principalement synchrones; FastAPI les exécute via son mécanisme standard de route sync, mais le coût threadpool/latence sous concurrence n’a pas été mesuré. Builder synchrone par défaut peut allonger une requête. Upload ZIP lit le fichier entier et conserve les bytes lors du traitement thread.

## Frontend
Signals, façade de domaine, tree lazy-load et pagination du graphe réduisent certains chargements. Le store chat sérialise toute la liste de conversations à chaque effet signal; le coût croît avec l’historique local. Sigma/WebGL limite les tests/rendus jsdom, pas de mesure de mémoire/frames disponible.

## Workers et stores
Worker configuré concurrency=2 dans Compose; aucune limite de ressources container explicite n’a été lue. Redis sert à broker/backend; aucun cache applicatif n’a été établi. Snapshots/alertes balaient plusieurs entités et doivent être observés à l’échelle réelle.

## Actions et limites
Mesurer taille workspace, temps Cypher, coût de sérialisation et latence LLM/API; ajouter pagination/filtrage côté source avant de remplacer l’architecture. Configurer limites upload, timeout et quotas, puis charge-test de manière isolée. Aucun benchmark ou profilage dynamique n’a été exécuté.