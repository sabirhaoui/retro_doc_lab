# Qualité du code

## Configuration

Backend : Ruff avec règles E/W/F/I/N/UP/B/SIM/RUF, format check CI; Mypy configuré `strict=false`, avec warnings ciblés et plugin Pydantic. Le pipeline exécute format, lint, Mypy. Frontend : TypeScript strict, `strictTemplates`, ESLint TS/HTML; certaines règles `any`/unused vars sont des warnings. Jest et Prettier sont configurés.

## Observations de structure

- Services et repositories séparés dans la plupart des modules; erreurs métier centralisées.
- Plusieurs modules se connaissent directement; l’orchestrateur Assystan assemble divers agents/domaines, et `unifier_package` orchestre graphes/Studio/canonique.
- Studio v1/v2 maintient deux modèles de données; les facades compatibilité/retrieval sont des coûts de migration actifs.
- Commentaires explicatifs nombreux et utiles pour plusieurs limites, mais des documents d’architecture évoluent indépendamment du code.
- L’état global NetworkX et status dict par processus compliquent isolation et tests distribués.

## Qualité non mesurée

Aucun lint, format, typecheck, analyse de complexité, détection code mort ou test n’a été exécuté. Il n’y a donc pas de décompte d’erreurs, couverture ou complexité calculée. Voir `evidence/commands.md`.

## Actions

Privilégier des tests de contrats et des frontières de modules avant refactor; conserver les changements ciblés. Épingler les dépendances Python via un lock reproductible et documenter les exceptions de lint. Prioriser la migration de schéma v1/v2 et la durabilité des tâches avant de découper en services.
