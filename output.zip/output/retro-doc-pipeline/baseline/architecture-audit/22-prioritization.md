# Priorisation des findings

La priorité combine risque, impact, urgence et effort de réduction; aucune note numérique arbitraire n’est calculée.

| ID | Finding | Severity | Impact | Effort | Priority | Justification / quick win |
|---|---|---:|---|---:|---:|---|
| ARCH-004 | Credentials ERP dans URL | HIGH | Élevé | S | P1 | Retirer les secrets des GET rapidement. |
| ARCH-005 | SSRF connecteurs | HIGH | Élevé | M | P1 | Egress/allowlist et validation host avant exposition. |
| ARCH-003 | Import async localhost en prod | HIGH | Élevé | S | P1 | Réécriture locale du base URL; feature prod indisponible. |
| ARCH-002 | Préfixe API retiré par Nginx dev | HIGH | Élevé | S | P1 | Bug d’entrée central, test proxy simple. |
| ARCH-001 | Port Nginx dev incorrect | HIGH | Élevé | S | P1 | Quick win, entrée documentée inaccessible. |
| ARCH-008 | Ingestion stub en succès | HIGH | Élevé | M | P1 | Ne pas consommer snapshots fictifs; corriger contrat. |
| ARCH-010 | Pas de backup Neo4j observé | HIGH | Élevé | M | P1 | Confirmer backup externe immédiatement; sinon ajouter. |
| ARCH-006 | Token accepté après désactivation | MEDIUM | Moyen/élevé | S | P1 | Vérification `is_active` locale, faible coût. |
| ARCH-007 | Secret ref sans resolver visible | MEDIUM | Élevé | M | P1 | Clarifier avant stockage/rotation de secrets ERP. |
| ARCH-009 | DDL startup + Alembic | MEDIUM | Moyen | M | P2 | Dette de transition; migrations avant prochains changements. |
| ARCH-011 | Import package en mémoire | MEDIUM | Moyen | M | P2 | Blocage avant scaling/reprise fiable. |
| ARCH-014 | Intégration non exécutée en CI | MEDIUM | Moyen | M | P2 | Gate Postgres pour régressions de persistance. |
| ARCH-012 | Chat localStorage | MEDIUM | Moyen | M | P2 | Arbitrer rétention/PII et source de vérité. |
| ARCH-013 | Doc nie le CD | MEDIUM | Moyen | S | P2 | Corriger immédiatement la compréhension opératoire. |

P0: aucun finding CRITICAL n’a été prouvé. Les priorités P1 sont à séquencer avec l’owner sécurité/plateforme; le backup Neo4j dépend d’une contre-vérification auprès des Ops.