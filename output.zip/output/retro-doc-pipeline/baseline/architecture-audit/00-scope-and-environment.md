# Périmètre et environnement

## Référentiel
- **FACT** — Repository analysé : `c:\workspace\twins_project_feat_studio`.
- **FACT** — Date : 2026-10-01; environnement de travail Windows/VS Code.
- **LIMITATION** — Branche et commit non établis. Le terminal actif n’était pas à la racine Git; l’appel status a échoué « not a git repository » et les appels branche/log ont été ignorés. Aucune valeur n’est inventée.
- **FACT** — L’index du workspace a recensé environ 902 fichiers; `backend/app` compte 249 fichiers Python, l’index de tests backend 123 fichiers, et 46 specs frontend.

## Périmètre consulté
- Racine : README, TODO, Makefile, manifests, Compose, Azure Pipelines, Nginx et exemples d’environnement.
- Backend : `main.py`, core DB/Neo4j, modules métier critiques, ORM/domain, repositories, Alembic et tests représentatifs.
- Frontend : package/config Angular, routes, guards, interceptors, auth, services chat/Studio, Signals et specs représentatives.
- Déploiement : Compose production, Dockerfiles, scripts release/runtime et exemple d’environnement.
- Documentation : README/TODO et documents techniques Assystan/Expérimentation sélectionnés.

**Méthode :** lazy loading par inventaire → entrypoints → dépendances → flux critiques. Les relations décrites sont fondées sur un appel, un import, une configuration ou un document explicitement vérifié.

## Confidentialité et écriture
- **FACT** — `deploy/ci-fixtures/.env` a été détecté par nom; son contenu n’a pas été lu. Aucun secret `.env` n’est reproduit.
- **FACT** — `architecture-audit/` n’existait pas avant les premières écritures; aucun artefact préexistant n’a été écrasé.
- **FACT** — Tous les fichiers créés pour cet audit sont dans `architecture-audit/`.

## Non exécuté et limites
Aucun test, lint, typecheck, build, conteneur, migration, benchmark, scan CVE/secrets, requête DB ou appel P6/Unifier n’a été lancé. Voir [journal](evidence/commands.md). Caddy/cloud/Ops hors dépôt ne sont pas vérifiables. La performance/scalabilité est statique. L’état Git initial n’est pas disponible; l’audit ne peut donc certifier l’absence de modifications préexistantes dans le workspace.