# Dette technique

| Dette | Catégorie | Évidence | Conséquence | Priorité |
|---|---|---|---|---|
| Studio v1 et v2 persistent deux modèles Neo4j; retrieval garde un fallback v1 | Architecture / Code | E-019 | Double évolution, contrats et migration de données parallèles | P2 |
| `ensure_schema` modifie au démarrage un schéma également géré par Alembic | Architecture / Opération | E-009 | Migrations moins reproductibles | P2 |
| Tâche ingestion officielle encore placeholder et statut success vide | Produit / Code | E-008 | Fonction déclarée mais non livrée par le flux async | P1 |
| Import Unifier en thread et statut mémoire locale | Opération | E-011 | Perte d’état/reprise au redémarrage | P2 |
| Référence de secret sans résolveur visible | Sécurité / Intégration | E-007 | Ambiguïté fonctionnelle et de protection | P1 |
| Proxy local, URL import prod et credentials query incohérents | Infra / Sécurité | E-001 à E-004 | Environnements/test UI divergents | P1 |
| Docs d’architecture et CI/CD dérivent du code | Documentation | E-013, E-018 | Décisions prises sur une topologie ou un modèle obsolète | P2 |
| Chat conservé à la fois en backend et localStorage | Données / Sécurité | E-012 | Rétention et suppression non centralisées | P2 |
| Dépendances Python non complètement lockées, tags conteneurs mobiles | Build | E-016, E-026 | Reproductibilité limitée | P2 |

## Dette à ne pas sur-interpréter
La coexistence v1/v2 est une migration en cours, pas automatiquement une mauvaise architecture. L’absence de vector store est cohérente avec le retrieval graphe/API observé. Les jobs périodiques distincts suivent des besoins métier identifiés. La priorité est d’expliciter la fin de migration et les contrats, non de réécrire en microservices.

Le backlog `TODO.md` contient aussi des demandes de raccordement UI et éléments déjà implémentés; vérifier chaque ligne avec le code avant usage comme roadmap.