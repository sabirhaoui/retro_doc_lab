 
# Document Technique : Module d'Authentification & Gestion des Utilisateurs

## 1. Architecture & Fonctionnement Actuel

Le module gère l'authentification (locale et SSO Microsoft), la gestion des sessions JWT, ainsi que le cycle de vie des utilisateurs (création par un administrateur, invitation et activation de compte).

### 1.1. Modèle de Données & Composants Clés

* **Frontend Angular** :
* `AdminUsersService` & `AdminApiService` : Gèrent la logique de présentation et l'émission des requêtes HTTP vers `/api/v1/admin/users`.


* **Backend FastAPI (Couche Exposition)** :
* `router.py` : Expose les endpoints HTTP pour l'authentification (`/v1/auth/*`) et l'administration (`/v1/admin/*`).




* **Couche Service (`IdentityService`)** :
* `service.py` : Contient toute la logique métier (validation des règles, orchestration du hachage, émission des JWT, gestion des sessions OAuth Microsoft).




* **Couche Repositories (`user_repo` & `auth_session_repo`)** :
* `user_repo.py` : Exécute les requêtes SQLAlchemy (`db.add()`, `db.commit()`) pour insérer ou mettre à jour les entrées dans PostgreSQL.



### 1.2. Flux de Création d'Utilisateur & Activation

```
[Angular UI] 
   └─> AdminApiService.addUser()
          └─> [POST /api/v1/admin/users]
                 └─> IdentityService.create_user()
                        ├─> user_repo.create_user() (PostgreSQL: is_active=False)
                        ├─> email_service.send_invite() (Envoi du mail)
                        └─> Setup account via /v1/auth/setup-account (Fixation du mot de passe)

```

---

## 2. Limitations Techniques & Risques Identifiés

En analysant le code source et en le confrontant aux exigences de la stratégie de test, plusieurs limitations apparaissent :

### 2.1. Traitement Synchronique des E-mails

* **Problème** : Dans `router.py`, l'envoi de l'e-mail d'invitation via `email_service.send_invite(...)` est effectué de manière synchrone directement dans le thread de la requête HTTP FastAPI.


* **Impact** : Si le serveur SMTP/Mailpit subit une latence ou tombe en panne, la requête HTTP de création d'utilisateur reste bloquée ou échoue avec un code `500`, bien que la ligne ait été créée en base de données.

### 2.2. Couplage fort avec le Schéma "Legacy"

* **Problème** : Dans `IdentityService.create_user()`, une conversion vers un DTO intermédiaire est effectuée (`LegacyUserCreate` et `LegacyUserUpdate`).


* **Impact** : Risque de régression sur la gestion des champs (ex: perte de certains attributs spécifiques au profil ou au statut), rendant l'écriture de tests unitaires plus complexe.

### 2.3. Gestion de Session & Sécurité Client

* **Problème** : L'expiration de session sur inactivité (scénario `SEC-AUTH-02`) repose intégralement sur le client Angular. Si le client ferme son onglet sans se déconnecter, la session reste active côté serveur jusqu'à l'expiration du token.
* **Impact** : Absence d'invalidation automatique du token si un utilisateur est désactivé par un admin entre-temps (déjà traité au niveau `get_current_user`, mais nécessite un mécanisme de révocation explicite).

### 2.4. Mot de Passe Placeholder en BDD

* **Problème** : La fonction `create_user` dans `user_repo.py` écrit la chaîne `"INVITED_NO_PASSWORD_SET_YET"` dans le champ `hashed_password`.
* **Impact** : Si une faille dans la logique de vérification du mot de passe survient (ex. sur l'endpoint `/login`), une tentative de connexion avec cette chaîne explicite pourrait poser un risque d'usurpation. Il est préférable d'utiliser `None` ou un hash invalide de type Argon2/Bcrypt.

---

## 3. Plan d'Amélioration & Refactoring

Pour répondre à la stratégie de test et faciliter le développement de nouvelles fonctionnalités, les axes d'amélioration suivants doivent être mis en œuvre :

### 3.1. Asynchronisme & Worker de Tâches (Celery + Redis)

* **Action** : Déporter l'appel `email_service.send_invite()` vers une tâche asynchrone Celery (`send_invitation_email.delay(...)`).
* **Gain** : Temps de réponse HTTP quasi-immédiat côté Angular (< 50ms) et robustesse face aux pannes du serveur SMTP.

### 3.2. Uniformisation des Modèles & Suppression du "Legacy"

* **Action** : Refactoriser `user_repo.py` pour accepter directement les schémas Pydantic modernes (`UserCreateRequest`) au lieu de repasser par `LegacyUserCreate`.


* **Gain** : Lisibilité accrue du code, meilleure sécurité de typage (`mypy`) et maintenance simplifiée.

### 3.3. Déconnexion sur Inactivité & Invalidation Côté Serveur

* **Action** :
1. Ajouter un service Angular `AutoLogoutService` basé sur un `timer` RxJS qui surveille les interactions utilisateur (`mousemove`, `keydown`, `click`).
2. En cas d'inactivité (ex. 15 min), déclencher un appel `POST /v1/auth/logout` pour révoquer le cookie `refresh_token` puis rediriger vers `/auth/login?reason=session_expired`.


* **Gain** : Couverture complète du scénario de test de sécurité `SEC-AUTH-02`.

### 3.4. Sécurisation de la Création de Compte

* **Action** :
1. Modifier `user_repo.py` pour stocker `None` (Null) ou un hash irréversible non utilisable lorsque le mot de passe n'a pas encore été défini.
2. S'assurer qu'un compte avec `is_active = False` ne puisse en aucun cas franchir l'étape de vérification de mot de passe.



---

## 4. Matrice de Traçabilité pour les Tests & Futures Features

| Scénario de Test / Exigence | Composant Concerné | Amélioration à Apporter |
| --- | --- | --- |
| **`UT-USER-01`** (Statut temporaire) | `user_repo.py` | S'assurer de la présence d'un statut explicite `INVITATION_PENDING`. |
| **`SEC-AUTH-02`** (Timeout inactivité) | Angular + `router.py` | Implémenter l'écouteur d'événements UI et l'invalidation automatique. |
| **`INT-CELERY-01`** (Envoi mail async) | `router.py` & `tasks.py` | Déplacer l'envoi de mail de `router.py` vers un worker Celery. |
| **`SEC-AUTH-01`** (Zero secrets in URL) | `AdminApiService` | Conserver l'usage strict des headers `Authorization` et cookies `HttpOnly`. |