# Flux de données et runtime

## Authentification
**FACT** — Login `/api/v1/auth/login` vérifie mot de passe, renvoie access/refresh JWT et pose refresh en cookie HttpOnly; Angular stocke access en mémoire et le joint en Bearer. 401 déclenche refresh puis replay. Logout efface le cookie; aucune révocation JWT serveur observée. `get_current_user` ne revérifie pas `is_active` (ARCH-006).

Durées par défaut observées: access 60 minutes, refresh 14 jours; README déclare 30 min et 7 jours. Le flux exact est dans [auth-flow.mmd](diagrams/auth-flow.mmd).

## Workspace/graph
Angular `StudioApiService` → `/api/v2/studio` → router/service → ACL PostgreSQL → repositories Neo4j v2. Le modèle legacy v1 reste en Neo4j via `repositories.graph_repo`; retrieval tente v2 puis v1. Métadonnées `WorkspaceGraphRef` relient workspace SQL à la clé graphe.

## Async
Connectors persiste job SQL puis `.delay()` vers Redis/Celery; worker actuel produit snapshot placeholder. Builders sont synchrones par défaut, option async route Celery. Beat planifie mappings, snapshots P6 et alertes. Import ZIP Unifier passe par thread daemon et dict mémoire, pas Celery. Diagramme : [async-flow.mmd](diagrams/async-flow.mmd).

## IA/RAG
Chat → `/api/v1/assystan/chat` ou SSE → orchestrateur → routeur LLM → agent → outils autorisés/retrieval ou API ERP → provider LLM → réponse/citations/trace, historique PostgreSQL. Retrieval est graphe/API; aucune base vectorielle observée. Diagramme : [ai-rag-flow.mmd](diagrams/ai-rag-flow.mmd).

## Diff/quality
Diff accepte jeux d’entités P6/Unifier, utilise mappings optionnels, calcule/persiste findings. Builder appelle les validateurs/scoring; erreurs structurelles bloquent publishable. Aucun benchmark, appel externe réel ou exécution de ce flux n’a été fait pendant l’audit.

Evidence: E-002 à E-009, E-019 à E-025.