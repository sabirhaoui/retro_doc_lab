# Architecture des données

## PostgreSQL
**FACT** — ORM couvre rôles/utilisateurs, workspaces/membres, graph refs, catalogues/credentials, jobs/snapshots, packages, mappings, builder/diff/dashboard runs, chat/feedback, alertes, expérimentations, snapshots planning et santé Twin. Plusieurs payloads sont JSONB. Certaines colonnes `workspace_id` de run tables ne sont pas des FK.

Alembic va jusqu’à `0024_onboarding_derived`; le script release exécute `alembic upgrade head`. **FACT** — en plus, au startup l’API appelle `ensure_schema()`: `create_all`, ajout manuel de colonnes, drop d’une contrainte. **RISK** — une voie de DDL non versionnée reste active (ARCH-009).

## Neo4j
- Studio v1 : Workspace → Graph → Category → KnowledgeNode; `repositories.graph_repo.py`.
- Studio v2 : label Node générique, relations RELATES_TO et hiérarchie PARENT_OF; `modules/studio_v2/repos/`.
- Canonique : `CanonicalOntologyVersion`, payload complet JSON.
- `WorkspaceGraphRef` est SQL, liant workspace relationnel à clé Neo4j.

**FACT** — retrieval préfère v2 et retombe sur v1 (E-019). **OBSERVATION** — `_load_v2` convertit les nœuds/relations en listes de workspace; aucune performance réelle n’est mesurée.

## Redis
Settings/Celery configurent broker et result backend séparés. Aucun cache applicatif identifié dans les chemins consultés; rôle de cache du README non confirmé.

## Backup / cohérence
Le déploiement exécute un pg_dump avant migration; Neo4j possède un volume persistant, mais aucun backup du graphe n’a été trouvé dans les scripts consultés (ARCH-010). Un backup opérateur hors repo reste ASSUMPTION. SQL↔Neo4j n’est pas transactionnel; les syncs reposent sur orchestration/réparations.

## Actions
Converger vers Alembic unique, tester snapshot/restore Postgres + Neo4j ensemble, publier propriétaires/RPO/RTO, mesurer les requêtes retrieval avant toute optimisation.