# Roadmap de migration

## Phase 0 — Réduire les risques immédiats
- **Objectif :** restaurer un parcours proxy fiable et réduire exposition secrets/destinations.
- **Changements :** corriger port/URI Nginx; retirer secrets des query params; allowlist URLs ERP; vérifier actif utilisateur; corriger URL d’import prod.
- **Dépendances :** contrat proxy/Caddy et politique d’URL connecteur.
- **Risque :** clients/outils externes dépendant des routes GET existantes.
- **Effort :** S à M.
- **Résultat :** parcours frontend/API fiable et surface réseau réduite.
- **Vérification :** tests proxy/API, tests auth/URL, staging derrière Caddy.

## Phase 1 — Clarifier credentials et opérations data
- **Objectif :** rendre secrets et backups vérifiables.
- **Changements :** resolver `secret_ref` ou stockage via secret manager; supprimer lecture valeur côté API; sauvegarde/restauration Neo4j et documentation RPO/RTO.
- **Dépendances :** choix de coffre et environnement de déploiement.
- **Risque :** rotation/format de credential et restauration de données legacy.
- **Effort :** M.
- **Résultat :** provenance credentials et reprise graph documentées.
- **Vérification :** test credential factice, inspection réponse API, exercice restore isolé.

## Phase 2 — Rendre l’async honnête et durable
- **Objectif :** éviter faux succès et états volatils.
- **Changements :** implémenter extraction via registry ou exposer unsupported; cancellation cooperative; import package comme task durable SQL/Celery; idempotence, timeout/retry.
- **Dépendances :** contrats P6/Unifier et stockage upload temporaire.
- **Risque :** doublons/rupture contrat UI.
- **Effort :** M à L.
- **Résultat :** jobs observables, reprenables, résultat conforme.
- **Vérification :** tests worker avec doubles deliveries, erreurs, restart et annulation.

## Phase 3 — Unifier cycle de schéma et documentation
- **Objectif :** une seule voie versionnée de changement PostgreSQL.
- **Changements :** réconcilier historique Alembic et bases existantes; retirer DDL startup; mettre à jour README/TODO/Exp docs et structure Angular.
- **Dépendances :** sauvegarde vérifiée, environnement staging représentatif.
- **Risque :** bases historiques non estampillées ou divergentes.
- **Effort :** M.
- **Résultat :** déploiements reproductibles et doc fidèle.
- **Vérification :** upgrade depuis baseline/staging snapshot; démarrage sans DDL; matrice doc vs source.

## Phase 4 — CI, observabilité et migration v1/v2
- **Objectif :** sécuriser évolution et scale avant extractions.
- **Changements :** intégrer tests Postgres, tester images avec mêmes Node/Python que prod, coverage ciblée, health/readiness, metrics workers, critères retirement v1.
- **Dépendances :** CI runners avec service DB et environnement Caddy de test.
- **Risque :** durée CI et coût observabilité.
- **Effort :** M à L.
- **Résultat :** signaux opérationnels, gate plus représentatif.
- **Vérification :** pipeline CI reproductible, alertes/restore drills, inventaire usage v1.

## Phase 5 — Durcissement production
- **Objectif :** maîtriser supply chain et opérations.
- **Changements :** lock Python, pin images/digests, SBOM/scan/signature, approvals CD explicites, rétention backups et exercice rollback.
- **Dépendances :** politiques sécurité/ops de l’organisation.
- **Risque :** maintenance régulière des images/dépendances.
- **Effort :** M.
- **Résultat :** releases auditables et récupérables.
- **Vérification :** preuve pipeline, provenance artefacts, restore et rollback en environnement dédié.
