# Tests et testabilité

## Inventaire

- Backend : fichiers unitaires et intégration dans `backend/tests`; fixtures de testclient FastAPI à la racine.
- Intégration : plusieurs tests repositories ciblent un vrai PostgreSQL; le fixture de session skip si PostgreSQL n’est pas disponible et isole les écritures via SAVEPOINT.
- Frontend : 46 specs recensées, Jest/jsdom; configuration couvre les TypeScript sous `src/app` et mocke les imports Sigma/WebGL.
- Unit test représentatif identité vérifie RBAC workspace; tests Studio vérifient la façade et délégation vers services spécialisés.

## Gate CI observé

Le pipeline backend lance Ruff format/lint, Mypy et `pytest tests/unit`; il ne lance pas `tests/integration`. Le frontend exécute lint, Jest et build production. La commande Jest passe `--coverage=false`, même si le script package et Jest config savent collecter la couverture.

## Testabilité

Les ports LLM mockables, les loaders injectables de retrieval et les services testés par mocks améliorent l’isolation. Les tests d’intégration DB existent et sont transactionnellement isolés. La présence d’un test fichier ne garantit pas les scénarios de production; couverture totale, résultat CI, flakiness et distribution par code n’ont pas été mesurés.

Les composants Sigma/WebGL sont testés avec un mock en jsdom selon la configuration; le README décrit aussi des tests de composant au niveau classe sans rendu DOM complet systématique. Aucun test E2E browser n’a été repéré dans le manifeste consulté.

## Lacunes prioritaires

- Intégrer un PostgreSQL éphémère et les tests d’intégration les plus critiques dans un gate CI distinct.
- Ajouter les tests d’URL/proxy, auth désactivée, secret resolver, annulation Celery et import production relatifs aux findings.
- Publier les rapports JUnit/coverage utiles et définir des seuils après mesure de baseline.
- Ajouter un parcours browser pour login/refresh, navigation Studio et import package.

Aucun test n’a été exécuté pendant cet audit. Voir [ARCH-014](findings/ARCH-014-ci-integration-coverage.md) et `evidence/commands.md`.
