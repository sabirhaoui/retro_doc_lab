# DevOps et CI/CD

## Pipeline Azure

Le YAML déclenche sur `dev` et `main`, inclut PR sur ces branches et a un stage CI en jobs backend, frontend, infra. Backend: installation pip, Ruff, Mypy, unit tests. Frontend: Node 24, `npm ci --legacy-peer-deps`, ESLint, Jest, Angular prod build. Infra valide Compose dev et deploy avec `docker compose config --quiet`.

Un stage `CD` est effectivement présent : condition succès, branche `dev`, cause différente d’une PR. Il build images, assemble release, installe clé SSH/known_hosts, transfère sur serveur et applique la release. README/TODO annoncent encore « pas de CD ». L’YAML consulté ne déclare pas d’approbation d’environnement; une gate externe Azure reste ASSUMPTION.

## Build/release/deploy

`deploy/build-release.sh` construit deux images de production dans l’agent CI, puis exporte les images et compose/scripts dans un artefact release. `apply-release.sh` valide placeholders, charge images, sauvegarde PostgreSQL, applique Alembic, seed référence puis démarre services et attend `/health` backend + frontend. Les ports prod sont loopback; le commentaire désigne Caddy externe.

## Écarts et risques

- Le pipeline CI n’exécute pas le Compose réel ni Dockerfile build; il valide seulement la syntaxe Compose.
- CI utilise Node 24, image build frontend Node 22; les deux builds ne sont pas le même environnement.
- Dépendances Python et tags Docker major/minor mobiles réduisent la reproductibilité.
- Aucun scan d’image, SBOM, signature/provenance ou test de restauration n’a été trouvé dans YAML/scripts consultés.
- La release sauvegarde PostgreSQL mais pas Neo4j dans le dépôt.
- Le stage CD de `dev` peut déployer vers l’hôte associé à la config runtime; gates externes non visibles.

## Actions

Aligner la politique documentaire, fixer versions build, ajouter un job de build des images et scans, confirmer environment approvals, restaurer périodiquement les deux datastores et conserver une procédure rollback vérifiée. Voir ARCH-013 et ARCH-010. Le pipeline n’a pas été exécuté.
