# Stack et dépendances

## Versions déclarées / construites
| Domaine | FACT observé | Fichier principal |
|---|---|---|
| Backend | Python `>=3.11`; FastAPI 0.139.0; Pydantic 2.13.4; SQLAlchemy 2.x; Alembic | `backend/pyproject.toml`, `requirements.txt` |
| Frontend | Angular `^22.0.5`; TypeScript `~6.0.3`; RxJS ~7.8.1; Jest 30 | `frontend/package.json` |
| Graph/SQL | Image Neo4j 5.21.0; Postgres 15-alpine; client Neo4j 6.2.0 | requirements/Compose |
| Async | Celery >=5.4, redis-py >=5; Redis 7-alpine | requirements/Compose |
| IA | OpenAI >=1.60, providers OpenAI/Mock | requirements et `llm_gateway` |
| Infra | Nginx Alpine, Docker Compose, Azure Pipelines | root/deploy configs |
| Node | Azure CI 24.x; Docker prod frontend Node 22-alpine | `azure-pipelines.yml`, Dockerfile prod |

## Reproductibilité
**FACT** — `frontend/package-lock.json` existe et CI utilise `npm ci --legacy-peer-deps`. **FACT** — plusieurs exigences Python sont `>=` et aucun lockfile Python n’a été recensé. Plusieurs images utilisent tags mobiles (`python:3.11-slim`, `node:22-alpine`, `nginx:alpine`, `postgres:15-alpine`, `redis:7-alpine`); Neo4j est tagué patch.

**OBSERVATION** — CI compile le frontend avec Node 24 alors que le Dockerfile prod build avec Node 22; le job CI ne construit pas l’image Docker prod. **RISK** — environnements de build divergents; pas de preuve de panne sans build comparatif.

## Périmètre fonctionnel
**FACT** — Assystan a une interface provider LLM et un provider Mock. Retrieval consulté lit graphes Studio v2 puis v1; aucun vector database/embedding n’a été identifié dans les manifestes et sources parcourus.

**OBSERVATION** — Redis est configuré comme broker et result backend Celery. **ASSUMPTION** — le rôle « cache » du README peut exister hors des modules examinés; aucun cache applicatif n’a été trouvé dans la recherche ciblée.

## Limites
Pas d’audit transitif/CVE, de mesure versions résolues, ni d’installation de dépendances. Voir [commandes](evidence/commands.md) et les preuves E-016/E-026.