# Traitements asynchrones

## Mécanismes constatés

`celery_app.py` configure Redis broker/backend, ack tardif, rejet à la perte du worker, prefetch=1 et expiration des résultats à 24 h. Autodiscovery inclut connectors, twin_builders, entity_mappings, schedule_snapshots et alerts. Beat planifie réconciliation mappings à 23:00, snapshots P6 à 23:30 et évaluation d’alertes au minute 15.

Le Compose déclare worker et Beat séparément; worker concurrency=2. En production Flower n’est pas déclaré dans le Compose consulté. Les statuts de jobs applicatifs sont en PostgreSQL, pas uniquement dans Celery.

## Parcours et risques

- Connector: API crée `IngestionJob`, puis `.delay`; worker actuel est un placeholder qui persiste un snapshot vide et SUCCESS. L’annulation écrit CANCELLED mais n’envoie pas de revoke et le worker ne relit pas le statut.
- Builder: service exécute synchrone par défaut (`options.sync` default true); chemin async persiste PENDING puis délègue à Celery. Le résultat passe par la même ligne run.
- Mappings/snapshots/alertes: Beat appelle des tâches qui ouvrent une session SQL et utilisent les outils P6/Unifier; chaque batch isole des erreurs métier.
- Import ZIP: thread daemon dans le processus API, task status Python dict, ZIP entier lu en mémoire; ce n’est pas Celery.

## Fiabilité et exploitation

Les retries et `acks_late` sont configurés, mais aucun timeout global de tâche, dead-letter/queue séparée ou outbox DB→broker n’a été observé. Les tâches de snapshot et de réconciliation décrivent des opérations répétables; l’idempotence complète n’a pas été démontrée. Une coupure entre commit SQL et enqueue peut laisser un job PENDING sans message.

## Actions recommandées

1. Remplacer le placeholder ingestion et définir un état explicite `unsupported` tant que ce n’est pas prêt.
2. Rendre l’annulation coopérative et transitions atomiques; tester retry/duplicate delivery.
3. Déplacer l’import Unifier dans une queue durable avec suivi DB, limites upload et reprise.
4. Ajouter timeouts, métriques par task, correlation ID propagé et alerte sur jobs bloqués.
5. Décider si exécution builder sync est acceptable pour les durées réelles; mesurer avant de changer la valeur par défaut.

Voir [ARCH-008](findings/ARCH-008-ingestion-placeholder.md) et [ARCH-011](findings/ARCH-011-unifier-task-state.md). Les workers n’ont pas été exécutés durant l’audit.
