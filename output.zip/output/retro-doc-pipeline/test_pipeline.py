import contextlib
import io
import json
import tempfile
import unittest
from argparse import Namespace
from pathlib import Path
from pipeline import prepare, validate

class PipelineTests(unittest.TestCase):
    def test_snapshot_unknown_drift_and_references(self):
        with tempfile.TemporaryDirectory() as t, contextlib.redirect_stdout(io.StringIO()):
            root=Path(t); repo=root/'repo'; base=root/'base'; out=root/'run'
            repo.mkdir(); base.mkdir()
            (repo/'app.py').write_text('print(1)\n')
            (repo/'README.md').write_text('# Application\n')
            (repo/'.env').write_text('PASSWORD=hidden')
            (base/'audit.md').write_text('SEC-001 ARCH-001 R-001')
            prepare(Namespace(repo=str(repo),baseline=str(base),out=str(out)))
            m=json.loads((out/'manifest.json').read_text())
            self.assertNotIn('.env',[e['path'] for e in m['sources']])
            a=Namespace(out=str(out)); self.assertEqual(validate(a),3)
            r=json.loads((out/'review.json').read_text())
            for v in r['domains'].values():
                v.update(status='complete',summary='Fixture',evidence=[{'path':'app.py','start':1,'end':1}],doc_evidence=[{'path':'README.md','start':1,'end':1}])
            for v in r['findings'].values(): v.update(status='not_applicable',summary='Fixture only')
            (out/'review.json').write_text(json.dumps(r)); self.assertEqual(validate(a),0)
            r['domains']['api']['evidence'][0]['end']=999
            (out/'review.json').write_text(json.dumps(r)); self.assertEqual(validate(a),2)
            (repo/'app.py').write_text('changed\n'); self.assertEqual(validate(a),2)
            with self.assertRaises(ValueError): prepare(Namespace(repo=str(repo),baseline=str(base),out=str(out)))
if __name__=='__main__': unittest.main()
