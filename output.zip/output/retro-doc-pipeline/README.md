# Project-Twin / Assystan retrospective documentation pipeline

This local workflow prepares an evidence inventory, asks Codex to review the current checkout against the supplied historical architecture/security/solution analyses, then validates citations and produces a coverage report. Python 3.10+ and Git are required. No third-party Python packages are needed. Codex performs the semantic review; the Python script does not automatically understand or certify the code.

## Launch locally

Extract this bundle outside the source repository. `baseline/` contains the supplied audit package, unchanged. From the extracted bundle directory, run (PowerShell or Bash):

```sh
python pipeline.py prepare --repo /absolute/path/project-twin --baseline ./baseline --out ./runs/review-001
```

On Windows replace the repository argument with a quoted path such as `"C:/workspace/Project-Twin"`; `py -3` may replace `python`.

Open a local Codex session with access to the repository and this bundle. Paste:

> Read runs/review-001/CODEX-TASK.md and carry out its retrospective documentation workflow against the repository identified there. Write only inside that run's output directory. Assess existing documentation before drafting new documents. Use the supplied pipeline.py validator and report its exit code and remaining unknowns.

No assumed Codex CLI flags or remote services are required. Keep baseline and run folders out of repository source control unless their contents have been reviewed for sharing. Codex may send inspected source to its configured model provider; offline here describes the Python inventory/validator, not model inference.

After the review, or to recheck it:

```sh
python pipeline.py validate --out ./runs/review-001
```

## Stages and outputs

| Stage | Output | Purpose |
|---|---|---|
| Freeze inputs | manifest.json | SHA-256 hashes, commit, dirty state and bounded scope |
| Index historical material | baseline-index.json | ARCH, SEC, SOL, requirements, tasks and test IDs |
| Assess existing docs | review.json | Twelve domains, citation ranges and gaps |
| Reconcile audits | findings in review.json | Current disposition of each historical ID |
| Generate retrospective docs | Markdown documents | Current architecture, API, data, security, operations and traceability |
| Validate and report | validation.json, REPORT.md | Input drift and citation checks; existing-doc coverage |
| Human review | POST-GENERATION-REVIEW.md | Semantic checks and unresolved evidence |

Exit codes: 0 = structurally valid and no documentation gaps/unknowns recorded; 2 = invalid inputs or review; 3 = unverified domains or historical IDs; 4 = partial/missing domain coverage. These are documentation gates, not security risk gates. Unresolved security findings can coexist with complete documentation. A 0 does not establish that the application's tests pass or that it is secure.

The coverage metric is the number of fully documented applicable domains divided by all applicable domains, including unknowns. It is a coarse indicator, not a claim that every source line is documented. Semantic completeness depends on Codex and human review. The validator checks reference existence/ranges, input hashes and required evidence, not whether a citation supports its claim.

## Review priorities grounded in the supplied audits

Recheck Nginx ports and API-prefix rewriting; Angular environment replacement and localhost assumptions; active versus legacy routers; session revocation and workspace authorization; secret_ref resolution; connector SSRF/TLS boundaries; ingestion placeholders; Neo4j backups and schema startup; Celery versus API-thread import execution; LLM tool trust; chat persistence; actual CD stages and external approval evidence. Trace experimentation journey execution, loops and dataset import only where current source supports them. Reconcile SOL-001/002 and requirements R-001–009 as proposals until implementation evidence exists.

## Boundaries and reproducibility

Application files are never executed by the script. It ignores symlinks, common generated directories, sensitive filenames and files over 2 MB; no scanner guarantees detection of every embedded secret. It records file names and hashes, not source contents. Review only sanitized configuration values and never copy credentials into reports. Existing application documentation remains unchanged.

Run folders are immutable preparation snapshots: prepare refuses an existing output. Reuse an existing run to resume review; use a new run after source changes. Validator rejects edits to indexed files. Newly added files are not captured until a new prepare; use a fresh run for the final repository snapshot. Git commit plus dirty flag is not a complete runtime/deployment snapshot.

The supplied baseline is historical documentation, not current source. The source repository was not attached to the request, so no assessment of its present implementation has been performed here.
