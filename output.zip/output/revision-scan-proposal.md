# Revision scans and incremental reuse

Status: implementation proposal; no remote access or source execution performed.

## Observed facts

- The runner accepts an existing local source directory and requires network disabled and source read-only (`src/retro_doc_agent/pipeline.py`, lines 28–53).
- Inventory applies exclusions before opening files and records SHA-256, line counts and sizes (`src/retro_doc_agent/pipeline.py`, lines 61–93).
- Current execution inventories files again on each run and produces unknown coverage; semantic review is pending (`src/retro_doc_agent/pipeline.py`, lines 122–199).

## Proposed interface

- Select exactly one revision with `--tag TAG` or `--commit FULL_SHA1`.
- Select a previous run with `--baseline-run RUN_ID` for incremental scanning.
- Retain existing local-directory scanning when no revision is supplied.
- Keep network disabled by default. Remote acquisition requires an explicit configuration option and repository allowlist. Do not accept embedded credentials or persist authenticated URLs.

## Revision acquisition

Resolve a tag to its commit, including annotated tags; accept only a full 40-character hexadecimal SHA-1 for commit selection. Record the requested selector and resolved immutable commit separately. Reject missing or ambiguous revisions with a structured error.

Create a fresh snapshot only under configured output, separate from reports and caches. Read tracked blobs directly from the selected Git tree so checkout filters, hooks, submodule commands and inspected code never run. Apply path exclusions before retrieving blobs. Do not traverse symlinks or fetch submodules or LFS content automatically; report these as uninspected scope. Acquisition must use a trusted implementation with repository configuration and external helpers disabled, without running shell commands from the target repository.

## Incremental scan

Identify an unchanged artifact by its relative path and content hash, with matching scanner version, skill version, exclusions and scan bounds. For Git revisions, compare immutable blob identities before reading contents so unchanged files can reuse a compatible inventory entry. For ordinary directories, read and hash included files to establish whether their contents changed; modification time alone is insufficient.

Record added, changed, unchanged, deleted, excluded and uninspected paths. A rename is initially a deletion and addition. An artifact absent because it was excluded or exceeded bounds must not be reported as deleted without revision-tree evidence.

Reuse only verified inventory metadata initially. Do not carry semantic coverage forward based solely on an unchanged file: changed dependencies or documentation can invalidate earlier conclusions. Regenerate aggregate reports for the current scope, preserve unknown coverage, and record the baseline run and reuse reason. Reject incompatible, malformed, linked or out-of-output baselines. Never modify a previous run.

## Verification to implement

Use synthetic repositories only: lightweight and annotated tags, exact commits, missing selectors, unchanged and changed blobs, deletion, exclusions before blob reads, bounds changes, malformed baselines, interrupted scans and unchanged source trees. Verify that hooks, filters and source code cannot execute and network remains disabled unless explicitly configured.

## Decisions required

1. Permit editing this lab's implementation, tests and documentation outside output, while keeping inspected target repositories read-only.
2. Choose local Git history only initially, or explicitly authorize opt-in remote acquisition and its configuration.

## Limitations

This proposal inspects the runner, configuration, skills, output contract, README and existing synthetic tests only. It does not establish correctness of any future Git integration or documentation completeness. No tests or repository code were executed.
